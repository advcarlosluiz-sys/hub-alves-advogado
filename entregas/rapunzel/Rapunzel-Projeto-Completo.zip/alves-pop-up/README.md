# Rapunzel — Contos de Gaitolé

Vídeo completo em `output/rapunzel.mp4`: 3min05s, horizontal 1280×720, 24 quadros por segundo, H.264 com áudio AAC estéreo. Abra esse arquivo para assistir, sem executar atalhos .cmd.

Adaptação do roteiro fornecido pelo autor, em dez cenas, com abertura de sete segundos mostrando o título na capa e o livro sobre mesa trabalhada em sala decorada. Ilustrações originais de Rapunzel, príncipe, feiticeira, cavalo, torre, vila e ponte. Trança modelada em 3D, porta revelada, degraus de papel, animais e flores no jardim e fechamento do livro antes da tela da marca.

Narração real: pt-BR-ThalitaMultilingualNeural, cadência -12%, tom -4Hz. A música fornecida pelo autor, Gaitolé, Gaitolé Completa (1), recua de 0.18 para 0.035 durante as falas. Legendas por frase com os tempos fornecidos pelo serviço de voz. Efeitos suaves de passarinhos sintetizados originalmente para a produção.

A pasta `publicacao` contém título, descrição, miniatura e ilustração da capa. O pacote de projeto mantém os áudios, ilustrações, bibliotecas locais e roteiro completo. Licenças do Mira e de suas bibliotecas preservadas. A entrega para assistir contém somente o MP4 e os áudios, sem executáveis.

O nome interno `stories/joao.json` é usado pelo motor, mas seu conteúdo é Rapunzel. `stories/rapunzel.json` é uma cópia com o nome do conto. Para editar, trabalhe no arquivo interno. Mudanças no texto exigem nova narração.

Para abrir o projeto no navegador, com Node 22+ instalado, use `node scripts/serve.mjs` e acesse http://127.0.0.1:8137. Abrir index.html diretamente pelo Explorador não habilita o gerador. Assistir ao MP4 não exige Node ou outros programas de desenvolvimento.

O gerador corrigido 0.2.2 foi utilizado. Para renderização automatizada, Chromium/Chrome e FFmpeg devem estar instalados; execute npm ci e depois node scripts/render-webcodecs.mjs --deck . --out output/rapunzel.mp4.

Este projeto foi preparado localmente. Publicação em armazenamento externo só deve ocorrer com autorização do autor. Caminhos internos e links sandbox não foram usados como promessa de download.

## Velocidade de exportação

O seletor Exportação oferece Padrão (24 quadros/s) e Mais rápido (12 quadros/s). Ambos mantêm 1280×720, duração e áudio; o modo de 12 quadros/s reduz a suavidade dos movimentos e gera metade dos quadros. Pela linha de comando, use --fps 12. O vídeo entregue nesta produção conserva o modo padrão de 24 quadros/s. Em testes deste ambiente, a cópia dos quadros WebGL foi o principal custo; simplificar a sala ou trocar a captura não trouxe ganho relevante. Uma GPU disponível para renderização é a alternativa para acelerar sem reduzir quadros ou resolução.
