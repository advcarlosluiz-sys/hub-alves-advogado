import * as THREE from '../vendor/three.module.js';
const smooth=x=>{x=Math.max(0,Math.min(1,x));return x*x*(3-2*x)};
export function buildAliceProps(parent,s,textures){
 const g=new THREE.Group();parent.add(g);const mat=c=>new THREE.MeshStandardMaterial({color:c,roughness:.9,side:THREE.DoubleSide});
 const wood=mat('#9d785b'),gold=mat('#c8a05b'),cream=mat('#efe1c3'),teal=mat('#84aaa4'),green=mat('#789366'),pink=mat('#c78d9c');
 const clocks=[],books=[],cards=[],arches=[],balls=[],wings=[],rosePetals=[],steam=[];let door=null,key=null,smile=null;
 function mesh(geometry,material,x,y,z,group=g){const m=new THREE.Mesh(geometry,material);m.position.set(x,y,z);m.castShadow=m.receiveShadow=true;group.add(m);return m}
 function box(w,h,d,m,x,y,z,group){return mesh(new THREE.BoxGeometry(w,h,d),m,x,y,z,group)}
 function shape(points,m,x,y,z,group){const a=new THREE.Shape();a.moveTo(...points[0]);for(const p of points.slice(1))a.lineTo(...p);a.closePath();return mesh(new THREE.ShapeGeometry(a),m,x,y,z,group)}
 function texture(draw,w=128,h=128){const c=document.createElement('canvas');c.width=w;c.height=h;draw(c.getContext('2d'),w,h);const tx=new THREE.CanvasTexture(c);tx.colorSpace=THREE.SRGBColorSpace;return tx;}
 const clockFace=texture((x,w,h)=>{x.fillStyle='#f7ebd1';x.fillRect(0,0,w,h);x.strokeStyle='#927444';x.lineWidth=3;x.beginPath();x.arc(w/2,h/2,55,0,7);x.stroke();x.fillStyle='#66563e';x.textAlign='center';x.textBaseline='middle';x.font='20px Georgia';for(const [n,dx,dy] of [[12,0,-39],[3,40,0],[6,0,40],[9,-40,0]])x.fillText(n,64+dx,64+dy);});
 function clock(x,y,z,scale=1){const b=new THREE.Group();b.position.set(x,y,z);b.scale.setScalar(scale);g.add(b);const body=mesh(new THREE.CylinderGeometry(.36,.36,.1,24),gold,0,0,0,b);body.rotation.x=Math.PI/2;mesh(new THREE.CircleGeometry(.31,24),new THREE.MeshStandardMaterial({map:clockFace,roughness:1}),0,0,.055,b);mesh(new THREE.TorusGeometry(.11,.025,6,12),gold,0,.43,0,b);const hand=new THREE.Group();b.add(hand);box(.02,.22,.025,wood,0,.1,.075,hand);box(.15,.025,.025,wood,.06,0,.08,hand);clocks.push({b,hand});return b;}
 function flower(x,z,n=0){const b=new THREE.Group();b.position.set(x,0,z);g.add(b);mesh(new THREE.CylinderGeometry(.15,.1,.3,10),mat('#b78970'),0,.15,0,b);box(.025,.65,.025,green,0,.57,0,b);for(let k=0;k<6;k++){const a=k*Math.PI/3;mesh(new THREE.CircleGeometry(.13,8),mat(n%2?'#c5afd0':'#e1b4b8'),Math.cos(a)*.15,.94+Math.sin(a)*.15,.025,b);}mesh(new THREE.CircleGeometry(.09,10),gold,0,.94,.04,b);}
 if(s.aliceGarden)for(const [n,x] of [-4.3,4.2].entries())for(const z of [.1,1.8])flower(x,z,n);
 if(s.pocketWatch)clock(s.teaPartyAlice?-2.6:2.1,s.teaPartyAlice?2.8:1.6,s.teaPartyAlice?-.3:.65,s.teaPartyAlice?1:.65);
 if(s.spiralPassage){for(let n=0;n<20;n++){const a=n*.4;const slab=box(.85,.035,.32,n%2?cream:teal,Math.cos(a)*2,3.8-n*.18,-1.4+Math.sin(a)*.55);slab.rotation.y=-a;}
 for(let n=0;n<6;n++){const b=new THREE.Group();b.position.set(-3.7+(n%3)*3.3,.8+Math.floor(n/3)*2.3,-.7);g.add(b);box(.55,.75,.08,mat(['#b38f9f','#8ca9a0','#c8ac75'][n%3]),0,0,0,b);box(.45,.64,.09,cream,0,0,.01,b);b.rotation.z=(n%2?.2:-.2);books.push(b);}clock(-3.4,2,.5,.8);clock(3.6,3.2,-1.1,.7);}
 if(s.keyTable){const glass=new THREE.MeshStandardMaterial({color:'#d1e1db',transparent:true,opacity:.55,roughness:.25});box(1.55,.09,.95,glass,.35,1,.65);for(const dx of [-.55,.55])for(const dz of [-.28,.28])box(.06,1,.06,gold,.35+dx,.5,.65+dz);
 key=new THREE.Group();key.position.set(.35,1.2,.85);g.add(key);mesh(new THREE.TorusGeometry(.12,.03,6,16),gold,0,0,0,key);box(.06,.35,.06,gold,0,-.25,0,key);box(.18,.06,.06,gold,.06,-.39,0,key);key.rotation.z=-.5;}
 if(s.tinyDoor){const f=new THREE.Group();f.position.set(1.5,.02,-.65);g.add(f);box(1.15,1.7,.08,gold,0,.85,-.03,f);const portal=mesh(new THREE.PlaneGeometry(.95,1.45),new THREE.MeshStandardMaterial({map:textures.jardim_arvore_alice,roughness:1}),0,.8,.025,f);door=new THREE.Group();door.position.set(-.48,0,.07);f.add(door);box(.96,1.5,.06,teal,.48,.75,0,door);box(.78,1.25,.07,cream,.48,.75,.015,door);mesh(new THREE.SphereGeometry(.04,8,6),gold,.82,.77,.075,door);}
 if(s.mushroomAlice){mesh(new THREE.CylinderGeometry(.2,.28,1.45,12),cream,1.5,.73,.4);mesh(new THREE.ConeGeometry(1.1,.43,18),pink,1.5,1.48,.4);for(let n=0;n<7;n++){const a=n*2.4;mesh(new THREE.SphereGeometry(.09,7,5),cream,1.5+Math.cos(a)*.7,1.55,.4+Math.sin(a)*.7);}}
 if(s.catSmile){const q=new THREE.Shape();q.moveTo(-.23,.04);q.quadraticCurveTo(0,-.18,.23,.04);q.quadraticCurveTo(0,-.07,-.23,.04);smile=mesh(new THREE.ShapeGeometry(q),cream,2.23,2.6,1.1);}
 if(s.signposts){box(.08,1.7,.08,wood,-3.2,.85,.2);for(const [n,dx] of [[0,-1],[1,1]]){const arrow=shape([[-.55,-.1],[.35,-.1],[.35,-.22],[.68,0],[.35,.22],[.35,.1],[-.55,.1]],n?cream:teal,-3.2,1.2+n*.4,.25);arrow.scale.x=dx;}}
 function cup(x,z,color=teal,group=g,y=1.18){mesh(new THREE.CylinderGeometry(.12,.085,.22,12),color,x,y,z,group);mesh(new THREE.TorusGeometry(.085,.018,6,12),gold,x+.12,y,z,group);mesh(new THREE.CylinderGeometry(.18,.18,.025,14),cream,x,y-.13,z,group);}
 if(s.teaPartyAlice){box(4.7,.12,1.35,wood,.3,.93,.7);for(const x of [-1.6,2.2])for(const z of [.15,1.2])box(.1,.9,.1,wood,x,.45,z);
 for(let n=0;n<6;n++){cup(-1.45+n*.65,.82,n%2?pink:teal);const curve=new THREE.CatmullRomCurve3([new THREE.Vector3(0,0,0),new THREE.Vector3(.05,.13,0),new THREE.Vector3(-.04,.25,0),new THREE.Vector3(.02,.4,0)]);const m=mesh(new THREE.TubeGeometry(curve,10,.009,4,false),new THREE.MeshBasicMaterial({color:'#e9dfd3',transparent:true,opacity:.4}),-1.45+n*.65,1.3,.82);steam.push(m);}
 mesh(new THREE.SphereGeometry(.24,12,8),pink,.2,1.25,.4);const spout=mesh(new THREE.ConeGeometry(.09,.4,8),pink,.5,1.35,.4);spout.rotation.z=-1;mesh(new THREE.TorusGeometry(.2,.025,6,16),gold,-.04,1.27,.4);
 for(const x of [-2.4,.1,2.8]){box(.7,.08,.6,wood,x,.56,-.4);box(.7,.7,.06,teal,x,.95,-.68);for(const dx of [-.25,.25])box(.06,.55,.06,wood,x+dx,.28,-.45);}}
 if(s.rosePaintAlice){for(const side of [-1,1])for(let n=0;n<3;n++){const x=side*(2.5+n*.6);box(.025,.85,.025,green,x,.45,1.4);for(let k=0;k<5;k++){const a=k*1.26;const m=mesh(new THREE.CircleGeometry(.11,7),mat('#f0e8d4'),x+Math.cos(a)*.08,.98+Math.sin(a)*.08,1.43);rosePetals.push({m,at:3+n*2+(side>0?1:0)});}}}
 if(s.fountainAlice){mesh(new THREE.CylinderGeometry(.6,.7,.2,14),cream,-4.2,.12,-1);mesh(new THREE.CylinderGeometry(.52,.52,.015,20),teal,-4.2,.23,-1);mesh(new THREE.CylinderGeometry(.08,.14,.6,10),cream,-4.2,.5,-1);
 for(const x of [-4.6,-3.9]){const b=new THREE.Group();b.position.set(x,0,-1.8);g.add(b);for(const dx of [-.05,.05])box(.025,.6,.025,gold,dx,.3,0,b);const body=mesh(new THREE.CircleGeometry(.19,14),pink,0,.76,0,b);body.scale.x=1.5;const curve=new THREE.CatmullRomCurve3([new THREE.Vector3(.15,.76,0),new THREE.Vector3(.08,.98,0),new THREE.Vector3(.2,1.16,0)]);mesh(new THREE.TubeGeometry(curve,12,.04,6,false),pink,0,0,0,b);mesh(new THREE.SphereGeometry(.07,10,6),pink,.2,1.16,0,b);shape([[0,0],[.13,-.05],[.02,-.09]],wood,.24,1.17,.01,b);}}
 if(s.royalGameAlice){for(let n=0;n<3;n++){const a=mesh(new THREE.TorusGeometry(.35,.025,6,24,Math.PI),n%2?gold:teal,-2+n*2,.12,1.2);arches.push({m:a,x:a.position.x});balls.push(mesh(new THREE.SphereGeometry(.13,10,8),n%2?pink:cream,-2+n*2,.14,1.5));}
 if(s.turnTakingAlice)for(let n=0;n<3;n++){const tx=texture((x,w,h)=>{x.fillStyle='#efe1c3';x.fillRect(0,0,w,h);x.fillStyle='#5b6a65';x.textAlign='center';x.textBaseline='middle';x.font='bold 84px Georgia';x.fillText(n+1,w/2,h/2);});box(.03,.6,.03,wood,-2+n*2,.3,2.1);mesh(new THREE.PlaneGeometry(.32,.38),new THREE.MeshStandardMaterial({map:tx,roughness:1}),-2+n*2,.78,2.1);}}
 if(s.cardSwirlAlice){const tx=texture((x,w,h)=>{x.fillStyle='#f5ecd9';x.fillRect(0,0,w,h);x.strokeStyle='#bfa374';x.lineWidth=3;x.strokeRect(3,3,w-6,h-6);x.fillStyle='#b67a82';x.beginPath();x.moveTo(w/2,h*.68);x.bezierCurveTo(w*.1,h*.35,w*.22,h*.18,w/2,h*.36);x.bezierCurveTo(w*.78,h*.18,w*.9,h*.35,w/2,h*.68);x.fill();},80,112);for(let n=0;n<20;n++)cards.push(mesh(new THREE.PlaneGeometry(.28,.4),new THREE.MeshStandardMaterial({map:tx,side:THREE.DoubleSide,roughness:1,transparent:true}),0,0,0));}
 if(s.storyBookAlice){const b=new THREE.Group();b.position.set(-.6,1.12,1.1);g.add(b);for(const side of [-1,1]){const leaf=box(.65,.035,.8,cream,side*.32,0,0,b);leaf.rotation.z=-side*.12;box(.67,.04,.83,teal,side*.32,-.04,0,b);}}
 if(s.butterfliesAlice)for(let n=0;n<3;n++){const b=new THREE.Group();g.add(b);for(const side of [-1,1]){const w=shape([[0,0],[side*.15,.14],[side*.24,.02],[side*.1,-.1]],n%2?pink:teal,0,0,0,b);w.userData.side=side;}wings.push(b);}
 return {update(t,closing){
  g.scale.y=Math.max(.001,smooth((t-.2)/1.2)*closing);
  clocks.forEach(({b,hand},n)=>{hand.rotation.z=-t*.9-n;b.rotation.z=Math.sin(t*.6+n)*.025;});books.forEach((b,n)=>b.position.y=.8+Math.floor(n/3)*2.3+Math.sin(t*.8+n)*.06);
  if(door)door.rotation.y=-smooth((t-(s.aliceScale?12:7))/2)*1.25;
  if(key)key.rotation.z=-.5+Math.sin(t)*.05;
  if(smile)smile.visible=t>=(s.catFadeAt??6)&&t<=(s.catReturnAt??12);
  steam.forEach((m,n)=>m.rotation.y=Math.sin(t+n)*.4);
  rosePetals.forEach(({m,at})=>m.material.color.set('#f0e8d4').lerp(new THREE.Color('#bc7d87'),smooth((t-at)/2)));
  arches.forEach(({m,x},n)=>m.position.x=x+(s.turnTakingAlice?1-smooth((t-11)/2):1)*Math.sin(t*1.5+n)*.45);
  balls.forEach((m,n)=>m.position.x=-2+n*2+Math.sin(t*1.1+n)*.6);
  cards.forEach((m,n)=>{const q=smooth((t-2)/2)*(1-smooth((t-10)/3)),a=n*2.4+t*.65;m.position.set(Math.cos(a)*(1.2+(n%4)*.7),.5+(n%6)*.52+Math.sin(t+n)*.1,Math.sin(a)*1.5);m.rotation.set(Math.sin(a)*.4,a,Math.sin(a+n)*.4);m.material.opacity=q;m.visible=q>.005;});
  wings.forEach((b,n)=>{const land=s.storyBookAlice?smooth((t-7)/5):0;b.position.set((1-land)*(-2+n*2+Math.sin(t*.7+n)*.3)+land*(-.65+n*.15),(1-land)*(1.6+n*.28+Math.sin(t+n)*.1)+land*1.3,(1-land)*1.1+land*1.1);b.children.forEach(w=>w.rotation.y=w.userData.side*Math.sin(t*8+n)*.65*(1-land*.8));});
 }};
}
