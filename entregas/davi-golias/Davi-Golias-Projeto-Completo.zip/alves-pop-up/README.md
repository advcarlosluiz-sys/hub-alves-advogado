# Davi e Golias — livro pop-up

Adaptação infantil de 1 Samuel 17 para o Contos de Gaitolé. **3min53s**, horizontal **1280 × 720**, **24 fps**, H.264/AAC estéreo. Narração Thalita em português do Brasil e música fornecida **Davi v.2**, com redução automática de volume nas falas.

## Assistir

Abra `output/davi-golias.mp4`. No ZIP para assistir, extraia a pasta e abra `alves-pop-up/ASSISTA-AQUI.mp4`. Não precisa executar `.cmd` para assistir.

## Arquivos do projeto

- `stories/joao.json`: roteiro principal do motor (nome mantido por compatibilidade); cópia nomeada em `stories/davi-golias.json`.
- `references/roteiro-fornecido.txt`: roteiro recebido do usuário.
- `assets/davi/`: ilustrações originais dos personagens e cenários; recortes descritos em `references/assets-originais.json` e `engine/story.mjs`.
- `engine/davi-props.mjs`: harpa, cajado, cestos, flores, armadura, pedrinhas e demais objetos animados.
- `assets/narracao/`: 11 clipes Thalita, legendas por frase e manifesto de sincronização.
- `assets/musica/davi-v2.mp3`: música original fornecida, preservada.
- `assets/musica/davi-v2-fundo.mp3`: cópia de trabalho com silêncio acrescentado ao fim para acompanhar a duração do vídeo, sem reiniciar a canção no encerramento. A pausa do confronto é aplicada pela mixagem.
- `assets/efeitos/`: sons suaves de ambiente e sinal de encerramento.
- `publicacao/`: miniatura 1280 × 720, capa, título e descrição para YouTube.

O confronto é representado por uma transição de céu e papel, sem lançamento ou impacto visíveis. A cena seguinte mostra apenas seu desfecho à distância. O livro fica sobre uma mesa de madeira em uma sala decorada, com transições por virada de página.

## Editar e exportar

Requer Node.js 22+, Chrome/Chromium/Edge e FFmpeg. Execute `npm ci`, depois `npm start` para visualizar o livro no endereço local indicado. Para exportar: `npm run render:fast -- --out output/davi-golias.mp4`. `CHROME_PATH` e `FFMPEG_PATH` permitem indicar os programas instalados.

As vozes existentes já estão incluídas; alterações no texto exigem regenerar a narração e atualizar as legendas. A geração musical Noiz está desativada neste episódio, pois foi usada a música fornecida. Nenhuma chave é necessária para exportar os arquivos existentes.

## Créditos

Relato bíblico: 1 Samuel 17, adaptação infantil original. Canal Contos de Gaitolé: YouTube @gaitolé e TikTok @gaitole0. Mira: sandeco/mira-animator. Avisos e termos originais preservados em LICENSE-MIRA e vendor.
