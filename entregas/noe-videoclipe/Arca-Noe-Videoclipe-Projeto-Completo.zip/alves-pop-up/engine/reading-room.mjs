import * as THREE from '../vendor/three.module.js';
const material=(color,metalness=0)=>new THREE.MeshStandardMaterial({color,roughness:metalness ? 0.38 : 0.85,metalness});
export function buildReadingRoom(scene,wood) {
 const previous=new Set(scene.children);
 const walnut=new THREE.MeshStandardMaterial({map:wood,color:'#9a7150',roughness:.65});
 const gold=material('#b78b3e',.65),dark=material('#432d23'),cream=material('#eadbbf'),teal=material('#305554');
 function box(w,h,d,mat,x,y,z){const m=new THREE.Mesh(new THREE.BoxGeometry(w,h,d),mat);m.position.set(x,y,z);scene.add(m);m.receiveShadow=true;return m;}
 function cylinder(rt,rb,h,mat,x,y,z){const m=new THREE.Mesh(new THREE.CylinderGeometry(rt,rb,h,16),mat);m.position.set(x,y,z);scene.add(m);m.receiveShadow=true;return m;}
 // Mesa de nogueira: tampo, moldura em relevo, saias entalhadas e pés torneados.
 box(19,.42,13,walnut,0,-.67,0);
 box(19.3,.12,13.3,dark,0,-.88,0);
 for(const z of [-6.28,6.28]){box(18.6,.035,.045,gold,0,-.44,z);box(17,.7,.2,walnut,0,-1.2,z*.92);}
 for(const x of [-9.15,9.15])box(.045,.035,12.6,gold,x,-.44,0);
 for(const x of [-8,8])for(const z of [-5,5]){
  cylinder(.35,.22,3.25,walnut,x,-2.8,z);
  for(const y of [-1.35,-2.2,-3.6,-4.35])cylinder(.43,.43,.13,gold,x,y,z);
  const foot=new THREE.Mesh(new THREE.SphereGeometry(.45,12,8),walnut);foot.scale.set(1,.55,1);foot.position.set(x,-4.55,z);scene.add(foot);
 }
 for(let x=-7.5;x<=7.5;x+=1.5){const m=box(.45,.22,.12,gold,x,-1.18,5.94);m.rotation.z=Math.PI/4;}
 // Passadeira bordada sob o livro.
 box(14.2,.025,10.2,cream,0,-.435,0);
 for(const z of [-4.94,4.94])box(13.9,.012,.04,gold,0,-.414,z);
 for(const x of [-6.9,6.9])box(.04,.012,9.9,gold,x,-.414,0);
 // Sala: assoalho, paredes, painéis, estantes, janela e cortinas.
 box(48,.2,44,walnut,0,-4.85,0);
 box(42,17,.3,material('#718477'),0,3.5,-12);
 box(.3,17,38,material('#566d63'),-18,3.5,3);
 box(42,3.3,.18,teal,0,-3.1,-11.76);
 for(let x=-19;x<20;x+=3){box(.07,3.3,.1,gold,x,-3.1,-11.6);box(2.6,.05,.1,gold,x+1.3,-1.6,-11.6);}
 box(42,.16,.23,dark,0,-1.35,-11.55);
 // Janela luminosa com caixilhos e vista para o jardim.
 const glass=material('#b5d5d2');glass.emissive=new THREE.Color('#799b95');glass.emissiveIntensity=.25;
 box(7.5,7,.13,cream,0,4,-11.65);box(6.8,6.4,.15,glass,0,4,-11.53);
 for(const x of [-3.5,0,3.5])box(.13,6.8,.2,dark,x,4,-11.35);
 for(const y of [1,4,7])box(7.2,.13,.2,dark,0,y,-11.35);
 for(const x of [-4.2,4.2]){
  const curtain=box(1.5,7.7,.28,material('#9e574a'),x,3.8,-11.1);
  for(let i=0;i<5;i++)cylinder(.14,.14,7.6,material(i%2?'#a76050':'#914e42'),x-.6+i*.3,3.8,-10.9);
  box(1.6,.12,.3,gold,x,2.3,-10.7);
 }
 box(11,.12,.3,gold,0,7.8,-10.8);
 const colors=['#835442','#546b62','#a38248','#6d5763','#ba9270','#425d69'];
 for(const sx of [-10.5,10.5]){
  box(5.8,11,.3,dark,sx,.7,-11.35);
  for(const x of [sx-3,sx+3])box(.3,11.5,1.3,walnut,x,.7,-10.9);
  for(let row=0;row<4;row++){
   const y=-4+row*2.8;box(6.2,.18,1.5,walnut,sx,y,-10.8);
   for(let n=0;n<8;n++){const x=sx-2.45+n*.69,h=1.4+(n*7%5)*.18;box(.5,h,.65,material(colors[(n+row)%colors.length]),x,y+h/2+.1,-10.6);box(.43,.04,.025,gold,x,y+h*.78,-10.25);}
  }
 }
 // Abajur de latão, vaso com folhas e xícara sobre a mesa.
 cylinder(.65,.8,.16,gold,7.4,-.28,-3.7);cylinder(.09,.13,2.25,gold,7.4,.9,-3.7);
 cylinder(.72,1.15,1.1,material('#eed5a6'),7.4,2.1,-3.7);
 const glow=new THREE.PointLight(0xffd298,12,11,2);glow.position.set(7.4,1.9,-3.7);scene.add(glow);
 cylinder(.6,.43,1.1,material('#98644b'),-7.7,.1,-3.5);
 for(let i=0;i<8;i++){const leaf=new THREE.Mesh(new THREE.SphereGeometry(.4,10,7),material(i%2?'#557948':'#769553'));leaf.scale.set(.55,2.1,.25);leaf.rotation.z=(i-3.5)*.29;leaf.position.set(-7.7+Math.sin(i)*.6,1+Math.cos(i*.8)*.4,-3.5+Math.cos(i)*.5);scene.add(leaf);}
 cylinder(.55,.55,.06,cream,7.7,-.35,3.4);cylinder(.35,.28,.6,cream,7.7,-.03,3.4);
 const handle=new THREE.Mesh(new THREE.TorusGeometry(.23,.06,8,16),gold);handle.position.set(8.05,.02,3.4);scene.add(handle);
 // Pequenas gravuras em moldura, em ambos os lados da janela.
 for(const x of [-5.8,5.8]){box(1.6,2.3,.15,gold,x,4.8,-11.3);box(1.35,2.05,.17,cream,x,4.8,-11.2);}
 // Agrupa a geometria estática da sala por material; preserva iluminação e UVs.
 const buckets=new Map();scene.updateMatrixWorld(true);
 for(const mesh of [...scene.children]){
  if(previous.has(mesh)||!mesh.isMesh)continue;
  const m=mesh.material,key=[m.type,m.color?.getHex(),m.map?.uuid,m.roughness,m.metalness,m.emissive?.getHex(),m.emissiveIntensity].join('|');
  const entry=buckets.get(key)||{material:m,parts:[]};
  const g=mesh.geometry.index?mesh.geometry.toNonIndexed():mesh.geometry.clone();g.applyMatrix4(mesh.matrixWorld);entry.parts.push(g);buckets.set(key,entry);scene.remove(mesh);
 }
 for(const {material,parts} of buckets.values()){
  const geometry=new THREE.BufferGeometry();
  for(const name of ['position','normal','uv']){
   const itemSize=parts[0].getAttribute(name).itemSize;
   const count=parts.reduce((n,p)=>n+p.getAttribute(name).array.length,0),values=new Float32Array(count);let offset=0;
   for(const part of parts){values.set(part.getAttribute(name).array,offset);offset+=part.getAttribute(name).array.length;}
   geometry.setAttribute(name,new THREE.BufferAttribute(values,itemSize));
  }
  const mesh=new THREE.Mesh(geometry,material);mesh.receiveShadow=true;scene.add(mesh);for(const part of parts)part.dispose();
 }
}
export async function createFrontCover(scene,story) {
 const c=document.createElement('canvas');c.width=1024;c.height=1365;const x=c.getContext('2d');
 x.fillStyle='#315d54';x.fillRect(0,0,c.width,c.height);
 for(let i=0;i<1800;i++){x.fillStyle=i%2?'rgba(255,245,205,.025)':'rgba(0,0,0,.025)';x.fillRect((i*97)%1024,(i*137)%1365,30,2);}
 x.strokeStyle='#e5c077';x.lineWidth=7;x.strokeRect(35,35,954,1295);x.lineWidth=2;x.strokeRect(54,54,916,1257);
 for(const xx of [74,950])for(const yy of [77,1288]){x.save();x.translate(xx,yy);x.rotate(Math.PI/4);x.fillStyle='#e5c077';x.fillRect(-13,-13,26,26);x.restore();}
 x.textAlign='center';x.fillStyle='#efd39a';x.font='32px Georgia';x.fillText('CONTOS DE GAITOLÉ',512,135);
 const words=story.title.split(' '),lines=[];let line='';x.font='bold 76px Georgia';
 for(const word of words){if(x.measureText((line+' '+word).trim()).width>820&&line){lines.push(line);line=word;}else line=(line+' '+word).trim();}if(line)lines.push(line);
 lines.forEach((l,i)=>x.fillText(l,512,280+i*95));
 if(story.presentation?.coverImage){const img=new Image();img.src=story.presentation.coverImage;try {await img.decode();x.drawImage(img,100,550,824,464);} catch { /* O título e a capa continuam disponíveis sem a ilustração opcional. */ }x.strokeStyle='#e5c077';x.lineWidth=4;x.strokeRect(97,547,830,470);}
 x.font='italic 32px Georgia';x.fillText('Uma bela história todo dia!',512,1190);
 const tex=new THREE.CanvasTexture(c);tex.colorSpace=THREE.SRGBColorSpace;
 const group=new THREE.Group();scene.add(group);
 const coverMat=material('#315d54');const pages=material('#e9d8b8');
 for(const [y,h,mat] of [[-.32,.15,coverMat],[-.1,.3,pages]]){const m=new THREE.Mesh(new THREE.BoxGeometry(6.3,h,8.4),mat);m.position.set(3.15,y,0);m.castShadow=m.receiveShadow=true;group.add(m);}
 const hinge=new THREE.Group();hinge.position.set(0,.12,0);group.add(hinge);
 const board=new THREE.Mesh(new THREE.BoxGeometry(6.35,.14,8.45),coverMat);board.position.x=3.175;board.castShadow=true;hinge.add(board);
 const face=new THREE.Mesh(new THREE.PlaneGeometry(6.25,8.35),new THREE.MeshStandardMaterial({map:tex,roughness:.62}));face.rotation.x=-Math.PI/2;face.position.set(3.175,.076,0);hinge.add(face);
 return {group,hinge,canvas:c};
}
