import * as THREE from '../vendor/three.module.js';
const smooth=x=>{x=Math.max(0,Math.min(1,x));return x*x*(3-2*x)};
export function buildNoeProps(parent,s,textures,actors){
 const g=new THREE.Group();parent.add(g);
 const mat=c=>new THREE.MeshStandardMaterial({color:c,roughness:.95,side:THREE.DoubleSide});
 const wood=mat('#b57d45'),dark=mat('#815831'),cream=mat('#e7d7ad'),green=mat('#708e4e'),gold=mat('#d8bc6c'),blue=mat('#6cabb9');
 function mesh(geo,m,x=0,y=0,z=0,group=g){const a=new THREE.Mesh(geo,m);a.position.set(x,y,z);a.castShadow=a.receiveShadow=true;group.add(a);return a;}
 function box(w,h,d,m,x,y,z,group){return mesh(new THREE.BoxGeometry(w,h,d),m,x,y,z,group)}
 function cyl(r1,r2,h,m,x,y,z,group){return mesh(new THREE.CylinderGeometry(r1,r2,h,18),m,x,y,z,group)}
 function texture(draw){const c=document.createElement('canvas');c.width=c.height=256;draw(c.getContext('2d'));const t=new THREE.CanvasTexture(c);t.colorSpace=THREE.SRGBColorSpace;return t;}
 const plankTx=texture(c=>{c.fillStyle='#b98249';c.fillRect(0,0,256,256);for(let j=0;j<8;j++){c.strokeStyle=j%2?'#926336':'#d29a5e';c.lineWidth=3;c.beginPath();c.moveTo(0,j*32);c.lineTo(256,j*32+1);c.stroke();for(let k=0;k<4;k++){c.lineWidth=.7;c.beginPath();c.moveTo(0,j*32+6+k*5);c.bezierCurveTo(80,j*32+k*5,180,j*32+12+k*5,256,j*32+7+k*5);c.stroke();}}});
 const grain=new THREE.MeshStandardMaterial({map:plankTx,roughness:.92,side:THREE.DoubleSide});
 let ark=null,hull=null,wall=null,roof=null,leaf=null,rainbow=null,calendar=null,structure=null,doorPivot=null;const rains=[],waves=[];
 if(s.arkModel){
  ark=new THREE.Group();ark.position.set(s.arkX||0,0,s.arkZ||0);ark.scale.setScalar(s.arkScale||1);g.add(ark);
  const shape=new THREE.Shape();shape.moveTo(-3.25,1.2);shape.lineTo(-2.65,.18);shape.quadraticCurveTo(0,-.05,2.65,.18);shape.lineTo(3.25,1.2);shape.closePath();
  hull=mesh(new THREE.ExtrudeGeometry(shape,{depth:2.2,bevelEnabled:true,bevelSegments:1,steps:1,bevelSize:.035,bevelThickness:.035}),grain,0,0,-1.1,ark);
  box(6.35,.1,2.25,dark,0,1.22,0,ark);
  // The front facade has actual openings, with a hinged lower edge.
  wall=new THREE.Group();wall.position.set(0,1.25,1.08);ark.add(wall);
  const facade=new THREE.Shape();facade.moveTo(-2.8,0);facade.lineTo(2.8,0);facade.lineTo(2.8,1.5);facade.lineTo(-2.8,1.5);facade.closePath();
  for(const x of [-1.8,-.6,.6]){const hole=new THREE.Path();hole.moveTo(x-.34,.42);hole.lineTo(x-.34,1.16);hole.lineTo(x+.34,1.16);hole.lineTo(x+.34,.42);hole.closePath();facade.holes.push(hole);box(.79,.055,.07,cream,x,.4,.04,wall);box(.79,.055,.07,cream,x,1.18,.04,wall);for(const side of [-1,1])box(.055,.82,.07,cream,x+side*.37,.79,.04,wall);}
  const door=new THREE.Path();door.moveTo(1.85,0);door.lineTo(1.85,1.28);door.lineTo(2.75,1.28);door.lineTo(2.75,0);door.closePath();facade.holes.push(door);for(const x of [1.82,2.78])box(.07,1.32,.1,cream,x,.64,.03,wall);box(1.03,.07,.1,cream,2.3,1.3,.03,wall);
  mesh(new THREE.ShapeGeometry(facade),grain,0,0,0,wall);doorPivot=new THREE.Group();doorPivot.position.set(1.85,0,.065);wall.add(doorPivot);box(.9,1.28,.06,grain,.45,.64,0,doorPivot);box(.055,.055,.06,gold,.75,.6,.045,doorPivot);
  structure=new THREE.Group();ark.add(structure);box(5.6,1.5,.06,grain,0,2,-1.08,structure);
  box(.07,1.5,2.12,grain,-2.8,2,0,structure);box(.07,1.5,2.12,grain,2.8,2,0,structure);
  for(const x of [-2.75,-.9,.9,2.75])box(.065,1.4,2.05,wood,x,1.95,-.02,structure);
  roof=new THREE.Group();roof.position.set(0,2.76,-1.15);ark.add(roof);
  const front=box(6.05,.065,1.4,mat('#a5633d'),0,.28,1.68,roof);front.rotation.x=.42;
  const back=box(6.05,.065,1.4,mat('#b7784d'),0,.28,.48,roof);back.rotation.x=-.42;
  for(let n=0;n<14;n++)for(const z of [.48,1.68]){const a=box(.025,.08,1.38,wood,-2.86+n*.44,.31,z,roof);a.rotation.x=z>1?.42:-.42;}
  // A folding gangway gives the boarding procession a destination.
  const ramp=box(1.15,.055,1.7,wood,2.5,.5,1.65,ark);ramp.rotation.x=.7;
  for(let n=0;n<6;n++){const a=box(1.16,.025,.055,cream,2.5,.1+n*.18,2.3-n*.21,ark);}
 }
 if(s.woodProps){for(let n=0;n<5;n++)box(1.5,.1,.18,n%2?wood:dark,-3.4,.1+n*.11,-.3);for(let n=0;n<3;n++)box(.13,.13,1.25,wood,3.7,.1+n*.14,.1);const r=mesh(new THREE.TorusGeometry(.32,.045,6,24),gold,-3.7,.12,1);r.rotation.x=-Math.PI/2;}
 if(s.planTable){box(2,.1,1.15,wood,0,1,.5);for(const x of [-.8,.8])for(const z of [.1,.9])box(.08,1,.08,dark,x,.5,z);const tx=texture(c=>{c.fillStyle='#e7d9b9';c.fillRect(0,0,256,256);c.strokeStyle='#628485';c.lineWidth=5;c.strokeRect(35,75,180,90);c.beginPath();c.moveTo(18,167);c.lineTo(51,213);c.lineTo(206,213);c.lineTo(239,167);c.closePath();c.stroke();c.beginPath();c.moveTo(25,77);c.lineTo(127,32);c.lineTo(227,77);c.stroke();for(let n=0;n<4;n++)c.strokeRect(48+n*43,105,25,35);});const a=mesh(new THREE.PlaneGeometry(1.7,.98),new THREE.MeshStandardMaterial({map:tx,roughness:1}),0,1.065,.5);a.rotation.x=-Math.PI/2;for(const x of [-.88,.88]){const q=cyl(.06,.06,1,cream,x,1.1,.5);q.rotation.x=Math.PI/2;}}
 if(s.feedingProps){const floor=s.arkCutaway?1.28:.12;for(const x of [-1.1,1.1]){cyl(.32,.24,.16,wood,x,floor,1.1);cyl(.27,.27,.025,blue,x,floor+.09,1.1);}for(let n=0;n<3;n++)box(.5,.3,.36,gold,2.2-n*.56,floor+.1,-.2);}
 if(s.calendarProps){calendar=new THREE.Group();calendar.position.set(2.9,2,-1.7);g.add(calendar);const tx=texture(c=>{c.fillStyle='#f4e8ce';c.fillRect(0,0,256,256);c.fillStyle='#779077';c.fillRect(0,0,256,70);c.fillStyle='white';c.font='bold 38px Georgia';c.textAlign='center';c.fillText('DIAS',128,49);c.fillStyle='#ba9c68';for(let n=0;n<20;n++)c.fillRect(30+(n%5)*42,90+Math.floor(n/5)*37,15,15);});mesh(new THREE.PlaneGeometry(1,1.1),new THREE.MeshStandardMaterial({map:tx,side:THREE.DoubleSide}),0,0,0,calendar);}
 if(s.rainProps||s.waterFloor){for(let n=0;n<5;n++){const shape=new THREE.Shape();shape.moveTo(-5,0);for(let k=0;k<=40;k++){const x=-5+k*.25;shape.lineTo(x,.25+Math.sin(k*.65+n)*.1);}shape.lineTo(5,0);shape.closePath();const a=mesh(new THREE.ShapeGeometry(shape),mat(n%2?'#82bac5':'#609eaf'),0,.06,1.6+n*.42);waves.push(a);}}
 if(s.rainProps){const rainmat=new THREE.MeshBasicMaterial({color:'#b8dce5',transparent:true,opacity:.65,side:THREE.DoubleSide});for(let n=0;n<36;n++){const a=mesh(new THREE.PlaneGeometry(.022,.16+(n%3)*.04),rainmat,-5+(n*1.618)%10,1+n%4,-1+(n%5)*.75);a.rotation.z=-.15;a.castShadow=false;rains.push(a);}}
 if(s.birdJourney){const bird=actors.find(a=>a.data.asset==='pomba');if(bird){const sh=new THREE.Shape();sh.moveTo(0,0);sh.quadraticCurveTo(.18,.25,.36,.11);sh.quadraticCurveTo(.2,-.04,0,0);leaf=mesh(new THREE.ShapeGeometry(sh),green,.38,.4,.04,bird.pivot);}}
 if(s.rainbowProps){rainbow=new THREE.Group();rainbow.position.set(0,1.4,-2.45);g.add(rainbow);const colors=['#df9d92','#e7ba82','#edd997','#abc49a','#8fbec2','#9eacd0','#b5a3c3'];colors.forEach((c,i)=>{const r=3.2-i*.14,sh=new THREE.Shape();sh.absarc(0,0,r,0,Math.PI,false);sh.absarc(0,0,r-.14,Math.PI,0,true);sh.closePath();mesh(new THREE.ShapeGeometry(sh),mat(c),0,0,0,rainbow);});}
 if(s.gardenProps)for(let n=0;n<10;n++){const x=-4.5+n*.95,z=2.5+(n%2)*.2;box(.02,.25,.02,green,x,.15,z);mesh(new THREE.CircleGeometry(.11,6),n%2?cream:gold,x,.34,z+.01);}
 return {update(t,closing){g.scale.y=Math.max(.001,smooth((t-.25)/1.2)*closing);if(doorPivot)doorPivot.rotation.y=s.rainProps?-1.4*(1-smooth((t-1)/2)):s.birdJourney?0:-1.4;if(ark){if(s.arkBuild){hull.scale.y=Math.max(.001,smooth((t-2)/4));wall.scale.y=Math.max(.001,smooth((t-6)/4));structure.scale.y=Math.max(.001,smooth((t-6)/4));structure.visible=t>=6;wall.visible=t>=6;roof.visible=t>=10;roof.scale.y=Math.max(.001,smooth((t-10)/4));}if(s.arkCutaway){const q=smooth((t-3)/4);wall.rotation.x=q*1.25;roof.rotation.x=-q*1.1;}if(s.arkFloat){const q=smooth((t-3)/5);ark.position.y=(.15+Math.sin(t*.65)*.06)*q;ark.rotation.z=Math.sin(t*.5)*.015*q;}}
 waves.forEach((a,n)=>{a.position.y=.08+Math.sin(t*.8+n)*.035;a.position.x=Math.sin(t*.5+n)*.12;});rains.forEach((a,n)=>{a.visible=t>3&&t<(s.sourceDuration||s.duration)-2;a.position.y=5-((t*.8+n*.163)%4.8);});if(leaf)leaf.visible=t>13;if(rainbow)rainbow.scale.y=Math.max(.001,smooth((t-5)/5));if(calendar)calendar.rotation.y=Math.sin(t*.5)*.08;
 }};
}
