# A Arca de Noé — videoclipe em livro pop-up

Canção original “Arca de Noé”, fornecida pelo usuário, na íntegra. Duração aproximada de 4min02s (242,458333 s), horizontal 1280 × 720, 24 fps, H.264 e AAC estéreo. Somente a canção, sem narrador adicional ou efeitos sobrepostos.

## Assistir

Abra `output/noe-videoclipe.mp4`. No ZIP para assistir, extraia e abra `alves-pop-up/ASSISTA-AQUI.mp4`. Não é necessário executar `.cmd` ou instalar o gerador.

## Montagem

26 trechos com variações reais de câmera 3D, movimentos suaves acompanhando pulsações musicais estimadas, construção da arca, animais em pares, interiores, chuva delicada, pomba e arco-íris. A capa aparece brevemente depois da abertura visual. Livro sobre mesa trabalhada em uma sala decorada. Encerramento de 20 segundos com marca, convite à inscrição e indicação da canção Uma Noite com Leões. Não há cenas de afogamento, violência ou destruição.

A montagem temática considera a letra embutida nos metadados da música. O andamento e as pulsações foram estimados por fluxo espectral, sem alinhamento palavra por palavra e sem legendas de karaokê.

## Arquivos

- `stories/joao.json`: roteiro principal do motor; nome mantido por compatibilidade. Cópia em `stories/noe-videoclipe.json`.
- `references/montagem-videoclipe.json`: tempos dos 26 trechos e intervalos das ações originais.
- `references/letra-musica-fornecida.txt`: letra extraída do arquivo fornecido.
- `references/roteiro-fornecido.txt`: roteiro da história narrada que originou os cenários. O videoclipe utiliza apenas a canção.
- `assets/noe/`: personagens, animais e cenários de papel; recortes em `engine/story.mjs`.
- `engine/noe-props.mjs`: arca articulada, porta, rampa, compartimentos, alimentação, ondas, chuva, pomba, folha de oliveira e arco-íris.
- `assets/musica/arca-noe.mp3`: original preservado, sem cortes, repetição ou substituição do vocal.
- `publicacao/`: capa, título, descrição, letra e duas miniaturas identificadas como VIDEOCLIPE.

## Editar e exportar

Requer Node.js 22+, Chrome/Chromium/Edge e FFmpeg. Execute `npm ci` e `npm start` para visualizar. Exporte com `npm run render:fast -- --out output/noe-videoclipe.mp4`. Use `CHROME_PATH` e `FFMPEG_PATH` se necessário. Nenhuma chave é necessária: a geração Noiz está desativada e a música já acompanha o projeto.

## Créditos

Contos de Gaitolé: YouTube @gaitolé e TikTok @gaitole0. Música e letra fornecidas pelo usuário; referência bíblica em Gênesis 6–9. Licença e avisos originais Mira preservados em LICENSE-MIRA e vendor. Nenhum teste A/B ou publicação no YouTube foi executado.
