// Preparação e armazenamento comuns aos provedores. Nenhuma chave entra no roteiro.
import {readFile,writeFile,mkdir,rename,rm,open} from 'node:fs/promises';
import {join,resolve} from 'node:path';
import {createHash,randomUUID} from 'node:crypto';
import {spawn} from 'node:child_process';
import {totalDuration} from '../engine/end-card.mjs';
const sha=data=>createHash('sha256').update(data).digest('hex');
export function episodeMusicPlan(story){
 if(!story.title||!Array.isArray(story.scenes)||!story.scenes.length)throw Error('Roteiro sem título ou cenas');
 const duration=totalDuration(story);
 if(!Number.isFinite(duration)||duration<=0||duration>1800)throw Error('Duração musical inválida');
 const style=story.musicGeneration?.style||'Gentle acoustic storybook score, soft piano, plucked strings, flute, celesta and warm light percussion, calm tempo, friendly wonder, subtle suspense resolving to joy.';
 const synopsis=story.scenes.map(s=>s.caption).join('\n');
 const prompt=`Original instrumental background score for the children's story “${story.title}”, for Contos de Gaitolé.\n${style}\nNo singing, no vocals, no choir, no spoken words. Keep the music gentle under a Brazilian Portuguese narrator. Natural opening and closing, no abrupt changes. Target length: ${Math.ceil(duration)} seconds.\nStory for musical inspiration only; do not sing or speak this text:\n${synopsis}`;
 const plan={version:1,provider:story.musicGeneration?.provider||"noiz",title:story.title,duration:Math.ceil(duration),instrumental:true,style,prompt};
 return {...plan,hash:sha(JSON.stringify(plan))};
}
function run(command,args){return new Promise((yes,no)=>{const child=spawn(command,args,{stdio:['ignore','ignore','pipe']});let err='';child.stderr.on('data',b=>{err=(err+b.toString()).slice(-1000)});child.on('error',()=>no(Error('FFmpeg não encontrado para preparar a música')));child.on('exit',code=>code===0?yes():no(Error('O áudio recebido não pôde ser convertido pelo FFmpeg')));});}
export async function musicStatus(root){
 const story=JSON.parse(await readFile(join(root,'stories/joao.json'),'utf8')),plan=episodeMusicPlan(story);
 try{const m=JSON.parse(await readFile(join(root,'assets/musica/episodio.json'),'utf8'));if(m.hash!==plan.hash||!/^assets\/musica\/[a-zA-Z0-9_-]+\.mp3$/.test(m.file))throw Error();const audio=await readFile(join(root,m.file));if(sha(audio)!==m.audioHash)throw Error();return {enabled:story.musicGeneration?.enabled===true,ready:true,provider:m.provider,title:story.title,duration:plan.duration};}catch{return {enabled:story.musicGeneration?.enabled===true,ready:false,title:story.title,duration:plan.duration};}
}
// Provider contract: generate(plan,{workDir}) returns {audioPath,provider}.
// Adapters must use the provider's documented API; never assume URL/schema.
export async function ensureEpisodeMusic(root,{generate}={}){
 root=resolve(root);const storyPath=join(root,'stories/joao.json');
 const story=JSON.parse(await readFile(storyPath,'utf8'));
 if(story.musicGeneration?.enabled!==true)return {changed:false,enabled:false};
 const plan=episodeMusicPlan(story),folder=join(root,'assets/musica');await mkdir(folder,{recursive:true});
 const lockPath=join(folder,'.generation.lock');let lock;
 try{lock=await open(lockPath,'wx');}catch{throw Error('Já existe uma geração de música neste episódio. Aguarde; se ela foi interrompida, verifique o processo antes de remover assets/musica/.generation.lock.');}
 let workDir;
 try{
  await lock.writeFile(JSON.stringify({pid:process.pid,started:new Date().toISOString()}));
  const status=await musicStatus(root);
  if(status.ready){const m=JSON.parse(await readFile(join(folder,'episodio.json'),'utf8'));if(story.music?.file===m.file)return {...status,changed:false};story.music={...defaults,...story.music,file:m.file,title:'Trilha original — '+story.title};await writeStory(storyPath,story);return {...status,changed:true};}
  if(!generate)throw Error('O provedor de música ainda não foi configurado. A trilha anterior foi preservada.');
  workDir=join(folder,'.music-work-'+randomUUID());await mkdir(workDir);
  await writeFile(join(workDir,'pedido.json'),JSON.stringify(plan,null,2)+'\n');
  const result=await generate(plan,{workDir});
  if(!result?.audioPath||typeof result.provider!=='string')throw Error('O provedor não retornou um arquivo de áudio válido');
  const file='assets/musica/episodio-'+plan.hash.slice(0,16)+'.mp3',converted=join(workDir,'final.mp3');
  // Repeat short music; cap exact episode duration and fade. Never alter the source Gaitolé track.
  await run(process.env.FFMPEG_PATH||'ffmpeg',['-v','error','-nostdin','-y','-stream_loop','-1','-i',result.audioPath,'-t',String(plan.duration),'-vn','-af',`afade=t=in:d=1,afade=t=out:st=${Math.max(0,plan.duration-2)}:d=2`,'-ar','48000','-ac','2','-codec:a','libmp3lame','-b:a','192k',converted]);
  const data=await readFile(converted);if(data.length<1024)throw Error('A música gerada está vazia');
  // Recheck before mutating a story that may have changed during generation.
  const latest=JSON.parse(await readFile(storyPath,'utf8'));
  if(episodeMusicPlan(latest).hash!==plan.hash||latest.musicGeneration?.enabled!==true)throw Error('O roteiro mudou durante a geração. A trilha anterior foi preservada.');
  await rename(converted,join(root,file));
  const manifest={...plan,file,provider:result.provider,...(Number.isFinite(result.sourceDuration)?{sourceDuration:result.sourceDuration}:{}),...(Number.isInteger(result.variants)?{variants:result.variants}:{}),audioHash:sha(data),created:new Date().toISOString()};
  const temp=join(folder,'episodio.json.partial');await writeFile(temp,JSON.stringify(manifest,null,2)+'\n');await rename(temp,join(folder,'episodio.json'));
  latest.music={...defaults,...latest.music,file,title:'Trilha original — '+latest.title};await writeStory(storyPath,latest);
  return {changed:true,enabled:true,ready:true,provider:result.provider};
 }finally{if(workDir)await rm(workDir,{recursive:true,force:true});await lock.close();await rm(lockPath,{force:true});}
}
const defaults={volume:.18,duckVolume:.035,attack:.35,release:.7,fadeIn:1,fadeOut:2};
async function writeStory(path,story){const temp=path+'.music.partial';await writeFile(temp,JSON.stringify(story,null,2)+'\n');await rename(temp,path);}
