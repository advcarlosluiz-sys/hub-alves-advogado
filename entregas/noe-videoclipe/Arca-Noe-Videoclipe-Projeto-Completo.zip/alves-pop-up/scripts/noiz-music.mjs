// Contrato verificado por tools/list em https://noiz.ai/v1/mcp.
import {readFile,writeFile,mkdir,rename} from 'node:fs/promises';
import {join} from 'node:path';
import {connectNoiz,httpRequest} from './noiz-discover.mjs';
const delay=ms=>new Promise(r=>setTimeout(r,ms));
export function noizMusicArguments(plan){
 const instrumental=plan.instrumental!==false;
 const suffix=instrumental?'\nInstrumental only. No vocals, choir or spoken words. Gentle background under narration.':'\nSing the supplied original lyrics naturally in Brazilian Portuguese. Warm clear female singing, family-friendly.';
 const args={prompt:(plan.prompt.slice(0,1500-suffix.length)+suffix),instrumental,title:plan.title.slice(0,80),target_duration:plan.duration<=60?60:plan.duration<=120?120:180};
 if(!instrumental){if(typeof plan.lyrics!=='string'||!plan.lyrics.trim()||plan.lyrics.length>5000)throw Error('Letra ausente ou acima do limite da Noiz');args.lyrics=plan.lyrics;args.vocal_gender='Female';}
 return args;
}

function toolData(result){
 if(result.isError)throw Error('A Noiz recusou a operação musical. Verifique a conta e os créditos.');
 if(result.structuredContent)return result.structuredContent;
 for(const item of result.content||[])if(item.type==='text'){try{const data=JSON.parse(item.text);if(data&&typeof data==='object')return data;}catch{}}
 throw Error('A Noiz retornou um resultado musical inesperado');
}
function validateAudioUrl(value){const u=new URL(value);if(u.protocol!=='https:'||u.username||u.password||u.port&&u.port!=='443'||!(u.hostname==='noiz.ai'||u.hostname.endsWith('.noiz.ai')||u.hostname==='storage.googleapis.com'))throw Error('Domínio de áudio não reconhecido. Confira a URL do provedor e libere somente o domínio de armazenamento confirmado.');return u;}
export async function downloadNoizAudio(url,path,{request=httpRequest}={}){
 for(let redirects=0;redirects<4;redirects++){
  const u=validateAudioUrl(url);
  // Nunca encaminhar Authorization nem sessão MCP ao armazenamento de áudio.
  const r=await request(u.href,{method:'GET',headers:{Accept:'audio/*, application/octet-stream'},timeout:90000,maxBytes:80*1024*1024,binary:true});
  if([301,302,303,307,308].includes(r.status)&&r.headers.location){url=new URL(r.headers.location,u).href;continue;}
  if(r.status!==200||!r.data||r.data.length<1024)throw Error('Não foi possível baixar a música da Noiz. A geração anterior será retomada sem novo pedido.');
  await writeFile(path,r.data);return;
 }throw Error('Redirecionamentos demais no download da Noiz');
}
export function createNoizMusicProvider(root,{connect=connectNoiz,download=downloadNoizAudio,sleep=delay,timeoutMs=15*60*1000,pollMs=10000}={}){
 return async(plan,{workDir})=>{
  const folder=join(root,'.noiz-private');await mkdir(folder,{recursive:true});
  const path=join(folder,plan.hash+'.json');let job;
  try{job=JSON.parse(await readFile(path,'utf8'));}catch(e){if(e.code!=='ENOENT')throw Error('Estado privado da geração inválido; confira antes de iniciar outra cobrança.');}
  if(job?.phase==='submitting')throw Error('O envio anterior à Noiz ficou sem confirmação. Verifique o histórico da conta antes de iniciar uma nova geração.');
  const client=await connect();
  async function save(value){const temp=path+'.partial';await writeFile(temp,JSON.stringify(value,null,2)+'\n',{mode:0o600});await rename(temp,path);}
  async function call(name,args){
   const result=await client.send('tools/call',{name,arguments:args});
   if(result.isError){
    if(name==='generate_music')await save({phase:'rejected',hash:plan.hash});
    const text=(result.content||[]).filter(c=>c.type==='text').map(c=>c.text).join(' ');
    const credit=text.match(/checked against (\d+) credits[\s\S]*?balance is (\d+)/i);
    if(credit)throw Error('Saldo Noiz: '+credit[2]+' créditos; pedido requer '+credit[1]+'. Atualize o saldo na sua conta antes de tentar novamente.');
    throw Error('A Noiz recusou a operação musical. Nenhuma nova tentativa automática foi enviada. Confira a conta e os créditos.');
   }
   return toolData(result);
  }
  if(!job||job.phase==='rejected'){
   const tools=(await client.send('tools/list',{})).tools||[];
   const create=tools.find(t=>t.name==='generate_music'),poll=tools.find(t=>t.name==='get_music_result');
   if(!create?.inputSchema?.properties?.instrumental||!create.inputSchema.properties.target_duration||!poll?.inputSchema?.properties?.gen_product_id)throw Error('O contrato musical da Noiz mudou. Atualize a integração antes de gerar.');
   await save({phase:'submitting',hash:plan.hash});
   const result=await call('generate_music',noizMusicArguments(plan));
   if(!Array.isArray(result.gen_product_ids)||!result.gen_product_ids.length||result.gen_product_ids.some(x=>typeof x!=='string'||!x||x.length>300))throw Error('A Noiz não confirmou os identificadores da geração. Verifique o histórico da conta antes de repetir.');
   job={phase:'running',hash:plan.hash,ids:result.gen_product_ids};await save(job);
  }
  if(job.hash!==plan.hash||!Array.isArray(job.ids)||!job.ids.length)throw Error('Estado da geração musical não corresponde ao episódio.');
  const start=Date.now();
  while(Date.now()-start<timeoutMs){
   let failed=0;
   for(const id of job.ids){
    const result=await call('get_music_result',{gen_product_id:id});
    if(result.status==='failed'){failed++;continue;}
    if(result.status==='succeeded'&&typeof result.audio_url==='string'){
     const audioPath=join(workDir,'noiz-source.audio');await download(result.audio_url,audioPath);return {audioPath,provider:'noiz',sourceDuration:result.duration_seconds,variants:job.ids.length};
    }
    if(!['submitted','running','succeeded'].includes(result.status))throw Error('Estado musical inesperado da Noiz; o pedido existente foi preservado.');
   }
   if(failed===job.ids.length)throw Error('As variantes musicais falharam na Noiz. Confira o histórico da conta; nenhum novo pedido foi enviado.');
   await sleep(pollMs);
  }
  throw Error('A Noiz ainda está gerando. Tente novamente para retomar o mesmo pedido, sem enviar outra geração.');
 };
}
