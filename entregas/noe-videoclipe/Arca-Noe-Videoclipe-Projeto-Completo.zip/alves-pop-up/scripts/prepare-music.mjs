import {ensureEpisodeMusic} from './episode-music.mjs';
import {createNoizMusicProvider} from './noiz-music.mjs';
import {resolve} from 'node:path';
import {fileURLToPath} from 'node:url';
export const prepareEpisodeMusic=root=>ensureEpisodeMusic(root,{generate:createNoizMusicProvider(root)});
if(process.argv[1]&&resolve(process.argv[1])===fileURLToPath(import.meta.url)){
 const i=process.argv.indexOf('--deck'),root=resolve(i<0?fileURLToPath(new URL('../',import.meta.url)):process.argv[i+1]);
 try{const result=await prepareEpisodeMusic(root);console.log(result.enabled?(result.changed?'Trilha Noiz preparada e incluída no episódio.':'Trilha do episódio já está pronta. Nenhuma nova geração foi enviada.'):'Este episódio usa a música fornecida no roteiro.');}catch(e){console.error(e.message);process.exitCode=1;}
}
