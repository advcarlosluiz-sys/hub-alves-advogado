# Um Pouquinho Vira Muito — videoclipe em livro pop-up

Canção enviada pelo usuário na íntegra, aproximadamente 4min02s (242,4583 segundos de vídeo; faixa original 242,424 segundos). Horizontal 1280 × 720, 24 fps, H.264/AAC estéreo. A canção mantém seu vocal original, sem narrador adicional ou efeitos sonoros sobrepostos.

## Assistir

Abra `output/paes-videoclipe.mp4`. No ZIP para assistir, extraia tudo e abra `alves-pop-up/ASSISTA-AQUI.mp4`. Não precisa executar `.cmd` ou instalar o gerador para assistir.

## Montagem

28 trechos com variações de câmera 3D e movimentos suaves próximos às pulsações estimadas da música. Livro com capa verde e dourada, mesa trabalhada e sala com estantes, janela, planta e luminária. Jesus, menino, André, famílias, crianças e idosos; campo, lago, cestas articuladas, ação de graças, distribuição e refeição. Exatamente cinco pães e dois peixes nas cenas do lanche antes do milagre. Doze cestos de sobras em três filas de quatro aparecem na parte final.

A montagem temática usa a letra embutida no MP3 e a pulsação estimada por fluxo espectral. Não há alinhamento de palavras ou marcação exata das seções vocais. Não é karaokê. A letra completa acompanha o kit. O encerramento mostra marca, perfis, inscrição e indicação musical de “Um Caminho no Mar”, de Moisés.

## Arquivos

- `stories/joao.json`: roteiro principal, nome mantido por compatibilidade. Cópia em `stories/paes-videoclipe.json`.
- `references/montagem-videoclipe.json`: tempos dos 28 trechos e intervalos de ações de origem.
- `references/letra-musica-fornecida.txt`: letra extraída dos metadados da canção.
- `references/roteiro-fornecido.txt`: roteiro da história que originou as cenas; o clipe utiliza somente a canção.
- `assets/paes/`: atlas de personagens e cenários WebP sem perdas, reutilizados da história narrada; recortes em `engine/story.mjs`.
- `engine/paes-props.mjs`: peças separadas de alimento, tampas, distribuição e doze cestos articulados.
- `assets/musica/um-pouquinho-vira-muito.mp3`: original preservado sem cortes, repetição ou substituição do vocal.
- `publicacao/`: capa, letra, título, descrição e miniaturas com indicação VIDEOCLIPE.

## Editar e exportar

Requer Node.js 22+, Chrome/Chromium/Edge e FFmpeg. Execute `npm ci` e `npm start` para visualizar. Exporte com `npm run render:fast -- --out output/paes-videoclipe.mp4`. Use `CHROME_PATH` e `FFMPEG_PATH` se necessário. A geração Noiz está desativada; a canção incluída permite exportar sem chave.

## Créditos

Contos de Gaitolé: YouTube @gaitolé; TikTok @gaitole0. Música e letra enviadas pelo usuário, inspiradas em João 6:1–13. Artes e mecanismos de papel preparados para a história de Jesus e os Cinco Pães e Dois Peixinhos. Licença e avisos originais do Mira preservados em LICENSE-MIRA e vendor. Nenhum teste A/B de desempenho nem publicação no YouTube foi realizado.
