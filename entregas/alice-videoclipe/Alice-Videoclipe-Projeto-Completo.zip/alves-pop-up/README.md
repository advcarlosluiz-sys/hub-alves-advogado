# Alice no País das Maravilhas — videoclipe

Videoclipe em livro pop-up para o Contos de Gaitolé, usando a canção **Alice v2** fornecida pelo usuário. Duração aproximada: **4min40s**, horizontal **1280 × 720**, **24 fps**, H.264/AAC estéreo. A canção inteira é o único áudio desta versão.

## Assistir

Abra `output/alice-videoclipe.mp4`. No ZIP para assistir, extraia a pasta e abra `alves-pop-up/ASSISTA-AQUI.mp4`. Não requer executar `.cmd`.

## Projeto

- `stories/joao.json`: arquivo principal do motor, mantido com esse nome por compatibilidade; cópia nomeada em `stories/alice-videoclipe.json`.
- `references/montagem-videoclipe.json`: 25 trechos, câmeras e tempos de montagem.
- `references/analise-musical.json`: estimativa de andamento e entradas musicais detectadas por análise espectral; os cortes se aproximam dessas entradas. Não representa transcrição da letra.
- `assets/alice/`: ilustrações originais. Recortes em `engine/story.mjs`.
- `engine/alice-props.mjs`: objetos e ações animadas.
- `assets/musica/alice-v2.mp3`: arquivo original fornecido, preservado.
- `publicacao/`: miniatura, capa, título e descrição.

As animações são aceleradas suavemente para caber em cada trecho, com variações de câmera e movimentos discretos associados às entradas musicais. A abertura mostra a capa sobre a mesa da sala; o encerramento traz a marca e os perfis do canal. Não há narrador, efeitos sonoros externos nem legendas da história falada nesta versão.

## Editar e exportar

Requer Node.js 22+, Chrome/Chromium/Edge e FFmpeg. Execute `npm ci` para instalar as dependências. Use `npm start` para visualizar no endereço local mostrado e `npm run render:fast -- --out output/alice-videoclipe.mp4` para exportar. `CHROME_PATH` e `FFMPEG_PATH` permitem indicar os programas instalados. Os áudios existentes dispensam chave de API; a geração Noiz está desativada.

## Créditos

Adaptação visual original inspirada no conto de Lewis Carroll. Contos de Gaitolé: YouTube @gaitolé, TikTok @gaitole0. Avisos e licença de Mira preservados em LICENSE-MIRA e vendor.
