# Rei Midas e o Toque de Ouro

REI MIDAS E O TOQUE DE OURO — CONTOS DE GAITOLÉ

PARA ASSISTIR
Extraia todo o ZIP e abra output/rei-midas-instrumental.mp4.
No pacote para assistir, o mesmo vídeo se chama ASSISTA-AQUI.mp4.
Não é necessário executar arquivos .cmd. Voz, música, efeitos e legendas estão no MP4.

DURAÇÃO E FORMATO
4min27s, horizontal 16:9, 1280 x 720, 24 quadros/s.
H.264 com áudio AAC estéreo.

PARA PUBLICAR
publicacao/miniatura-youtube.jpg tem 1280 x 720 pixels.
publicacao/titulo.txt e descricao.txt estão prontos para copiar.

PARA EDITAR
Motor de livro pop-up 3D do Mira com Three.js e GSAP locais.
O roteiro ativo é stories/joao.json: o nome é herdado, mas o conteúdo é Rei Midas.
A cópia identificada está em stories/rei-midas.json.
Node.js 22+, Chrome/Edge e servidor local são necessários somente para editar/exportar.
Com Node instalado: node scripts/serve.mjs
Depois de alterar o roteiro ativo:
node scripts/narrate.mjs
node scripts/subtitles.mjs
node scripts/effects.mjs
Abra o endereço do servidor e clique em Exportar MP4.

CRÉDITOS
Adaptação original do mito tradicional com o roteiro fornecido pelo autor.
Ilustrações originais criadas para esta produção.
Voz pt-BR-ThalitaMultilingualNeural, ritmo -12%, tom -4Hz.
Marca e música fornecidas pelo autor.
O arquivo original “Midas 2 Instrumental.mp3” foi preservado integralmente em assets/musica/midas-2-instrumental.mp3.
A música acompanha os 4min27s do vídeo, com fade suave no final e redução automática de volume durante a narração.
