# Cadê Minha Ovelhinha! — A Ovelha Perdida — videoclipe

Canção original enviada pelo autor, na íntegra, aproximadamente 2min55s. Vídeo de 175,375 segundos; arquivo musical de 175,344 segundos. Horizontal 1280 × 720, 24 fps, H.264/AAC estéreo. Vocal original da canção, sem narrador adicional ou efeitos sonoros sobrepostos.

## Assistir

Abra `output/ovelha-videoclipe.mp4`. No ZIP para assistir, extraia tudo e abra `alves-pop-up/ASSISTA-AQUI.mp4`. Não precisa executar .cmd ou instalar o gerador para assistir.

## Montagem e apresentação

24 trechos com variações de câmera 3D, enquadramentos próximos e movimentos suaves. Capa verde-sálvia e dourada sobre mesa de madeira trabalhada em sala decorada. Cenários e personagens de papel em camadas, com sombras. Pastor em poses de busca, acolhimento e levando a ovelha nos ombros. Colinas, árvores, riacho, flores, trilha, vila e arbusto com duas abas articuladas.

A busca progride para o reencontro, retorno e celebração. Após o reencontro, a protagonista permanece acolhida; os refrões retomam enquadramentos, sem fazê-la desaparecer novamente. As trocas de pose não duplicam o pastor ou a ovelha. Jesus aparece como contador da parábola em página distinta da história do pastor. Os números 100 e 99 são representações do total narrado, sem simular contagem de um rebanho inteiro na tela.

Cortes próximos às pulsações estimadas por fluxo espectral (aproximadamente 100,3 BPM), com montagem temática baseada na letra dos metadados do MP3. Não há alinhamento por palavra nem marcação exata de seções vocais; não é karaokê. Ações e movimentos delicados têm relógios separados. Enquadramentos consecutivos na mesma página conservam os elementos levantados, sem uma virada desnecessária a cada corte.

Encerramento com capa, marca Contos de Gaitolé, YouTube @gaitolé, TikTok @gaitole0, convite à inscrição e indicação musical de “Calma, Ventania!”. A canção toca completa, uma vez, sem repetição; os 31 ms finais completam o último quadro. A produção narrada original foi preservada em seu próprio projeto.

## Arquivos

- stories/joao.json: roteiro principal, nome por compatibilidade. Cópia em stories/ovelha-videoclipe.json.
- references/montagem-videoclipe.json: tempos dos 24 trechos, câmeras e intervalos de ações.
- references/letra-musica-fornecida.txt: letra extraída dos metadados do MP3 enviado.
- references/roteiro-fornecido.txt: roteiro narrado que originou as cenas; não integra a trilha deste videoclipe.
- assets/ovelha/: ilustrações originais do pastor, ovelha e cenários, WebP sem perdas.
- assets/elenco/: ilustrações originais de Jesus e ouvintes, com recortes em engine/story.mjs.
- engine/ovelha-props.mjs: mecanismos e cenário de papel 3D.
- assets/musica/cade-minha-ovelhinha.mp3: original preservado, sem cortes, repetição ou substituição do vocal.
- publicacao/: capa, letra, título, descrição e duas miniaturas 1280 × 720 com indicação VIDEOCLIPE.

## Editar e exportar

Requer Node.js 22+, Chrome/Chromium/Edge e FFmpeg. Execute `npm ci` e `npm start`. Exporte com `npm run render:fast -- --out output/ovelha-videoclipe.mp4`. Use CHROME_PATH e FFMPEG_PATH se necessário. A geração Noiz está desativada; não é necessária chave para exportar este clipe.

## Créditos

Contos de Gaitolé, YouTube @gaitolé, TikTok @gaitole0. Canção e roteiro de origem enviados pelo autor. Referência: Lucas 15:3–7. Artes e mecanismos reutilizados e adaptados da história narrada “Cadê Minha Ovelhinha!”. Licença e avisos do Mira preservados em LICENSE-MIRA e vendor. Nenhum teste A/B de desempenho ou publicação no YouTube foi realizado.
