import {
  cpSync,
  existsSync,
  mkdirSync,
  readFileSync,
  writeFileSync,
} from "node:fs";
import { resolve, join } from "node:path";
import { fileURLToPath } from "node:url";
import { createHash } from "node:crypto";
import { introDuration } from "../engine/end-card.mjs";
import { validateStory } from "../engine/story.mjs";
export const ROOT = fileURLToPath(new URL("../", import.meta.url));
export function createDeck(
  destination,
  storyFile = join(ROOT, "stories/joao.json"),
) {
  const dest = resolve(destination);
  if (existsSync(dest)) throw Error("Destino já existe: " + dest);
  const story = validateStory(JSON.parse(readFileSync(storyFile, "utf8")));
  story.presentation ??= { introDuration: 7, cameraScale: 1.12 };
  mkdirSync(dest, { recursive: true });
  for (const path of [
    "index.html",
    ".gitignore",
    "LICENSE-MIRA",
    "engine",
    "assets",
    "vendor",
    "stories",
    "scripts",
    "package.json",
    "package-lock.json",
    "plugin",
    "COMECE-AQUI.txt",
    "COMECE-AQUI-VIDEO.txt",
    "GERAR-VOZ-THALITA.cmd",
    "GERAR-VOZ-THALITA.command",
    "README.md",
    "ABRIR-LIVRO.cmd",
    "ABRIR-LIVRO.command",
    "SALVAR-TUDO-ZIP.cmd",
    "SALVAR-TUDO-ZIP.command",
    "EXPORTAR-MP4.cmd",
  ]) {
    mkdirSync(resolve(dest, path, ".."), { recursive: true });
    cpSync(join(ROOT, path), join(dest, path), { recursive: true });
  }
  if (existsSync(join(ROOT, "publicacao"))) cpSync(join(ROOT,"publicacao"),join(dest,"publicacao"),{recursive:true});
  // Reutiliza a voz somente quando os textos e a cadência correspondem.
  const manifestPath=join(dest,"assets/narracao/manifest.json");
  if (existsSync(manifestPath) && story.narration) {
    const manifest=JSON.parse(readFileSync(manifestPath,"utf8"));
    const config=story.narration;
    const matching=manifest.voice===config.voice && manifest.clips?.length===story.scenes.length && story.scenes.every(scene=>{
      const hash=createHash("sha256").update([scene.caption,config.voice,config.rate,config.pitch].join("|")).digest("hex");
      return manifest.clips.some(c=>c.scene===scene.id && c.hash===hash);
    });
    if(matching){let offset=introDuration(story);for(const scene of story.scenes){const clip=manifest.clips.find(c=>c.scene===scene.id);clip.offset=offset+2;offset+=scene.duration;}manifest.duration=story.duration;writeFileSync(manifestPath,JSON.stringify(manifest,null,2)+"\n");}
  }
  writeFileSync(
    join(dest, "stories/joao.json"),
    JSON.stringify(story, null, 2) + "\n",
  );
  mkdirSync(join(dest, "references"));
  return dest;
}
if (
  process.argv[1] &&
  resolve(process.argv[1]) === fileURLToPath(import.meta.url)
) {
  try {
    const args = process.argv.slice(2);
    if (!args[0])
      throw Error(
        "Uso: node scripts/create.mjs decks/nome [--story roteiro.json]",
      );
    const i = args.indexOf("--story");
    console.log(createDeck(args[0], i < 0 ? undefined : args[i + 1]));
  } catch (e) {
    console.error(e.message);
    process.exitCode = 1;
  }
}
