import http from "node:http";
import { readFile, stat, realpath, mkdir, writeFile, rename } from "node:fs/promises";
import { fileURLToPath } from "node:url";
import { resolve, sep, extname, join } from "node:path";
export function startServer(
  root = fileURLToPath(new URL("../", import.meta.url)),
  port = 8137,
) {
  const types = {
    ".html": "text/html; charset=utf-8",
    ".js": "text/javascript",
    ".mjs": "text/javascript",
    ".json": "application/json",
    ".svg": "image/svg+xml",
    ".png": "image/png",
    ".mp4": "video/mp4",
    ".css": "text/css",
  };
  const server = http.createServer(async (req, res) => {
    try {
      const path = decodeURIComponent(
        new URL(req.url, "http://localhost").pathname,
      );
      if (path === "/save-export" && req.method === "POST") {
        if (req.headers.origin && req.headers.origin !== "http://" + req.headers.host) {res.writeHead(403);return res.end();}
        if (req.headers["content-type"] !== "video/mp4") {res.writeHead(415);return res.end("Formato de vídeo inválido");}
        const chunks=[];let size=0;
        for await (const chunk of req) {size+=chunk.length;if(size>512*1024*1024){res.writeHead(413);return res.end("Vídeo acima de 512 MB");}chunks.push(chunk);}
        const data=Buffer.concat(chunks);
        if(data.length<24 || data.toString("ascii",4,8)!=="ftyp"){res.writeHead(400);return res.end("MP4 inválido");}
        const folder=join(root,"output");await mkdir(folder,{recursive:true});
        const temp=join(folder,"exportado-no-aplicativo.mp4.partial");
        await writeFile(temp,data);await rename(temp,join(folder,"exportado-no-aplicativo.mp4"));
        res.writeHead(200,{"Content-Type":"text/plain; charset=utf-8"});return res.end("MP4 incluído no projeto local");
      }
      if (req.method !== "GET" && req.method !== "HEAD") {res.writeHead(405);return res.end();}
      if (path === "/download-project" || path === "/download-media") {
        if (req.method === "HEAD") {res.writeHead(200,{"Content-Type":"application/zip"});return res.end();}
        try {
          const {packageZip}=await import("./package.mjs");
          const result=packageZip(root,undefined,path === "/download-media");
          const data=await readFile(result.path);
          res.writeHead(200,{"Content-Type":"application/zip","Content-Disposition":'attachment; filename="alves-pop-up-'+(path==="/download-media"?"assistir":"completo")+'.zip"',"Cache-Control":"no-store"});
          return res.end(data);
        } catch(error) {res.writeHead(409,{"Content-Type":"text/plain; charset=utf-8"});return res.end(error.message);}
      }
      const target = await realpath(
        resolve(root, "." + (path === "/" ? "/index.html" : path)),
      );
      if (!target.startsWith((await realpath(root)) + sep)) {
        res.writeHead(403);
        return res.end();
      }
      if (!(await stat(target)).isFile()) {
        res.writeHead(404);
        return res.end();
      }
      const data = await readFile(target);
      res.writeHead(200, {
        "Content-Type": types[extname(target)] || "application/octet-stream",
        "Cache-Control": "no-store",
      });
      res.end(req.method === "HEAD" ? undefined : data);
    } catch {
      res.writeHead(404);
      res.end("Arquivo não encontrado");
    }
  });
  return new Promise((yes, no) => {
    server.once("error", no);
    server.listen(port, "127.0.0.1", () => yes(server));
  });
}
if (
  process.argv[1] &&
  resolve(process.argv[1]) === fileURLToPath(import.meta.url)
) {
  const server = await startServer(
    undefined,
    Number(process.env.POPUP_PORT) || 8137,
  );
  console.log("Livro disponível localmente na porta " + server.address().port);
}
