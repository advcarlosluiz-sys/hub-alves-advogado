# Correção do gerador 0.2.1

Leia ATUALIZAR-NO-MIRA.txt para atualizar uma instalação existente. A atualização preserva os roteiros e cria backup antes de substituir o motor. O teste de exportação foi realizado em Chromium neste ambiente; o Windows do usuário não foi testado.

# Contos de Gaitolé — apresentação com sala e capa

Esta edição do aplicativo inclui um livro com capa, título e abertura animada sobre uma mesa trabalhada. A sala tem estantes, janela, cortinas, abajur, plantas e xícara. As cenas de Chapeuzinho incluem flores, coelho, esquilo, troncos e personagens em camadas.

**Amostra pronta:** `output/amostra-nova-apresentacao.mp4`, com 44 segundos. Abra diretamente no reprodutor do computador. Não é a história completa. Não precisa executar arquivos .cmd para assistir.

**História completa configurada:** 3min14s, incluindo abertura de sete segundos, voz Thalita, música com redução nas falas e encerramento. O roteiro e os áudios completos estão incluídos para a exportação pelo aplicativo.

Este pacote será entregue pelo GitHub por autorização excepcional do autor. A preferência por não publicar futuras produções no GitHub permanece. Baixe o ZIP para guardar uma cópia no computador.

## Usar o aplicativo

Se Node 22+ estiver instalado, abra um terminal na pasta e execute `node scripts/serve.mjs`. Acesse `http://127.0.0.1:8137` no Chrome ou Edge. A reprodução tem voz Thalita. O botão Exportar MP4 exporta a história completa.

Os botões **Baixar projeto ZIP** e **Baixar vídeo em ZIP** geram arquivos locais pelo servidor do aplicativo, sem GitHub. Os ZIPs incluem os vídeos já salvos no projeto. Se você acabou de usar Exportar MP4 nesta sessão, o último vídeo gerado é incluído automaticamente ao clicar no botão de ZIP. Isso usa apenas o servidor local, sem upload para serviços externos.

Para renderização automática com Node, Chromium e FFmpeg instalados:

```
npm ci
node scripts/render-webcodecs.mjs --deck . --out output/chapeuzinho-completo.mp4
```

O nome interno `stories/joao.json` contém Chapeuzinho Vermelho. `presentation.introDuration` controla a abertura; a duração da história continua sendo a soma das cenas. A voz começa depois da abertura. Os MP3s foram preservados; o manifesto e a trilha de efeitos foram deslocados para manter o sincronismo.

Novos projetos criados pelo motor recebem abertura de sete segundos. O título da capa vem do roteiro. `presentation.coverImage` pode apontar para uma ilustração local. Licenças das bibliotecas do Mira foram mantidas.
