let preparing = false;
// O navegador guarda o último MP4 gerado e o inclui no ZIP pelo servidor local.
for (const link of document.querySelectorAll('a[href="/download-project"],a[href="/download-media"]')) {
 link.addEventListener('click',async event=>{
  event.preventDefault();
  if (preparing) return;
  preparing = true;
  const status=document.getElementById('status');
  try {
   status.textContent='Preparando o ZIP para baixar…';
   if(window.popupLastExport){
    const saved=await fetch('/save-export',{method:'POST',headers:{'Content-Type':'video/mp4'},body:window.popupLastExport});
    if(!saved.ok)throw Error(await saved.text());
   }
   const response=await fetch(link.getAttribute('href'));
   if(!response.ok)throw Error(await response.text());
   const blob=await response.blob(),url=URL.createObjectURL(blob),a=document.createElement('a');
   a.href=url;a.download=link.getAttribute('href')==='/download-media'?'gaitole-video.zip':'gaitole-projeto-completo.zip';a.click();
   setTimeout(()=>URL.revokeObjectURL(url),60000);
   status.textContent='ZIP pronto. Confira a pasta Downloads do computador.';
  }catch(error){status.textContent=error.message;}finally{preparing=false;}
 });
}
