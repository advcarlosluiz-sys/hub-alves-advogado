# Daniel na Cova dos Leões — livro pop-up

Adaptação infantil de Daniel 6 para o Contos de Gaitolé. **4min18s**, horizontal **1280 × 720**, **24 fps**, H.264/AAC estéreo. Narração **Thalita em português do Brasil**, legendas por frase e música **Uma Noite com Leões**, fornecida pelo usuário, com redução automática durante as falas.

## Assistir

Abra `output/daniel-leoes.mp4`. No ZIP para assistir, extraia a pasta e abra `alves-pop-up/ASSISTA-AQUI.mp4`. Não requer executar `.cmd`.

## Arquivos

- `stories/joao.json`: roteiro principal do motor, com nome mantido por compatibilidade; cópia em `stories/daniel-leoes.json`.
- `references/roteiro-fornecido.txt`: adaptação original preparada para este episódio.
- `assets/daniel/`: personagens, poses, leões e cenários originais. Recortes em `engine/story.mjs` e `references/assets-originais.json`.
- `engine/daniel-props.mjs`: objetos animados de papel, documento, pedra da entrada, iluminação do anjo, lamparina e detalhes.
- `assets/narracao/`: 13 clipes Thalita, manifestos e legendas por frase.
- `assets/musica/uma-noite-com-leoes.mp3`: arquivo original fornecido, preservado. No vídeo é utilizado como fundo e termina suavemente na duração da história.
- `assets/efeitos/`: ambiente suave e sinal de encerramento.
- `publicacao/`: capa, miniaturas A e B em 1280 × 720, título, descrição e instruções de comparação.

## Abertura e continuidade

O vídeo começa com Daniel e os leões; a pergunta é narrada a partir dos 2 segundos. A capa aparece brevemente no fim do primeiro trecho. O contexto da história começa aos 14 segundos. O encerramento recomenda a história de Davi e Golias e convida à inscrição. Os elementos finais são gráficos do próprio vídeo, sem pressupor recursos interativos do YouTube.

## Editar e exportar

Requer Node.js 22+, Chrome/Chromium/Edge e FFmpeg. Execute `npm ci`, depois `npm start` para visualizar o livro. Para exportar: `npm run render:fast -- --out output/daniel-leoes.mp4`. `CHROME_PATH` e `FFMPEG_PATH` permitem indicar os programas instalados. As vozes existentes já estão incluídas; alterações no texto exigem regenerar a narração e atualizar as legendas. A geração Noiz está desativada: nenhuma chave é necessária para exportar estes arquivos existentes.

## Créditos

Relato bíblico: Daniel 6, adaptação infantil original. Contos de Gaitolé: YouTube @gaitolé e TikTok @gaitole0. Termos e avisos originais de Mira preservados em LICENSE-MIRA e vendor.
