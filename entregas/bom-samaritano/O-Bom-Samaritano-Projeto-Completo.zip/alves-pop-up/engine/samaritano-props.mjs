import * as THREE from '../vendor/three.module.js';

const ease = value => {
  const t = THREE.MathUtils.clamp(value, 0, 1);
  return t*t*(3-2*t);
};
export function buildSamaritanoProps(group, scene, textures) {
  const stage = scene.samaritano;
  const root = new THREE.Group();
  group.add(root);
  const material = color => new THREE.MeshStandardMaterial({color, side:THREE.DoubleSide, roughness:1});
  function mesh(geometry, surface, x, y, z, parent=root) {
    const object = new THREE.Mesh(geometry, surface);
    object.position.set(x,y,z);
    object.castShadow = object.receiveShadow = true;
    parent.add(object);
    return object;
  }
  const box = (w,h,d,color,x,y,z,parent) => mesh(new THREE.BoxGeometry(w,h,d),material(color),x,y,z,parent);
  const card = (key,w,h,x,z) => mesh(new THREE.PlaneGeometry(w,h),new THREE.MeshStandardMaterial({
    map:textures[key], alphaTest:.45, side:THREE.DoubleSide, roughness:1,
  }),x,h/2,z);
  function cutout(points,color,x,y,z) {
    const shape = new THREE.Shape();
    shape.moveTo(...points[0]);
    for(const point of points.slice(1)) shape.lineTo(...point);
    shape.closePath();
    return mesh(new THREE.ExtrudeGeometry(shape,{depth:.028,bevelEnabled:false}),material(color),x,y,z);
  }
  function sign(text,w,x,y,z) {
    const canvas = document.createElement('canvas');
    canvas.width = 960;
    canvas.height = 200;
    const context = canvas.getContext('2d');
    context.fillStyle='#f1e3bc';
    context.fillRect(0,0,960,200);
    context.strokeStyle='#b17d38';
    context.lineWidth=10;
    context.strokeRect(10,10,940,180);
    context.fillStyle='#234d46';
    context.textBaseline='middle';
    context.textAlign='center';
    context.font='bold 86px Georgia';
    context.fillText(text,480,100,887);
    const map = new THREE.CanvasTexture(canvas);
    map.colorSpace=THREE.SRGBColorSpace;
    return mesh(new THREE.PlaneGeometry(w,w/4.8),new THREE.MeshStandardMaterial({map}),x,y,z);
  }
  function room(parent) {
    box(8.8,3.45,.09,'#dfbc8b',0,1.73,-2.5,parent);
    box(1.85,1.29,.11,'#92bfc2',2.95,2.43,-2.4,parent);
    for (const x of [2.05,2.95,3.85]) box(.065,1.35,.14,'#926642',x,2.43,-2.33,parent);
    for (const y of [1.78,2.43,3.08]) box(1.9,.07,.14,'#926642',2.95,y,-2.33,parent);
    box(5,.025,2.34,'#a86450',.7,.05,.25,parent);
    for (const z of [-.85,1.35]) box(4.85,.029,.036,'#e7c677',.7,.075,z,parent);
    mesh(new THREE.CylinderGeometry(.13,.23,.5,18),material('#a45e40'),-3.6,.26,-1.4,parent);
  }
  let facade, interior, door, coins=[];
  if (!stage.bedroom) {
    cutout([[-5.6,0],[-5.6,.8],[-4.2,1.9],[-2.45,1.05],[-.65,2.45],[1.95,.9],[3.6,2.02],[5.65,.75],[5.65,0]],'#a89ba8',0,0,-3.25);
    cutout([[-5.7,0],[-5.7,.55],[-4,.99],[-2.1,.49],[-.5,1.35],[1.8,.63],[3.7,1.26],[5.7,.72],[5.7,0]],'#9eac72',0,0,-2.81);
    for(const [x,z,size] of [[-4.9,1.8,.56],[3.65,.44,.49],[4.75,1.65,.67],[-3.7,-1.35,.65],[-1.3,2.27,.35]]) {
      const stone = mesh(new THREE.DodecahedronGeometry(size,0),material('#c0a584'),x,size*.26,z);
      stone.scale.set(1,.55,.59);
    }
    if(stage.grove) {
      card('tronco',3.8,3.4,-3.75,-1.95);
      const top = card('copa',3.7,2.02,-3.7,-2);
      top.position.y=3.5;
    }
  }
  if(stage.inn) {
    facade=new THREE.Group();
    facade.position.set(2.15,0,-1.72);
    root.add(facade);
    box(4.8,2.9,.16,'#dfbc89',-.9,1.47,0,facade);
    const roof = new THREE.Group();
    roof.position.set(-.9,2.82,0);
    facade.add(roof);
    for(const side of [-1,1]) {
      const panel = box(2.68,.14,1,'#a76743',side*1.22,.3,0,roof);
      panel.rotation.z=side*-.25;
    }
    box(1.14,1.85,.22,'#624935',-.76,.96,.08,facade);
    door = new THREE.Group();
    door.position.set(-1.29,.04,.22);
    facade.add(door);
    box(1.05,1.78,.07,'#916441',.525,.89,0,door);
    for(const x of [.2,.42,.64,.86]) box(.028,1.69,.043,'#ac7b48',x,.89,.04,door);
    box(.63,.55,.2,'#637f7f',-2.45,1.71,.08,facade);
    const banner=sign('Hospedaria',2.35,-.91,2.35,.18);
    facade.add(banner);
    interior = new THREE.Group();
    root.add(interior);
    room(interior);
  }
  if(stage.bedroom) {
    room(root);
    box(2.5,.11,1.05,'#9b6745',0,.89,.96);
    for(const x of [-1,1]) for(const z of [.57,1.35]) box(.13,.84,.14,'#815936',x,.44,z);
    coins=[-.28,.14].map(x=>mesh(new THREE.CylinderGeometry(.137,.137,.04,24),material('#ddb34e'),x,.97,.95));
  }
  if(stage.message) sign('O amor vira cuidado.',4.25,3.15,3.07,-2.38);
  return {update(t,closing) {
    const progress=ease(t/1.55)*closing;
    root.visible=progress>.001;
    root.scale.y=Math.max(.001,progress);
    if (facade) {
      const reveal=ease((t-7.35)/2.65);
      facade.visible=reveal<.96;
      facade.rotation.y=-reveal*Math.PI*.59;
      door.rotation.y=-ease((t-4.5)/2)*1.6;
      interior.visible=reveal>.62;
      interior.scale.y=Math.max(.001,ease((t-8.8)/1.25));
    }
    for(const [index,coin] of coins.entries()) {
      const begin=5.95+index*.53;
      const toss=ease((t-begin)/1.4);
      coin.visible=t>=begin;
      coin.position.x=THREE.MathUtils.lerp(-1.08,-.28+index*.42,toss);
      coin.position.y=.97+Math.sin(Math.PI*toss)*.46;
      coin.rotation.x=(1-toss)*1.25;
    }
  }};
}
