import { MOTIONS } from "./actor-motion.mjs";
export const ASSETS=Object.freeze(["samaritano", "ajoelhado", "viajante", "sentado", "montado", "repouso", "sacerdote", "levita", "hospedeiro", "zaqueu_em_pe", "zaqueu_sobe", "zaqueu_sentado", "zaqueu_recebe", "zaqueu_devolve", "zaqueu_feliz", "tronco", "copa", "casa", "banca", "burrinho", "passarinho", "arvore", "vila", "jesus_conta", "vizinho", "avo", "crianca", "folha"]);
export function validateStory(story) {
  if (
    !story ||
    typeof story.title !== "string" ||
    !story.title.trim() ||
    !Array.isArray(story.scenes) ||
    !story.scenes.length
  )
    throw Error("Roteiro precisa de título e cenas");
  if (
    story.endCard &&
    (!Number.isFinite(story.endCard.duration) ||
      story.endCard.duration < 3 ||
      story.endCard.duration > 15 ||
      typeof story.endCard.youtube?.name !== "string" ||
      typeof story.endCard.youtube?.handle !== "string" ||
      typeof story.endCard.tiktok?.handle !== "string")
  )
    throw Error("Tela final inválida");
  if (story.presentation) {
    const p=story.presentation;
    if (!Number.isFinite(p.introDuration) || p.introDuration<0 || p.introDuration>15 ||
        (p.cameraScale!==undefined && (!Number.isFinite(p.cameraScale) || p.cameraScale<0.9 || p.cameraScale>1.6)) ||
        (p.coverImage!==undefined && (!/^(assets|publicacao)\/[a-zA-Z0-9_./-]+\.(png|jpg)$/.test(p.coverImage) || p.coverImage.includes(".."))))
      throw Error("Apresentação do livro inválida");
  }
  const ids = new Set();
  let duration = 0;
  for (const s of story.scenes) {
    if (!s.id || ids.has(s.id))
      throw Error("Identificador de cena ausente ou repetido");
    ids.add(s.id);
    if (!Number.isFinite(s.duration) || s.duration < 3 || s.duration > 120)
      throw Error("Duração de cena inválida");
    if (typeof s.caption !== "string") throw Error("Legenda ausente");
    for (const key of ["from", "to", "target"])
      if (
        !Array.isArray(s.camera?.[key]) ||
        s.camera[key].length !== 3 ||
        !s.camera[key].every(Number.isFinite)
      )
        throw Error("Câmera inválida");
    if (!Array.isArray(s.actors) || s.actors.length > 60)
      throw Error("Atores inválidos");
    for (const a of s.actors) {
      if (a.motion) {
        if (!MOTIONS.includes(a.motion.type))
          throw Error("Movimento desconhecido");
        if (
          !Number.isFinite(a.motion.start) ||
          !Number.isFinite(a.motion.end) ||
          a.motion.start < 0 ||
          a.motion.end <= a.motion.start
        )
          throw Error("Intervalo de movimento inválido");
        for (const field of ["dx", "dy"])
          if (
            a.motion[field] !== undefined &&
            !Number.isFinite(a.motion[field])
          )
            throw Error("Deslocamento inválido");
      }

      if (!ASSETS.includes(a.asset))
        throw Error("Asset desconhecido: " + a.asset);
      for (const k of ["x", "z", "width", "height"])
        if (!Number.isFinite(a[k])) throw Error("Dimensão/posição inválida");
      if (a.width <= 0 || a.height <= 0 || a.width > 25 || a.height > 25)
        throw Error("Dimensão fora dos limites");
      for (const k of ["y", "walk", "enter"])
        if (a[k] !== undefined && !Number.isFinite(a[k]))
          throw Error("Parâmetro de ator inválido");
    }
    duration += s.duration;
  }
  if (
    !Number.isFinite(story.duration) ||
    Math.abs(duration - story.duration) > 0.001
  )
    throw Error("Duração total difere da soma das cenas");
  return story;
}
export function locateScene(story, time) {
  const t = Math.min(story.duration, Math.max(0, Number(time) || 0));
  let start = 0;
  for (let index = 0; index < story.scenes.length; index++) {
    const scene = story.scenes[index];
    if (t < start + scene.duration || index === story.scenes.length - 1)
      return { index, scene, local: t - start, start, time: t };
    start += scene.duration;
  }
}

export const ASSET_FILES={
  samaritano: {file: "assets/samaritano/samaritano.webp"},
  ajoelhado: {file: "assets/samaritano/ajoelhado.webp"},
  viajante: {file: "assets/samaritano/viajante.webp"},
  sentado: {file: "assets/samaritano/sentado.webp"},
  montado: {file: "assets/samaritano/montado.webp"},
  repouso: {file: "assets/samaritano/repouso.webp"},
  sacerdote: {file: "assets/samaritano/sacerdote.webp"},
  levita: {file: "assets/samaritano/levita.webp"},
  hospedeiro: {file: "assets/samaritano/hospedeiro.webp"},

  "zaqueu_em_pe": {
    "file": "assets/zaqueu/zaqueu_em_pe.webp"
  },
  "zaqueu_sobe": {
    "file": "assets/zaqueu/zaqueu_sobe.webp"
  },
  "zaqueu_sentado": {
    "file": "assets/zaqueu/zaqueu_sentado.webp"
  },
  "zaqueu_recebe": {
    "file": "assets/zaqueu/zaqueu_recebe.webp"
  },
  "zaqueu_devolve": {
    "file": "assets/zaqueu/zaqueu_devolve.webp"
  },
  "zaqueu_feliz": {
    "file": "assets/zaqueu/zaqueu_feliz.webp"
  },
  "tronco": {
    "file": "assets/zaqueu/tronco.webp"
  },
  "copa": {
    "file": "assets/zaqueu/copa.webp"
  },
  "casa": {
    "file": "assets/zaqueu/casa.webp"
  },
  "banca": {
    "file": "assets/zaqueu/banca.webp"
  },
  "burrinho": {
    "file": "assets/zaqueu/burrinho.webp"
  },
  "passarinho": {
    "file": "assets/zaqueu/passarinho.webp"
  },
  "arvore": {
    "file": "assets/ovelha/cenarios.webp",
    "rect": [
      6,
      2,
      711,
      701
    ]
  },
  "vila": {
    "file": "assets/ovelha/cenarios.webp",
    "rect": [
      724,
      87,
      720,
      577
    ]
  },
  "jesus_conta": {
    "file": "assets/elenco/jesus.webp",
    "rect": [
      1552,
      4,
      473,
      716
    ]
  },
  "vizinho": {
    "file": "assets/elenco/discipulos.webp",
    "rect": [
      577,
      512,
      361,
      512
    ]
  },
  "avo": {
    "file": "assets/elenco/familia.webp",
    "rect": [
      125,
      2,
      544,
      720
    ]
  },
  "crianca": {
    "file": "assets/elenco/familia.webp",
    "rect": [
      804,
      15,
      402,
      697
    ]
  },
  "folha": {
    "file": "assets/folha.svg"
  }
};
