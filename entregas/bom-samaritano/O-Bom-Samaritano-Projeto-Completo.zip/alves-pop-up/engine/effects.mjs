import {introDuration,totalDuration} from "./end-card.mjs";
// Efeitos originais sintetizados: nenhum arquivo externo é necessário.
export function validateEffects(config) {
  if (!config || !/^assets\/efeitos\/[a-zA-Z0-9_-]+\.wav$/.test(config.file) ||
      !Number.isFinite(config.volume) || config.volume < 0 || config.volume > 0.5)
    throw Error('Trilha de efeitos inválida');
  return config;
}
export function effectEvents(story) {
  let offset = introDuration(story);
  const all=story.scenes.flatMap(scene => {
    const events = (scene.soundEvents || []).map(event => {
      if (!['birds', 'steps', 'knock', 'rain', 'water', 'wind', 'tambourine', 'bleat'].includes(event.type) || !Number.isFinite(event.time) || event.time < 0 || event.time + (event.duration || 3) >= scene.duration)
        throw Error('Evento sonoro inválido em ' + scene.id);
      return {...event, time: offset + event.time};
    });
    offset += scene.duration;
    return events;
  });
  if(story.closingBell)all.push({type:"bell",time:totalDuration(story)-2.3});
  return all;
}
export function synthesizeEffects(story, rate = 48000) {
  const duration = totalDuration(story);
  const samples = new Float32Array(Math.ceil(duration * rate));
  let seed = 15433;
  function noise() {seed = (seed * 1664525 + 1013904223) >>> 0; return seed / 2147483648 - 1;}
  function tone(start, length, kind) {
    const first = Math.round(start * rate);
    for (let i=0; i<Math.round(length*rate); i++) {
      const t=i/rate, p=t/length;
      let sample;
      if(kind==='bleat'){const f=300*t+8*t*t; sample=.07*Math.sin(Math.PI*p)**.8*(1+.25*Math.sin(2*Math.PI*8*t))*(Math.sin(2*Math.PI*f)+.45*Math.sin(4*Math.PI*f)+.2*Math.sin(6*Math.PI*f));
      } else if(kind==='bell'){ sample=.16*Math.exp(-t*2.8)*(Math.sin(2*Math.PI*1320*t)+.35*Math.sin(2*Math.PI*2647*t)+.15*Math.sin(2*Math.PI*3965*t));
      } else if(kind==='tambourine'){sample=.035*Math.exp(-t*25)*(noise()*.5+Math.sin(2*Math.PI*3600*t)*.25+Math.sin(2*Math.PI*5230*t)*.25);
      } else if (kind==='birds') {
        const phase = 2*Math.PI*(2200*t + 1200*t*t / (2*length));
        sample = .10*Math.sin(Math.PI*p)**2*(Math.sin(phase)+.2*Math.sin(phase*2));
      } else if (kind==='knock') {
        sample = .12*Math.exp(-t*35)*(Math.sin(2*Math.PI*180*t)+.3*noise());
      } else {
        sample = .065*Math.exp(-t*35)*(noise()*.7+Math.sin(2*Math.PI*90*t)*.3);
      }
      if (first+i<samples.length) samples[first+i]+=sample;
    }
  }
  for (const event of effectEvents(story)) {
    if(event.type==='bleat'){tone(event.time,event.duration||1.1,'bleat');continue;}
    if(event.type==='tambourine'){for(let n=0;n<12;n++)tone(event.time+n*.45,.15,'tambourine');continue;}
    if(event.type==='rain'||event.type==='water'||event.type==='wind'){let low=0;const len=event.duration||8,first=Math.round(event.time*rate);for(let i=0;i<Math.round(len*rate)&&first+i<samples.length;i++){const p=i/rate/len;low=.96*low+.04*noise();samples[first+i]+=(event.type==='rain'?.11*noise()+.1*low:event.type==='wind'?.7*low*(.7+.3*Math.sin(i/rate*.5)):.5*low)*Math.min(1,p*8,(1-p)*8);}continue;}
    if(event.type==='bell'){tone(event.time,2.2,'bell');continue;}
    const count = event.type==='steps' ? 6 : 3;
    for(let n=0;n<count;n++) tone(event.time+n*(event.type==='birds'?.55:event.type==='steps'?.45:.32),event.type==='birds'?.18:.16,event.type);
  }
  return samples;
}
