import * as THREE from '../vendor/three.module.js';
const smooth=x=>{x=Math.min(1,Math.max(0,x));return x*x*(3-2*x);};
export function buildZaqueuProps(group,s,textures,actors){
 const root=new THREE.Group();group.add(root);
 const mat=color=>new THREE.MeshStandardMaterial({color,roughness:1,side:THREE.DoubleSide});
 const mats={paper:mat('#eee0ba'),wood:mat('#976943'),gold:mat('#dab95a'),cream:mat('#f2e0b2'),teal:mat('#568b83')};
 function box(w,h,d,m,x,y,z,parent=root){const mesh=new THREE.Mesh(new THREE.BoxGeometry(w,h,d),m);mesh.position.set(x,y,z);mesh.castShadow=mesh.receiveShadow=true;parent.add(mesh);return mesh;}
 function card(asset,w,h,x,z,y=.04,parent=root){const g=new THREE.Group();g.position.set(x,y,z);const m=new THREE.Mesh(new THREE.PlaneGeometry(w,h),new THREE.MeshStandardMaterial({map:textures[asset],alphaTest:.45,side:THREE.DoubleSide,roughness:1}));m.position.y=h/2;m.castShadow=m.receiveShadow=true;g.add(m);parent.add(g);return g;}
 function shape(points,color,x,z){const sh=new THREE.Shape();sh.moveTo(...points[0]);for(const p of points.slice(1))sh.lineTo(...p);sh.closePath();const m=new THREE.Mesh(new THREE.ShapeGeometry(sh),mat(color));m.position.set(x,.04,z);m.castShadow=m.receiveShadow=true;root.add(m);return m;}
 function coin(x,y,z,parent=root){const m=new THREE.Mesh(new THREE.CylinderGeometry(.15,.15,.035,16),mats.gold);m.rotation.x=Math.PI/2;m.position.set(x,y,z);m.castShadow=true;parent.add(m);return m;}
 function label(text,x,y,z,w=2.4){const c=document.createElement('canvas');c.width=1024;c.height=256;const q=c.getContext('2d');q.fillStyle='#f8eed5';q.fillRect(0,0,1024,256);q.strokeStyle='#b8954d';q.lineWidth=10;q.strokeRect(8,8,1008,240);q.fillStyle='#365b51';q.font='bold 80px Georgia';q.textAlign='center';q.textBaseline='middle';q.fillText(text,512,130,960);const tx=new THREE.CanvasTexture(c);tx.colorSpace=THREE.SRGBColorSpace;const m=new THREE.Mesh(new THREE.PlaneGeometry(w,w/4),new THREE.MeshStandardMaterial({map:tx,side:THREE.DoubleSide}));m.position.set(x,y,z);root.add(m);return m;}
 let door=null,book=null,coins=[],table=null,canopy=[],bird=null;
 const inside=s.setting==='inside';
 if(!inside){
  shape([[-5.5,0],[-5.5,.65],[-4.1,1.2],[-2.3,1.55],[-.7,.9],[1.4,1.5],[3.5,1.1],[5.5,.7],[5.5,0]],'#bcc495',0,-3.22);
  card('vila',5.5,2.7,-2.35,-2.8);card('casa',2.5,2.25,4.0,-2.75);
  if(s.market!==false)card('banca',2.1,2.0,-3.7,-.9);
  if(s.tree){
   const tx=s.treeX??1.3,tz=s.treeZ??-.7;
   card('tronco',4.4,4.2,tx,tz);
   // Duas abas independentes de folhagem, com dobradiça na copa.
   const cw=4.7,ch=3.0;
   for(const side of [-1,1]){
    const hinge=new THREE.Group();hinge.position.set(tx,2.55,tz-.10);root.add(hinge);
    const geo=new THREE.PlaneGeometry(cw/2,ch),uv=geo.attributes.uv;for(let n=0;n<uv.count;n++)uv.setX(n,(side<0?0:.5)+uv.getX(n)*.5);
    const m=new THREE.Mesh(geo,new THREE.MeshStandardMaterial({map:textures.copa,alphaTest:.45,side:THREE.DoubleSide,roughness:1}));m.position.set(side*cw/4,ch/2,0);m.castShadow=m.receiveShadow=true;hinge.add(m);hinge.userData.side=side;canopy.push(hinge);
   }
   // Galho de apoio, em cartão espesso, separado do tronco e do protagonista.
   box(1.5,.12,.18,mats.wood,tx-.65,3.05,tz+.08);
   bird=card('passarinho',.6,.54,tx+1.25,tz+.15,4.45);
  }else card('arvore',2.35,3.1,-4.6,-2.1);
  if(s.home){card('casa',3.4,3.05,-3.6,-1.85);door=new THREE.Group();door.position.set(-4.6,.08,-1.76);root.add(door);box(.93,1.9,.065,mats.wood,.465,.95,0,door);for(let n=0;n<5;n++)box(.015,1.82,.02,mats.gold,.12+n*.17,.95,.045,door);const knob=coin(.75,.95,.06,door);knob.scale.setScalar(.4);}
 }else{
  box(11.15,3.7,.09,mats.cream,0,1.85,-2.9);box(11.25,.1,.17,mats.gold,0,3.7,-2.82);
  // Janela com duas folhas de papel, jarros e tapete.
  box(1.6,1.4,.11,mats.teal,3,2.25,-2.78);for(const x of [2.2,3,3.8])box(.06,1.4,.15,mats.gold,x,2.25,-2.68);box(1.6,.06,.15,mats.gold,3,2.25,-2.67);
  const rug=box(4,.025,2.35,mat('#a86450'),0,.035,.8);for(const z of [-.23,1.83])box(3.8,.02,.035,mats.gold,0,.055,z);
  box(1.2,2.4,.1,mats.wood,-4,1.2,-2.78);for(const y of [.2,1.1,2.2])box(1.3,.07,.5,mats.gold,-4,y,-2.55);
  for(let n=0;n<4;n++){const urn=new THREE.Mesh(new THREE.CylinderGeometry(.12,.2,.35,12),mat(n%2?'#b97852':'#c59b65'));urn.position.set(-4.35+(n%2)*.65,.4+Math.floor(n/2)*1.0,-2.5);root.add(urn);}
 }
 if(s.taxTable||inside){
  table=new THREE.Group();table.position.set(s.taxTable?-1.1:0,0,inside?.5:.6);root.add(table);
  box(2.65,.1,1.15,mats.wood,0,.92,0,table);for(const x of [-1.03,1.03])for(const z of [-.4,.4])box(.12,.88,.12,mats.wood,x,.44,z,table);
  for(let n=0;n<7;n++)coins.push(coin(-.85+(n%4)*.29,1.01+Math.floor(n/4)*.06,.04,table));
  if(inside){
   const bread=new THREE.Mesh(new THREE.SphereGeometry(.23,12,8),mat('#d7ad6b'));bread.scale.set(1.5,.45,1);bread.position.set(.7,1.05,0);table.add(bread);
   const jug=new THREE.Mesh(new THREE.CylinderGeometry(.13,.2,.42,12),mat('#b7764d'));jug.position.set(1.04,1.19,-.2);table.add(jug);
  }
  book=new THREE.Group();book.position.set(-.2,1.0,.05);table.add(book);box(.67,.07,.72,mats.teal,0,0,0,book);box(.59,.035,.65,mats.cream,0,.055,0,book);
  const lid=new THREE.Group();lid.position.set(-.335,.09,0);book.add(lid);box(.67,.025,.72,mats.teal,.335,0,0,lid);book.userData.lid=lid;
 }
 let movingCoin=null;
 if(s.coinReturn){movingCoin=coin(-.25,1.25,1.1);for(let n=0;n<4;n++)coin(2.9+(n%2)*.32,.12,.7+Math.floor(n/2)*.32);label('Devolver e cuidar',0,3.3,-1.8,3.5);}
 if(s.decision){label('Metade para ajudar',-3.05,3.05,-1.9,3.4);label('Devolver quatro vezes',2.9,3.05,-1.9,3.6);}
 if(s.message)label('Cada pessoa tem valor',0,3.4,-2.05,4.6);
 // Flores e pequenos vasos em planos separados, junto às bordas das páginas.
 if(!inside)for(let n=0;n<12;n++){
  const x=-5.2+(n*1.31)%10.3,z=2.3+(n%3)*.27;
  const stem=box(.018,.28,.018,mat('#738950'),x,.15,z);const flower=new THREE.Mesh(new THREE.CircleGeometry(.085,7),mat(['#e9b597','#f0d693','#f3e7c3'][n%3]));flower.position.set(x,.34,z);root.add(flower);
 }
 return {update(t,closing){
  const rise=smooth((t-.2)/1.4)*closing;root.scale.y=Math.max(.001,rise);root.visible=rise>.001;
  for(const h of canopy){h.rotation.y=h.userData.side*(1-smooth((t-.8)/2))*1.35;h.rotation.z=h.userData.side*Math.sin(t*.65)*.009;}
  if(bird){bird.position.x=(s.treeX??1.3)+1.25+Math.sin(t*.4)*.16;bird.rotation.z=Math.sin(t*2)*.035;}
  if(door)door.rotation.y=-smooth((t-4.3)/3)*1.65;
  if(book){book.userData.lid.rotation.z=-.9*(1-smooth((t-3)/4));}
  if(movingCoin){const q=smooth((t-3)/5);movingCoin.position.set(-.25+3.15*q,1.25+Math.sin(q*Math.PI)*.5,1.1-.1*q);}
  for(const {pivot,data:a} of actors){
   if(a.enter!==undefined&&t<a.enter){pivot.visible=false;continue;}
   if(a.exit!==undefined&&t>=a.exit){pivot.visible=false;continue;}
   if(a.climb){const q=smooth((t-a.climb.start)/(a.climb.end-a.climb.start));pivot.position.x=a.x+(a.climb.dx||0)*q;pivot.position.y=(a.y||.025)+a.climb.dy*q;pivot.rotation.z=Math.sin(t*6)*.022;}
   if(a.descend){const q=smooth((t-a.descend.start)/(a.descend.end-a.descend.start));pivot.position.x=a.x+(a.descend.dx||0)*q;pivot.position.y=a.y+a.descend.dy*q;pivot.rotation.z=Math.sin(t*6)*.018;}
   if(a.lookUp)pivot.rotation.z=-.035+Math.sin(t*.7)*.012;
  }
  window.popupZaqueuAudit={scene:s.id,tree:!!s.tree,canopyHinges:canopy.length,doorAngle:door?.rotation.y??null,returnCoinX:movingCoin?.position.x??null,mainCount:actors.filter(a=>a.data.main&&a.pivot.visible).length,cast:actors.filter(a=>a.pivot.visible).map(a=>({asset:a.data.asset,x:a.pivot.position.x,y:a.pivot.position.y}))};
 }};
}
