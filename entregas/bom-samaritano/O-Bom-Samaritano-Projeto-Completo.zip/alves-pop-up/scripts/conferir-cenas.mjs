import puppeteer from 'puppeteer-core';
import {startServer} from './serve.mjs';
import {readFile, mkdir} from 'node:fs/promises';
import {resolve, join} from 'node:path';
const root=resolve(process.argv[2]||'.');
const out=resolve(process.argv[3]||'output/previews');
const story=JSON.parse(await readFile(join(root,'stories/joao.json'),'utf8'));
await mkdir(out,{recursive:true});
const server=await startServer(root,0);
let browser;
try {
  browser=await puppeteer.launch({executablePath:process.env.CHROME_PATH||'/usr/bin/chromium', headless:true,
    args:['--enable-unsafe-swiftshader','--disable-dev-shm-usage',...(process.env.POPUP_NO_SANDBOX==='1'?['--no-sandbox']:[])]});
  const page=await browser.newPage();
  const errors=[];
  page.on('pageerror',error=>errors.push(error.message));
  page.on('response',response=>{if(response.status()>=400 && !response.url().endsWith('/favicon.ico')) errors.push(response.status()+' '+response.url());});
  await page.setViewport({width:1280,height:720,deviceScaleFactor:1});
  await page.goto('http://127.0.0.1:'+server.address().port+'/?render&video-only',{waitUntil:'networkidle0'});
  await page.waitForFunction(()=>window.popupReady||window.popupError);
  const error=await page.evaluate(()=>window.popupError);
  if(error) throw Error(error);
  let start=0;
  for(const scene of story.scenes) {
    const local=({gancho:[5,13],jesus:[1,6],cuidado:[4,15],hospedaria:[5,13],encerramento:[6,14]})[scene.id]||[7];
    for(const second of local) {
      const actual=await page.evaluate(t=>{window.renderAt(t);return window.popupState.scene;},start+second);
      if(actual!==scene.id) throw Error('Cena incorreta no quadro: '+actual);
      await page.screenshot({path:join(out,scene.id+'-'+second+'.jpg'),quality:88});
    }
    start+=scene.duration;
  }
  await page.evaluate(t=>window.renderAt(t),start+2);
  await page.screenshot({path:join(out,'marca.jpg'),quality:88});
  if(errors.length) throw Error(errors.join('\n'));
} finally {
  if(browser) await browser.close();
  await new Promise(done=>server.close(done));
}
