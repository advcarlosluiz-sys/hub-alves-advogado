"""Importa os três originais do episódio e separa as poses em WebP."""
from pathlib import Path
import argparse
import shutil
from PIL import Image, ImageOps

parser = argparse.ArgumentParser()
parser.add_argument("ele_parou", type=Path)
parser.add_argument("quem_ajuda", type=Path)
parser.add_argument("elenco", type=Path)
parser.add_argument("capa", type=Path)
args = parser.parse_args()
root = Path(__file__).resolve().parents[1]
originals = root / "references" / "arte-original"
originals.mkdir(parents=True, exist_ok=True)
publication = root / "publicacao"
publication.mkdir(exist_ok=True)
for name, source in vars(args).items():
    shutil.copyfile(source, originals / (name + source.suffix.lower()))

for source, name in ((args.quem_ajuda, "miniatura.jpg"), (args.ele_parou, "miniatura-alternativa.jpg")):
    with Image.open(source) as image:
        image = ImageOps.fit(image.convert("RGB"), (1280, 720), Image.Resampling.LANCZOS)
        image.save(publication / name, quality=94, optimize=True)
with Image.open(args.capa) as image:
    image.convert("RGB").save(publication / "capa.png", optimize=True)

poses = {
    "samaritano": (42,0,366,422), "ajoelhado": (417,62,812,409),
    "viajante": (902,0,1185,422), "sentado": (0,453,399,830),
    "montado": (400,410,818,831), "repouso": (820,438,1254,825),
    "sacerdote": (48,832,347,1254), "levita": (454,832,734,1254),
    "hospedeiro": (851,832,1190,1254),
}
assets = root / "assets" / "samaritano"
assets.mkdir(parents=True, exist_ok=True)
with Image.open(args.elenco) as source:
    atlas = source.convert("RGBA")
    if atlas.getchannel("A").getextrema()[0] == 255:
        # Preserva a arte quando o PNG veio com o fundo preto consolidado.
        alpha = ImageOps.grayscale(atlas).point(lambda value: 0 if value < 13 else 255)
        atlas.putalpha(alpha)
    scale_x, scale_y = atlas.width / 1254, atlas.height / 1254
    for name, (x0, y0, x1, y1) in poses.items():
        pose = atlas.crop(tuple(round(n) for n in (x0*scale_x, y0*scale_y, x1*scale_x, y1*scale_y)))
        alpha = pose.getchannel("A")
        bounds = alpha.point(lambda value: 255 if value > 110 else 0).getbbox()
        if bounds is None:
            raise SystemExit("Recorte vazio: " + name)
        pose.crop(bounds).save(assets / (name + ".webp"), lossless=True)
