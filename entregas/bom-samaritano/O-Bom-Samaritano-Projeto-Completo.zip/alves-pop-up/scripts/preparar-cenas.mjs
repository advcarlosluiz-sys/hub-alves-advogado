import { readFileSync, writeFileSync } from 'node:fs';
import { validateStory } from '../engine/story.mjs';
const file = new URL('../stories/joao.json', import.meta.url);
const story = JSON.parse(readFileSync(file));
const proportions = {samaritano:.69, ajoelhado:1.12, viajante:.60, sentado:1.07, montado:.96, repouso:1.14, sacerdote:.62, levita:.57, hospedeiro:.74, jesus_conta:.64, vizinho:.70, crianca:.58, burrinho:1.20};
function actor(asset, x, z, height, options = {}) {
  return {asset, x, z, height, width:height*proportions[asset], ...options};
}
function walk(start, end, dx) { return {motion:{type:'walk', start, end, dx}}; }
const seated = () => actor('sentado', 2.15, .92, 1.72, {flip:true});
const listeners = () => [
  actor('jesus_conta', -1.9, .1, 3.08), actor('vizinho', .8, .55, 2.45, {flip:true}),
  actor('crianca', 2.35, 1.02, 1.6, {flip:true}),
];
const sets = {
  gancho:{road:true, close:true, teaserCover:true, actors:[seated(), actor('sacerdote',-4.1,-1.2,2.2,walk(2,11,3.9))]},
  jesus:{grove:true, coverOpening:true, actors:listeners()},
  viajante:{road:true, actors:[actor('viajante',-3.8,-.1,2.83,{...walk(1.25,7.9,4.25),exit:8}), {...seated(),enter:8}]},
  'dois-passam':{road:true, actors:[seated(), actor('sacerdote',-4.2,-.15,2.74,{...walk(1.1,8.4,7.9),exit:8.6}), actor('levita',-4.2,-.55,2.68,{...walk(10,17.8,7.9),enter:9,exit:18})]},
  compaixao:{road:true, close:true, actors:[seated(),actor('burrinho',-4.45,-.95,1.67,walk(2,9,2.4)),actor('samaritano',-3.7,.3,2.82,walk(2,11,4.0))]},
  cuidado:{road:true, close:true, actors:[{...seated(),exit:9.4},actor('ajoelhado',.03,.76,1.92,{exit:9.4}),actor('burrinho',-2.5,-.85,1.76,{exit:9.4}),actor('montado',-.15,.45,3.05,{enter:9.4,...walk(10.7,18,3.1)}),actor('samaritano',-1.97,.8,2.76,{enter:9.4,...walk(10.6,18,3.1)})]},
  hospedaria:{inn:true, actors:[actor('hospedeiro',3.25,.5,2.72,{exit:9.3}),actor('montado',-4.25,.2,3.02,{...walk(1.5,7.8,5.4),exit:9.3}),actor('samaritano',-2.6,.8,2.78,{...walk(1.5,7.8,4.8),exit:9.3}),actor('repouso',1.9,-.3,2.02,{enter:9.3}),actor('samaritano',-.85,.4,2.65,{enter:9.3})]},
  moedas:{bedroom:true, actors:[actor('repouso',3.26,-1.46,1.83),actor('hospedeiro',1.1,.1,2.76),actor('samaritano',-1.32,.1,2.78, {exit:13.6}),actor('burrinho',-3.18,-.48,1.6,{enter:13.6,...walk(14.4,18,-2.4),flip:true}),actor('samaritano',-2.40,.45,2.78,{enter:13.6,...walk(14.4,18,-3.1),flip:true})]},
  proximo:{grove:true, message:true, actors:[...listeners().map(a=>({...a,x:a.x-1.05})), actor('ajoelhado',2.44,-.63,1.23,{enter:7}),actor('sentado',3.76,-.44,1.03,{enter:7,flip:true})]},
  encerramento:{grove:true, actors:[actor('ajoelhado',-1.32,.6,2.05),{...seated(),x:1.27},actor('burrinho',-3.48,-1.15,1.78)]}
};
for (const scene of story.scenes) {
  const stage = sets[scene.id];
  const close = stage.close;
  Object.assign(scene,{
    samaritano:stage,
    room:!!stage.bedroom,
    extraAssets: stage.grove ? ["tronco","copa"] : [],
    coverOpening:!!stage.coverOpening,
    teaserCover:!!stage.teaserCover,
    camera:{
      from:close?[2.25,4.7,11.65]:[3.2,6.2,15],
      to:close?[.8,4.1,11.10]:[1.9,5.6,13.2],
      target:[0,1.45,-.15],
    },
    actors:stage.actors,
  });
  delete scene.samaritano.actors;
}
story.scenes.find(scene => scene.id === 'dois-passam').soundEvents = [
  {type:'steps',time:2.7,duration:2.6}, {type:'steps',time:11.4,duration:2.6},
];
story.effects={file:'assets/efeitos/ambiente.wav',volume:.16};
story.presentation.coverImage='publicacao/capa.png';
validateStory(story);
writeFileSync(file, JSON.stringify(story,null,2)+'\n');
