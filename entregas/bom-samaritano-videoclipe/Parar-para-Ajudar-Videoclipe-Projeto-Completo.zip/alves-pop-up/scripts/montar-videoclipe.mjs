import {readFileSync,writeFileSync} from 'node:fs';
import {validateStory} from '../engine/story.mjs';
const path = new URL('../stories/joao.json', import.meta.url);
const base = JSON.parse(readFileSync(new URL('../stories/filme-base.json', import.meta.url)));
const shots = [
 // Barra final, cena, intervalo percorrido dentro da animação, câmera.
 [4,'jesus',0,2.55,'capa'],
 [8,'gancho',1.4,12,'direita'],
 [12,'viajante',1.5,8,'esquerda'],
 [16,'viajante',8,17,'direita'],
 [20,'dois-passam',1.5,8.6,'aberta'],
 [24,'dois-passam',9,18,'direita'],
 [28,'compaixao',1.55,11.5,'esquerda'],
 [32,'cuidado',1.7,9.35,'perto'],
 [36,'cuidado',9.4,18.5,'direita'],
 [40,'hospedaria',1.6,9.1,'aberta'],
 [44,'hospedaria',8.7,18,'perto'],
 [48,'moedas',2.5,11.5,'mesa'],
 [52,'moedas',12.15,18.7,'aberta'],
 [56,'proximo',2,14,'aberta'],
 [60,'cuidado',2,9.3,'direita'],
 [64,'compaixao',6,15,'perto'],
 [68,'cuidado',9.45,18.5,'esquerda'],
 [72,'hospedaria',5.2,16.5,'direita'],
 [76,'proximo',7.5,17.2,'mesa'],
 [80,'encerramento',2.5,10.7,'perto'],
 [84,'encerramento',10.4,16.99,'capa'],
];
const cameras = {
  aberta: {from:[3.3,6.4,15],to:[.9,5.3,13.7],target:[0,1.45,-.05]},
  esquerda: {from:[-3.45,4.6,12.3],to:[-.8,4.6,11.2],target:[-.75,1.38,.1]},
  direita: {from:[3.35,4.7,12.4],to:[.9,4.05,10.65],target:[1.08,1.35,.15]},
  perto: {from:[1.55,4.2,10.1],to:[-.75,3.6,9],target:[.56,1.29,.3]},
  mesa: {from:[2.1,5.1,11.4],to:[.8,4.25,10.2],target:[.2,1.35,.4]},
};
const rate = 24;
const songSeconds = 211.632;
const totalFrames = Math.ceil(songSeconds*rate);
const bpm = 98.4;
const cutOffset = 0.18;
const byId = new Map(base.scenes.map(s=>[s.id,s]));
let start=0;
const scenes = shots.map(([bar,id,sourceFrom,sourceTo,angle],index)=>{
  const original=byId.get(id);
  const end=Math.round((cutOffset + bar*4*60/bpm)*rate);
  const duration=(end-start)/rate;
  start=end;
  return {
    ...original,id:id+'-'+String(index+1),caption:'',subtitles:[],
    soundEvents:[],duration,camera:cameras[angle]||original.camera,
    videoclip:{sourceFrom,sourceTo:Math.min(sourceTo,original.duration-.001),sourceDuration:original.duration,
      coverHold:index===0},
  };
});
const {narration,effects,...story}=base;
Object.assign(story,{
  scenes,title:'Parar para Ajudar! — Videoclipe',slug:'parar-para-ajudar-videoclipe',
  duration:start/rate, videoBitrate:1770000, audioMasterGain:1,
  videoClip:{songSeconds,bpm,cutOffset},
  music:{...base.music,volume:1,duckVolume:1,fadeIn:0,fadeOut:0,attack:.2,release:.2},
  endCard:{...base.endCard,duration:(totalFrames-start)/rate,featuredStory:'O Bom Samaritano — Quem Vai Ajudar?'},
});
validateStory(story);
writeFileSync(path, JSON.stringify(story,null,2)+'\n');
console.log(scenes.length+' planos · '+(totalFrames/rate).toFixed(3)+' s');
