# A Arca de Noé — livro pop-up

Adaptação infantil de Gênesis 6–9 para Contos de Gaitolé. Duração de 4min05s, horizontal 1280 × 720, 24 fps, H.264/AAC estéreo. Narração Thalita em português do Brasil, legendas por frase e música “Arca de Noé” fornecida pelo usuário, reduzida durante as falas.

## Assistir

Abra `output/arca-noe.mp4`. No pacote para assistir, extraia e abra `alves-pop-up/ASSISTA-AQUI.mp4`. Nenhum `.cmd` é necessário para assistir.

## Arquivos do projeto

- `stories/joao.json`: roteiro principal do motor; nome mantido por compatibilidade. Cópia em `stories/arca-noe.json`.
- `references/roteiro-fornecido.txt`: roteiro original enviado pelo usuário.
- `assets/noe/`: personagens, animais e cenários em aquarela de papel. Recortes em `engine/story.mjs`.
- `engine/noe-props.mjs`: arca com lateral e teto dobráveis, construção em etapas, rampa, chuva e ondas delicadas, recipientes, mesa com planta, pomba e folha, calendário e arco-íris.
- `assets/narracao/`: dez clipes Thalita e manifesto com tempos e hashes.
- `assets/musica/arca-noe.mp3`: música original preservada. `arca-noe-fundo.mp3` é a cópia de trabalho com silêncio acrescentado ao final para evitar reiniciar a música nos últimos segundos.
- `assets/efeitos/`: efeitos suaves originais de pássaros, chuva, água e sinal final.
- `publicacao/`: capa do livro, duas miniaturas em 1280 × 720, título, descrição e notas para comparação.

## Abertura e final

Pergunta a partir de 2 segundos, capa breve no fim da primeira cena e início do contexto aos 14 segundos. Entrada de animais em pares, interiores acolhedores, pomba e arco-íris. Sem cenas de afogamento, destruição ou violência. Encerramento recomenda Daniel na Cova dos Leões e convida à inscrição. Os elementos finais estão gravados no vídeo; recursos interativos do YouTube dependem da classificação e disponibilidade.

## Editar e exportar

Para editar o projeto, use Node.js 22+, Chrome/Chromium/Edge e FFmpeg. Execute `npm ci` e `npm start` para visualizar. Exporte com `npm run render:fast -- --out output/arca-noe.mp4`. Indique `CHROME_PATH` e `FFMPEG_PATH` se necessário. A geração Noiz está desativada e nenhuma chave é necessária para exportar os áudios incluídos. Mudanças no texto exigem nova narração e legendas. Os comandos existentes são opcionais e destinam-se à edição; o MP4 pronto pode ser assistido diretamente.

## Créditos

Gênesis 6–9, adaptação infantil original fornecida pelo usuário. Música fornecida pelo usuário. YouTube @gaitolé e TikTok @gaitole0. Licença e avisos originais Mira preservados em LICENSE-MIRA e vendor.
