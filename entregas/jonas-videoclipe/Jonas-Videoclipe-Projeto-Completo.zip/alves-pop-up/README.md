# Jonas, uma nova chance — videoclipe em livro pop-up

Canção original fornecida pelo usuário na íntegra, aproximadamente 4min33s (273,25 s). Horizontal 1280 × 720, 24 fps, H.264/AAC estéreo. Somente a canção, sem narrador adicional ou efeitos sobrepostos.

## Assistir

Abra `output/jonas-videoclipe.mp4`. No ZIP para assistir, extraia tudo e abra `alves-pop-up/ASSISTA-AQUI.mp4`. Não é necessário executar `.cmd` ou instalar o gerador para assistir ao MP4 pronto.

## Montagem

30 trechos com variações reais de câmera 3D e movimentos suaves acompanhando pulsações musicais estimadas. Livro com capa trabalhada sobre mesa em sala decorada, porto, barco, grande peixe com painel articulado, oração, praia, Nínive e plantinha. Encerramento de 20 segundos com marca, inscrição e indicação da canção A Arca de Noé.

A montagem temática considera a letra embutida nos metadados do MP3. O andamento e as pulsações foram estimados pelo fluxo espectral. Não há alinhamento da letra palavra por palavra nem legendas de karaokê.

## Arquivos

- `stories/joao.json`: roteiro principal do motor; nome mantido por compatibilidade. Cópia em `stories/jonas-videoclipe.json`.
- `references/montagem-videoclipe.json`: tempos dos 30 trechos e intervalos das ações originais.
- `references/letra-musica-fornecida.txt`: letra extraída do arquivo de música.
- `references/roteiro-fornecido.txt`: roteiro da história narrada que originou as cenas; o videoclipe utiliza apenas a canção.
- `assets/jonas/`: personagens, poses, animais e cenários de papel. Recortes em `engine/story.mjs` e origens em `references/assets-originais.json`.
- `engine/jonas-props.mjs`: peixe articulado, barco, ondas, portões, mercado, palmeiras e plantinha.
- `assets/musica/jonas-uma-nova-chance.mp3`: original preservado sem cortes, repetição ou substituição do vocal.
- `publicacao/`: capa, letra, título, descrição e duas miniaturas com indicação VIDEOCLIPE.

## Editar e exportar

Requer Node.js 22+, Chrome/Chromium/Edge e FFmpeg. Execute `npm ci` e `npm start` para visualizar. Exporte com `npm run render:fast -- --out output/jonas-videoclipe.mp4`. Use `CHROME_PATH` e `FFMPEG_PATH` se necessário. A geração Noiz está desativada; nenhuma chave é necessária para exportar a música incluída.

## Créditos

Contos de Gaitolé: YouTube @gaitolé e TikTok @gaitole0. Música e letra fornecidas pelo usuário, com referência em Jonas 1–4. Licença e avisos originais Mira preservados em LICENSE-MIRA e vendor. Nenhum teste A/B de desempenho nem publicação no YouTube foi realizado.
