# Gaitolé — O Menino e a Bruxa

Contos de Gaitolé. Filme em livro pop-up 3D com 4min22s, 720p/24fps, narração Thalita pt-BR, música, legendas e encerramento.

Extraia o ZIP e abra `output/gaitole.mp4`. No ZIP para assistir, abra `ASSISTA-AQUI.mp4`. Nenhum `.cmd` precisa ser executado para assistir.

Personagens confirmados pelo autor: João, Potocó, Espirro, Espoleta, Dona Zefinha, Maria e Morgana. Essas correções prevalecem sobre o roteiro fornecido inicialmente.

A pasta `publicacao` contém a miniatura, o título e a descrição. O roteiro do motor é `stories/joao.json`; a cópia identificada pelo nome deste conto é `stories/gaitole.json`.

Veja `LEIA-ME-PRIMEIRO.txt` para editar ou exportar novamente. A música original e a versão de montagem estão em `assets/musica`. Código, bibliotecas, ilustrações, falas e efeitos acompanham o projeto.
