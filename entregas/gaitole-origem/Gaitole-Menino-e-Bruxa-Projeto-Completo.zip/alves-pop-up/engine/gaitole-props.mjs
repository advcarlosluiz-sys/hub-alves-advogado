import * as THREE from '../vendor/three.module.js';
const smooth=v=>{v=Math.max(0,Math.min(1,v));return v*v*(3-2*v)};
export function buildGaitoleProps(parent,s){
 const g=new THREE.Group();parent.add(g);
 const mat=color=>new THREE.MeshStandardMaterial({color,roughness:.85,side:THREE.DoubleSide});
 const paper=mat('#e8d8b5'),wood=mat('#8e6347'),gold=mat('#efc75d');
 function add(geometry,material,x,y,z,group=g){const m=new THREE.Mesh(geometry,material);m.position.set(x,y,z);m.castShadow=m.receiveShadow=true;group.add(m);return m}
 function line(points,color='#dab66b',radius=.018,group=g){const curve=new THREE.CatmullRomCurve3(points.map(v=>new THREE.Vector3(...v)));return add(new THREE.TubeGeometry(curve,48,radius,5,false),mat(color),0,0,0,group)}
 if(s.familyBook){
  for(const actor of s.actors){
   const name={avo_gaitole:"Maria",mae_gaitole:"Dona Zefinha",menino_gaitole:"João"}[actor.asset];
   if(!name)continue;
   const c=document.createElement("canvas");c.width=512;c.height=112;const x=c.getContext("2d");x.fillStyle="#f6e6bc";x.fillRect(0,0,512,112);x.strokeStyle="#b68a43";x.lineWidth=8;x.strokeRect(5,5,502,102);x.font="48px Georgia";x.textAlign="center";x.fillStyle="#5a3c26";x.fillText(name,256,73);
   const tex=new THREE.CanvasTexture(c);tex.colorSpace=THREE.SRGBColorSpace;
   add(new THREE.PlaneGeometry(1.8,.4),new THREE.MeshBasicMaterial({map:tex,side:THREE.DoubleSide}),actor.x,actor.height+.35,actor.z+.04);
  }

  add(new THREE.BoxGeometry(2.4,.12,1.1),wood,0,.85,1.2);
  for(const x of [-.9,.9])for(const z of [.8,1.6])add(new THREE.BoxGeometry(.09,.85,.09),wood,x,.42,z);
  for(const side of [-1,1]){const page=add(new THREE.BoxGeometry(.65,.05,.65),paper,side*.33,.95,1.2);page.rotation.z=side*.1;}
 }
 let door=null;
 if(s.openingDoor){door=new THREE.Group();door.position.set(-3.35,.05,-2.65);g.add(door);const slab=add(new THREE.BoxGeometry(.68,1.35,.045),mat('#694c37'),.34,.675,0,door);add(new THREE.SphereGeometry(.045,8,6),gold,.56,.68,.045,door);}
 const smoke=[];
 if(s.smoke)for(let i=0;i<5;i++){const m=add(new THREE.CircleGeometry(.12+i*.02,12),new THREE.MeshBasicMaterial({color:'#ded5c1',transparent:true,opacity:.35,depthWrite:false,side:THREE.DoubleSide}),-1.7,2.6+i*.2,-2.65);smoke.push(m);}
 if(s.cassava){
  const food=add(new THREE.CylinderGeometry(.09,.1,.38,8),mat('#e6d1a0'),-.23,1.18,1.45);food.rotation.z=.6;
  const end=add(new THREE.CircleGeometry(.085,10),mat('#fff0c9'),-.13,1.32,1.51);end.rotation.x=-.4;
 }
 function chain(config,kind){
  if(!config)return null;
  const group=new THREE.Group();g.add(group);const [x,y,z]=kind==='dog'?[1.8,.47,1.25]:[3.2,.95,.1];
  const anchor=kind==='dog'?[2.55,.75,-1.5]:[4.55,1.1,-1.75];
  const links=[];
  for(let i=0;i<13;i++){const q=i/12;const m=add(new THREE.TorusGeometry(.105,.022,5,12),mat('#a6a18c'),anchor[0]+(x-anchor[0])*q,anchor[1]+(y-anchor[1])*q-Math.sin(q*Math.PI)*.15,anchor[2]+(z-anchor[2])*q,group);m.rotation.y=i%2?Math.PI/2:.5;links.push(m);}
  const band=add(new THREE.TorusGeometry(kind==='dog'?.24:.4,.025,6,20),mat('#a6a18c'),x,y,z,group);band.rotation.y=Math.PI/2;band.scale.y=.8;
  const hair=line([[-2.8,2.5,-.35],[-.9,2.7,.7],[.5,1.5,1],[x,y,z]],'#d2c5a4',.023);
  return {group,hair,links,start:config.start};
 }
 const dog=chain(s.dogChain,'dog'),horse=chain(s.horseChain,'horse');
 let sword=null,cutHair=null;const sparks=[];
 if(s.swordCut!==undefined){
  sword=new THREE.Group();sword.position.set(-.2,1.15,1.58);g.add(sword);
  add(new THREE.BoxGeometry(.07,.22,.045),wood,0,-.12,0,sword);
  add(new THREE.BoxGeometry(.33,.05,.065),gold,0,.01,0,sword);
  add(new THREE.BoxGeometry(.075,.65,.022),mat('#f3dda0'),0,.35,0,sword);
  const tip=add(new THREE.ConeGeometry(.06,.16,3),gold,0,.75,0,sword);
  cutHair=line([[-2.8,2.5,-.35],[-1.7,2.6,.5],[-.3,1.8,1.5]],'#dac884',.024);
  for(let i=0;i<7;i++)sparks.push(add(new THREE.OctahedronGeometry(.08,0),new THREE.MeshBasicMaterial({color:'#ffe9a3'}),-.1,1.7,1.5));
 }
 const tangle=[];
 if(s.tangle!==undefined)for(let i=0;i<3;i++){
  const points=[];for(let k=0;k<=36;k++){const q=k/36,a=q*Math.PI*5;points.push([-2.8+Math.cos(a)*(.4+i*.04),.4+q*1.6,-.4+Math.sin(a)*.15]);}
  tangle.push(line(points,'#cabf9f',.023));
 }
 const notes=[];
 if(s.musicNotes)for(let i=0;i<6;i++){
  const n=new THREE.Group();g.add(n);const head=add(new THREE.SphereGeometry(.075,8,6),gold,0,0,0,n);head.scale.y=.7;add(new THREE.BoxGeometry(.025,.34,.025),gold,.055,.15,0,n);const flag=add(new THREE.BoxGeometry(.15,.045,.025),gold,.11,.3,0,n);notes.push(n);
 }
 return {update(t,closing){
  g.scale.y=Math.max(.001,smooth((t-.3)/1.1)*closing);
  if(door)door.rotation.y=-smooth((t-2.2)/2)*1.45;
  smoke.forEach((m,i)=>{const q=(t*.17+i*.2)%1;m.position.y=(s.id==="porta"?3.5:2.65)+q*.9;m.position.x=-1.7+Math.sin(t+i)*.08;m.material.opacity=.3*(1-q);});
  for(const c of [dog,horse])if(c){
   const q=c.start===0?1:smooth((t-c.start)/2.2),release=s.release===undefined?0:smooth((t-s.release)/1.4);
   c.group.visible=q>.45&&release<.995;c.group.scale.setScalar(Math.max(.001,(.4+.6*q)*(1-release)));
   c.hair.visible=c.start>0&&t>=c.start&&q<.999;
   const total=c.hair.geometry.index.count;c.hair.geometry.setDrawRange(0,Math.floor(total*q/6)*6);
  }
  if(sword){const q=smooth((t-s.swordCut)/.5);sword.visible=t>3;sword.rotation.z=t<s.swordCut?Math.sin(t*12)*.03:-.9+q*1.65;cutHair.visible=t>=s.swordCut-6&&t<s.swordCut+.35;const hairProgress=smooth((t-(s.swordCut-6))/3);cutHair.geometry.setDrawRange(0,Math.floor(cutHair.geometry.index.count*hairProgress/6)*6);const flash=t>=s.swordCut&&t<s.swordCut+1.2;for(let i=0;i<sparks.length;i++){const a=i*Math.PI*2/7,r=.2+Math.max(0,t-s.swordCut)*.7;sparks[i].visible=flash;sparks[i].position.set(-.1+Math.cos(a)*r,1.7+Math.sin(a)*r,1.5);}}
  tangle.forEach(m=>{m.visible=t>=s.tangle&&!(s.release!==undefined&&t>8);m.scale.y=Math.max(.001,smooth((t-s.tangle)/2));});
  notes.forEach((n,i)=>{n.position.set(-1+i*.5,2.9+Math.sin(t*1.5+i)*.12,.7);n.rotation.z=Math.sin(t+i)*.08;});
 }};
}
