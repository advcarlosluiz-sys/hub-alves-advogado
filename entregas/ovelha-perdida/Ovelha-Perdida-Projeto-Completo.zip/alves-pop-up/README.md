# Cadê Minha Ovelhinha! — A Ovelha Perdida

Contos de Gaitolé. História narrada em livro pop-up, adaptação infantil de Lucas 15:3–7. Aproximadamente 2min55s (175,375s), horizontal 1280×720,24fps,H.264/AAC estéreo. Voz Thalita pt-BR,  legendas por frase e canção fornecida “Cadê minha ovelhinha!” baixa nas falas.

## Assistir

Abra `output/ovelha-perdida.mp4`. No ZIP para assistir, extraia tudo e abra `alves-pop-up/ASSISTA-AQUI.mp4`. Não precisa executar .cmd, instalar o gerador ou gerar a voz para assistir ao vídeo pronto.

## Apresentação

Dez cenas, capa intitulada verde e dourada sobre mesa trabalhada em sala decorada. Narração desde 0,75s; busca iniciada na abertura. Colinas em camadas, árvores, flores, riacho, trilha e vila. O arbusto abre com duas dobradiças 3D para revelar a ovelhinha. Pastor em poses de busca, acolhimento e carregando a ovelha nos ombros. Trocas de pose sem duplicar pastor ou protagonista. Jesus aparece como contador da parábola, em página distinta da ação do pastor.

Os números 100 e 99 representam o total narrado; a composição mostra partes do rebanho e não uma contagem animada de todas as ovelhas. Detalhes como seguir uma borboleta são recursos da adaptação. Sem precipícios, predadores ou violência.

Encerramento com marca, YouTube @gaitolé, TikTok @gaitole0, inscrição e indicação de Jesus Acalma a Tempestade. Os elementos finais são gráficos do vídeo.

## Arquivos do projeto

- stories/joao.json: roteiro principal, nome por compatibilidade; cópia em stories/ovelha-perdida.json.
- references/roteiro-fornecido.txt: texto integral enviado, preservado. O resíduo 15:45 ao final não integra a narração.
- references/tempos-producao.json: durações e ajustes após medição real das falas.
- assets/ovelha/: atlas originais, WebP sem perda, comparados por pixels RGBA com PNGs gerados.
- assets/elenco/: ilustrações originais de Jesus e ouvintes reutilizadas da produção Jesus Acalma a Tempestade.
- engine/ovelha-props.mjs: trilha, colinas, flores, placas e arbusto articulado 3D.
- assets/narracao/: dez clipes Thalita, manifesto com hashes e SRTs por frase. Voz pt-BR-ThalitaMultilingualNeural, ritmo −12%, tom −4Hz.
- assets/musica/cade-minha-ovelhinha.mp3: original preservado,175,344s. Uma reprodução completa, sem loop, com ducking;31 ms finais completam o último quadro.
- assets/efeitos/: efeitos sintetizados discretos de pássaros, passos e balido estilizado.
- publicacao/: título, descrição, capítulos, legendas e miniaturas 1280×720.

## Editar e exportar

Requer Node.js 22+,Chrome/Chromium/Edge e FFmpeg. Execute `npm ci` e `npm start`. Exporte com `npm run render:fast -- --out output/ovelha-perdida.mp4`. Configure CHROME_PATH e FFMPEG_PATH se necessário. Os áudios já estão incluídos; geração Noiz desativada, sem chave necessária para esta exportação. Alterar texto exige gerar a voz novamente; revisar durações, legendas e efeitos se mudar a montagem. O ZIP inclui os fontes locais, sem node_modules,venv ou credenciais.

## Créditos

Roteiro e música fornecidos pelo autor. Referência: Lucas 15:3–7. Ilustrações e mecanismos originais preparados para o episódio, com reutilização identificada acima. Licença e avisos do Mira preservados em LICENSE-MIRA e vendor. Nenhuma publicação no YouTube ou teste A/B de desempenho foi realizado.
