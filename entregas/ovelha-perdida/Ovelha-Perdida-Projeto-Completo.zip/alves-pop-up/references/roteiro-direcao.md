# Cadê Minha Ovelhinha! — A Ovelha Perdida

Roteiro para história narrada em livro pop-up | Contos de Gaitolé

- Referência: Lucas 15:3–7. Adaptação infantil; diálogos e detalhes visuais são recursos da adaptação.
- Narração prevista: Thalita, português do Brasil, acolhedora e expressiva.
- Música fornecida: “Cadê minha ovelhinha!.mp3”, duração verificada de 175,344 segundos (aproximadamente 2min55s).
- Arquivo original: `/workspace/attachments/98de3d2a-fde2-4dc8-98fa-9c2bc3975ed8/Cadê minha ovelhinha!.mp3`.
- Tempos abaixo são planejamento de cenas, não alinhamento dos versos da canção. Ajustar à gravação da voz na produção. A canção deve tocar completa, uma vez, com redução de volume durante a narração. Priorizar passagem instrumental sob a voz quando disponível, evitando competição entre canto e fala.
- Formato previsto: horizontal 16:9; legendas por frases curtas.

## Direção visual e sonora

Livro físico com capa verde-sálvia, moldura dourada, flores em relevo e título “Cadê Minha Ovelhinha!”. Sobre mesa de madeira entalhada em sala acolhedora, com estante, luminária quente, tapete, vaso de flores e janela. Capa integrada à abertura rápida, sem vinheta longa. Personagens e cenários de papel recortado em 3D, com bordas, dobras, textura e sombras suaves; transições por virada de página. Pastor com túnica bege, manto azul e sandálias; ovelhinha de lã branca, focinho claro e pequena mecha na testa. Preservar a aparência em todas as cenas. Jesus aparece como contador da parábola em página distinta; o pastor é personagem da história contada. Sem precipícios, predadores, ferimentos ou broncas. Balidos, passos e pássaros discretos, sem encobrir a narradora.

## 1. Uma ovelhinha está faltando — 0:00–0:12

**Visual:** Um balido suave acompanha a primeira imagem da capa. O livro se abre imediatamente e revela o pastor procurando entre ovelhas e flores. Jesus aparece brevemente como contador da história em uma vinheta na margem da página. Um espaço vazio no rebanho inicia o mistério.

**Narração:** “Cadê a ovelhinha? Jesus contou a história de um pastor que percebeu uma ausência no rebanho. Vamos acompanhar essa busca!”

## 2. Cada uma era importante — 0:12–0:30

**Visual:** Colinas e uma árvore se levantam. Ovelhas caminham, bebem água e descansam. O pastor observa com carinho. O número 100 surge brevemente como elemento de papel. As ovelhas podem ocupar planos e grupos distintos, sem mostrar uma contagem visual incompleta como se fosse o total.

**Narração:** “Aquele pastor tinha cem ovelhas. Ele conhecia seu rebanho e cuidava de cada uma com atenção. Levava todas para lugares com água e capim fresquinho. Nenhuma era esquecida.”

## 3. Um caminho diferente — 0:30–0:48

**Visual:** A câmera acompanha a ovelhinha passando por flores e uma borboleta. Um arbusto dobrável encobre gradualmente o rebanho ao fundo. Ela para e olha ao redor. Detalhe imaginado para esta adaptação.

**Narração:** “Na nossa história, uma ovelhinha caminhou entre as flores e acabou se afastando. Quando levantou a cabeça, já não via as companheiras. Parou, olhou ao redor e soltou um balido baixinho.”

## 4. O pastor percebe — 0:48–1:06

**Visual:** No campo, o pastor confere o rebanho. O número 99 se desdobra. Ele olha a trilha e começa a procurar. As outras ovelhas permanecem juntas no campo.

**Narração:** “Ao conferir o rebanho, o pastor percebeu: havia noventa e nove. Faltava uma! Ele não pensou que ela fosse menos importante. Saiu à sua procura, atento aos caminhos e aos sons.”

## 5. Vamos escutar? — 1:06–1:24

**Visual:** Uma trilha se desdobra entre camadas de colinas, arbustos, pedras arredondadas e passarinhos. O pastor faz uma pausa. Duas orelhas aparecem discretamente atrás das folhas, permitindo descoberta pelo público.

**Narração:** “Ele passou pelas flores, contornou uma pedra e escutou com cuidado. Você consegue ver alguma coisa atrás das folhas? Duas orelhinhas apareceram… Então veio um som: mééé! Estava bem pertinho!”

## 6. O reencontro — 1:24–1:45

**Visual:** O arbusto abre como uma aba e revela a ovelhinha, sem estar presa ou ferida. O pastor se aproxima devagar, ajoelha e a acolhe. A expressão dela muda de apreensão para alívio. Breve pausa para a música.

**Narração:** “Era ela! O pastor se aproximou devagar e a acolheu com muito carinho. Que alegria encontrá-la! Não houve bronca nem empurrão. A ovelhinha recebeu cuidado e pôde descansar junto dele.”

## 7. De volta nos ombros — 1:45–2:03

**Visual:** O pastor coloca a ovelhinha nos ombros; a pose mantém as quatro patas e o corpo apoiados. O caminho de papel se estende até o rebanho. Borboletas e flores acompanham o retorno.

**Narração:** “O pastor colocou a ovelhinha nos ombros e fez o caminho de volta. Ela já não precisava andar sozinha. Entre colinas e flores, os dois seguiram para o reencontro com as outras.”

## 8. Uma alegria para compartilhar — 2:03–2:23

**Visual:** A página vira, mostrando rebanho reunido, casas, amigos e vizinhos. O pastor acomoda a ovelhinha no chão e convida todos a celebrar. Não representar duplicação da ovelhinha durante a mudança de pose.

**Narração:** “Quando voltou, o pastor chamou os amigos e vizinhos para compartilhar sua alegria: ‘Encontrei minha ovelha!’ A que estava perdida havia sido encontrada. Agora, estava novamente junto do rebanho, recebida com carinho.”

## 9. O carinho de Deus — 2:23–2:40

**Visual:** Retorno à página de Jesus contando a parábola. Crianças e adultos o escutam; uma pequena ilustração do pastor com a ovelhinha permanece na página. A mensagem “Cada um tem valor” aparece sem cobrir rostos.

**Narração:** “Jesus ensinou que Deus se alegra quando alguém volta para perto dele. Cada pessoa tem valor. E nós também podemos cuidar, acolher e ajudar quem se sente sozinho.”

## 10. Contos de Gaitolé — 2:40–2:55,344

**Visual:** O rebanho se recolhe suavemente e a capa fecha. A mesa e a sala reaparecem. Exibir marca Contos de Gaitolé, YouTube @gaitolé, TikTok @gaitole0 e “Inscreva-se para ouvir mais histórias!”. Sugerir a próxima história: “Jesus Acalma a Tempestade”. Encerramento gráfico, sem simular botões interativos. A música termina naturalmente; conferir duração da voz e reservar a cauda musical na montagem.

**Narração:** “Você merece carinho e cuidado! Inscreva-se no Contos de Gaitolé para ouvir mais histórias. E continue essa aventura com Jesus Acalma a Tempestade!”

---

Estado: roteiro preparado. Não foram gerados vídeo, voz ou ZIP nesta etapa.
