import * as THREE from '../vendor/three.module.js';
const smooth=x=>{x=Math.min(1,Math.max(0,x));return x*x*(3-2*x);};
export function buildOvelhaProps(group,s,textures,actors){
 const root=new THREE.Group();group.add(root);
 const mat=(color)=>new THREE.MeshStandardMaterial({color,roughness:1,side:THREE.DoubleSide});
 const paper=mat('#eee0ba'),gold=mat('#d4ad59');
 function card(asset,w,h,x,z,y=.04){const g=new THREE.Group();g.position.set(x,y,z);const m=new THREE.Mesh(new THREE.PlaneGeometry(w,h),new THREE.MeshStandardMaterial({map:textures[asset],alphaTest:.45,side:THREE.DoubleSide,roughness:1}));m.position.y=h/2;m.castShadow=m.receiveShadow=true;g.add(m);root.add(g);return g;}
 function shape(points,color,x,z){const sh=new THREE.Shape();sh.moveTo(...points[0]);for(const p of points.slice(1))sh.lineTo(...p);sh.closePath();const m=new THREE.Mesh(new THREE.ShapeGeometry(sh),mat(color));m.position.set(x,.04,z);m.castShadow=m.receiveShadow=true;root.add(m);return m;}
 // Dezenas de peças de papel em planos distintos, não uma única imagem de cenário.
 shape([[-5.55,0],[-5.55,1],[-4.5,1.8],[-3.2,2.1],[-1.8,1.6],[0,2.1],[1.5,1.6],[3.1,2.2],[4.8,1.7],[5.55,.8],[5.55,0]],'#87a66d',0,-2.95);
 shape([[-5.55,0],[-5.55,.6],[-4.1,1.25],[-2.7,1.5],[-.8,.9],[1,1.45],[3,1.65],[4.5,1.1],[5.55,.6],[5.55,0]],'#a7bc77',0,-2.55);
 shape([[-5.55,0],[-5.55,.4],[-3.5,.9],[-1.4,.5],[.8,.85],[2.7,.6],[4.5,.95],[5.55,.45],[5.55,0]],'#b8c88b',0,-2.15);
 card('arvore',2.1,3.35,-4.6,-1.4);if(s.landscape!=='village')card('arvore',1.6,2.65,4.7,-1.8);
 if(s.landscape==='village')card('vila',4.9,2.7,1.1,-2.0);
 // Trilha curva como recorte de papel colocado sobre a página.
 const pathShape=new THREE.Shape();pathShape.moveTo(-1.6,-3.25);pathShape.bezierCurveTo(-1.3,-.8,2.5,-.2,1.6,3.15);pathShape.lineTo(.45,3.15);pathShape.bezierCurveTo(1.4,.1,-2.3,-.6,-2.5,-3.25);pathShape.closePath();const trail=new THREE.Mesh(new THREE.ShapeGeometry(pathShape,32),mat('#dfcca0'));trail.rotation.x=-Math.PI/2;trail.position.y=.028;trail.receiveShadow=true;root.add(trail);
 shape([[-.55,0],[-.48,.37],[-.12,.6],[.35,.51],[.61,.15],[.5,0]],'#b9b6a0',-3.0,.5);
 if(s.id==='rebanho'){const stream=new THREE.Mesh(new THREE.PlaneGeometry(1.2,5),mat('#8fbfc2'));stream.rotation.x=-Math.PI/2;stream.rotation.z=-.14;stream.position.set(3.8,.04,.2);root.add(stream);}
 // Flores em instâncias mantêm os detalhes sem tornar a exportação pesada.
 const colors=['#f4e5b3','#e5bcbd','#e4d18a'];const dummy=new THREE.Object3D();
 for(let ci=0;ci<colors.length;ci++){
  const petals=new THREE.InstancedMesh(new THREE.CircleGeometry(.075,6),mat(colors[ci]),30);let n=0;
  for(let f=0;f<6;f++){const x=-5.1+((f*1.79+ci*.71)%10.1),z=1.8+((f*1.1+ci*.5)%1.6),y=.22+(f%2)*.09;for(let k=0;k<5;k++){dummy.position.set(x+Math.sin(k*1.256)*.08,y+Math.cos(k*1.256)*.08,z);dummy.rotation.set(0,0,k);dummy.updateMatrix();petals.setMatrixAt(n++,dummy.matrix);}}
  petals.castShadow=true;root.add(petals);
 }
 // Um arbusto articulado em duas abas esconde e revela a protagonista.
 let leaves=null;
 if(s.revealBush||s.passBush){
  leaves=new THREE.Group();leaves.position.set(s.passBush?2.45:-1.55,.05,s.passBush?1.65:1.28);root.add(leaves);
  const width=s.passBush?2.0:2.55,height=s.passBush?1.35:1.43;
  for(const side of [-1,1]){
   const hinge=new THREE.Group();hinge.position.x=side*width/2;leaves.add(hinge);
   const g=new THREE.PlaneGeometry(width/2+.06,height),uv=g.attributes.uv;
   for(let n=0;n<uv.count;n++)uv.setX(n,(side<0?0:.5)+uv.getX(n)*.5);
   const m=new THREE.Mesh(g,new THREE.MeshStandardMaterial({map:textures.arbusto,alphaTest:.45,side:THREE.DoubleSide,roughness:1}));m.position.set(-side*width/4,height/2,0);m.castShadow=m.receiveShadow=true;hinge.add(m);hinge.userData.side=side;
  }
 }
 let count=null;
 function label(text,x,y,z,w,h,size){const c=document.createElement('canvas');c.width=1024;c.height=256;const q=c.getContext('2d');q.fillStyle='#f8eed5';q.fillRect(0,0,1024,256);q.strokeStyle='#ae8d48';q.lineWidth=12;q.strokeRect(8,8,1008,240);q.fillStyle='#425a39';q.textAlign='center';q.textBaseline='middle';q.font='bold '+size+'px Georgia';q.fillText(text,512,130,970);const tx=new THREE.CanvasTexture(c);tx.colorSpace=THREE.SRGBColorSpace;const p=new THREE.Group();p.position.set(x,y,z);const m=new THREE.Mesh(new THREE.PlaneGeometry(w,h),new THREE.MeshStandardMaterial({map:tx,side:THREE.DoubleSide,roughness:1}));m.position.y=h/2;m.castShadow=true;p.add(m);root.add(p);return p;}
 if(s.countLabel)count=label(s.countLabel,3.4,1.6,-1.1,1.5,.65,185);
 if(s.messageLabel)label(s.messageLabel,0,3.1,-1.8,4.3,.85,86);
 if(s.storytellerVignette){const pl=card('jesus_conta',.82,1.32,4.5,-.8);label('Jesus contou',4.4,1.58,-.82,1.65,.4,86);}
 let butterfly=null;
 if(s.butterfly){butterfly=new THREE.Group();butterfly.position.set(0,1.8,.9);root.add(butterfly);for(const side of [-1,1]){const wing=new THREE.Mesh(new THREE.CircleGeometry(.18,7),mat(side<0?'#d9b376':'#e9cda0'));wing.position.x=side*.12;wing.scale.y=1.4;wing.userData.side=side;butterfly.add(wing);}}
 return {update(t,closing){
  const rise=smooth((t-(s.coverOpening?2.5:.3))/1.4)*closing;root.scale.y=Math.max(.001,rise);root.visible=rise>.001;
  const reveal=s.revealBush?smooth((t-(s.revealAt??2))/(s.revealDuration||3)):0;
  if(leaves){for(const hinge of leaves.children)hinge.rotation.y=hinge.userData.side*reveal*1.28;}
  if(count){count.rotation.x=-Math.PI/2*(1-smooth((t-(s.countAt??3))/1.5));count.visible=t>(s.countAt??3);}
  if(butterfly){const q=smooth((t-1.7)/8);butterfly.position.x=-1.8+q*4.2;butterfly.position.y=1.55+Math.sin(t*1.4)*.22;for(const wing of butterfly.children)wing.rotation.y=wing.userData.side*(.25+Math.sin(t*6)*.75);}
  // Trocas de pose no mesmo instante, sem um segundo de duplicação.
  for(const {pivot,data:a} of actors){
   if(a.enter!==undefined&&t<a.enter){pivot.visible=false;continue;}
   if(a.exit!==undefined&&t>=a.exit){pivot.visible=false;continue;}
   if(a.mainSheep&&s.id==='reencontro'){
    const q=smooth((t-(s.approachAt??5))/((s.approachEnd??10)-(s.approachAt??5)));pivot.position.x=-1.55+1.75*q;pivot.rotation.z=Math.sin(t*4)*.015;
   }
  }
  window.popupOvelhaAudit={scene:s.id,reveal,carriersVisible:actors.filter(a=>a.data.carrying&&a.pivot.visible).length,sheepOnGroundVisible:actors.filter(a=>a.data.mainSheep&&a.pivot.visible).length,mainPastors:actors.filter(a=>a.data.asset.startsWith('pastor')&&a.pivot.visible).length,number:s.countLabel||null,cast:actors.filter(a=>a.pivot.visible).map(a=>a.data.asset)};
 }};
}
