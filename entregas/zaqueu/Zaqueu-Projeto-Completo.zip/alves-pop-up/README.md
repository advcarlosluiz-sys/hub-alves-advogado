# Zaqueu — Um Encontro que Mudou Tudo

História narrada em livro pop-up 3D para Contos de Gaitolé, adaptação infantil de Lucas 19:1–10. Dez cenas, 3min23s aproximadamente, 1280×720, 24 fps, H.264/AAC estéreo.

## Assistir

Abra `output/zaqueu.mp4`. No ZIP para assistir, extraia tudo e abra `alves-pop-up/ASSISTA-AQUI.mp4`. O vídeo pronto inclui voz, música e legendas; não precisa instalar programas de geração nem executar .cmd.

## Apresentação

Pergunta narrada desde 0,75s, Zaqueu entre os galhos na primeira cena, capa intitulada teal/dourada sobre mesa trabalhada em sala decorada. Ruas de Jericó, mercado, casas, moradores, criança, burrinho e passarinho. Árvore com tronco, galho e duas abas de copa independentes. Subida e descida animadas; troca de poses sem duplicação. Porta articulada, interior da casa, mesa, livro de contas que se fecha e moedas devolvidas. As promessas de dar metade e devolver quatro vezes são narradas e identificadas por placas; as moedas são representação simbólica, não contagem de toda a dívida. Atitudes de reparação sem exigir perdão imediato das pessoas.

## Áudio e legendas

Dez falas sintetizadas com pt-BR-ThalitaMultilingualNeural, ritmo −12%, tom −4Hz. A canção “Desce Dessa Árvore, Zaqueu!” tem 202,8 segundos e toca uma vez, completa, com fundo muito baixo durante as falas e aumento gradual nas pausas. Não foi gerada outra canção nem usada API Noiz. O vocal da canção não é identificado como Thalita. Os versos não possuem sincronização de karaokê. Os tempos das frases da narração vêm do serviço de voz; frases longas foram divididas em blocos menores com tempos proporcionais estimados. Efeitos discretos sintetizados de passos e pássaros.

## Arquivos

- `stories/joao.json`: roteiro principal por compatibilidade com o motor. `stories/zaqueu.json`: cópia do episódio.
- `references/roteiro-fornecido.txt`: texto original preservado.
- `assets/zaqueu/`: novas ilustrações de Zaqueu em seis poses, tronco, copa, casa, banca, burrinho e pássaro. WebP sem perda conferidos por pixels RGBA.
- `assets/elenco/` e `assets/ovelha/cenarios.webp`: arte original de produções anteriores do próprio canal, reutilizada para Jesus, moradores, vila e árvore secundária.
- `engine/zaqueu-props.mjs`: mecanismos articulados e propriedades específicos do episódio.
- `assets/narracao/`: dez MP3, manifesto e SRTs da voz.
- `assets/musica/desce-dessa-arvore-zaqueu.mp3`: original fornecido, preservado integralmente.
- `publicacao/`: capa, miniaturas, título, descrição, capítulos, letra e legendas.

## Editar e exportar

Requer Node.js 22+, Chrome/Chromium/Edge e FFmpeg para gerar outro vídeo. Instale as dependências com `npm ci`, abra com `npm start` e exporte por `npm run render:fast -- --out output/zaqueu.mp4`. Configure CHROME_PATH e FFMPEG_PATH se necessário. O modo da exportação entregue é 720p/24fps. A voz já está incluída. Ao alterar falas, regenere a narração e revise durações, legendas e efeitos; nenhuma chave de API é necessária para assistir ou reexportar esta versão.

## Créditos

Roteiro e música fornecidos pelo autor do Contos de Gaitolé. Arte original gerada para esta adaptação; base visual de papel, programação e montagem Three.js/GSAP/Mira. Voz sintética Microsoft Thalita. Fontes e bibliotecas locais com suas licenças preservadas. Material pronto para revisão do autor; nenhuma publicação no YouTube ou teste A/B de desempenho foi executado.
