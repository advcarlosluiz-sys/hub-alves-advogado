# Pinóquio — Contos de Gaitolé

Filme em livro pop-up 3D com 4min09s, 720p/24fps, narração Thalita pt-BR, música com redução durante as falas, legendas e encerramento do canal.

Para assistir, extraia o ZIP e abra `output/pinoquio.mp4`. No pacote para assistir, abra `ASSISTA-AQUI.mp4`. Nenhum `.cmd` precisa ser executado para assistir.

A pasta `publicacao` contém a miniatura, o título e a descrição. O roteiro em uso é `stories/joao.json`; a cópia identificada pelo conto é `stories/pinoquio.json`.

O motor usa Three.js e GSAP distribuídos com o Mira. Livro, sala, mesa, sombras, viradas de página e mecanismos de papel são renderizados em 3D. Veja `LEIA-ME-PRIMEIRO.txt` para editar ou exportar novamente.
