import * as THREE from '../vendor/three.module.js';
const smooth=v=>{v=Math.max(0,Math.min(1,v));return v*v*(3-2*v)};
export function buildPinocchioProps(parent,s,textures){
 const g=new THREE.Group();parent.add(g);const mat=c=>new THREE.MeshStandardMaterial({color:c,roughness:.9,side:THREE.DoubleSide});const wood=mat('#a57951'),gold=mat('#e9bd64'),paper=mat('#f1deb5');
 function add(geom,material,x,y,z,group=g){const m=new THREE.Mesh(geom,material);m.position.set(x,y,z);m.castShadow=m.receiveShadow=true;group.add(m);return m}
 function shape(points,material,x,y,z,group=g){const q=new THREE.Shape();q.moveTo(...points[0]);for(const p of points.slice(1))q.lineTo(...p);q.closePath();return add(new THREE.ShapeGeometry(q),material,x,y,z,group)}
 if(s.workbench){const x=s.id==='oficina'?.6:-3.3,z=s.id==='oficina'?-.1:-.7;add(new THREE.BoxGeometry(2.6,.12,1.1),wood,x,.8,z);for(const dx of [-1,1])for(const dz of [-.4,.4])add(new THREE.BoxGeometry(.1,.8,.1),wood,x+dx,.4,z+dz);for(let n=0;n<5;n++)add(new THREE.BoxGeometry(.26,.025,.09),paper,x-.8+n*.3,.89,z+.2*Math.sin(n));}
 let book=null;
 if(s.schoolbook){book=new THREE.Group();g.add(book);add(new THREE.BoxGeometry(.55,.65,.1),mat('#648579'),0,0,0,book);add(new THREE.BoxGeometry(.48,.58,.11),paper,0,0,.015,book);book.position.set(.45,1.05,1.4);book.rotation.z=-.15;}
 let gate=null,stair=null;
 if(s.theater){
  add(new THREE.BoxGeometry(4.2,.2,1.5),wood,0,.1,.1);
  for(const x of [-2.2,2.2]){const toy=new THREE.Group();g.add(toy);add(new THREE.SphereGeometry(.16,12,8),paper,x,1.35,-.2,toy);add(new THREE.BoxGeometry(.28,.5,.14),mat(x<0?'#7f9d8a':'#ba8b73'),x,.95,-.2,toy);for(const dx of [-.1,.1])add(new THREE.BoxGeometry(.07,.4,.08),wood,x+dx,.5,-.2,toy);}
  stair=new THREE.Group();g.add(stair);for(let n=0;n<3;n++)add(new THREE.BoxGeometry(1.1,.08+n*.08,.3),wood,2.5,(.08+n*.08)/2,1.1-n*.3,stair);
  gate=new THREE.Group();gate.position.set(3,.1,-.2);g.add(gate);for(const dx of [-.3,0,.3])add(new THREE.BoxGeometry(.06,1.6,.06),wood,dx,.8,0,gate);add(new THREE.BoxGeometry(.75,.07,.07),gold,0,.4,0,gate);
 }
 let nose=null;
 if(s.nose){nose=new THREE.Group();g.add(nose);nose.position.set(.31,1.87,1.47);for(let n=0;n<5;n++){const m=add(new THREE.BoxGeometry(.2,.085,.075),mat(n%2?'#d0a36e':'#dfb880'),.1+n*.2,0,0,nose);}const tip=add(new THREE.ConeGeometry(.055,.15,4),wood,1.075,0,0,nose);tip.rotation.z=-Math.PI/2;}
 const sparks=[];if(s.magic)for(let n=0;n<18;n++)sparks.push(add(new THREE.OctahedronGeometry(.035+(n%3)*.009,0),new THREE.MeshBasicMaterial({color:'#ffe4a0'}),0,0,0));
 const waves=[];
 if(s.sea){for(let row=0;row<3;row++){const q=new THREE.Shape();q.moveTo(-5.6,0);for(let n=0;n<=40;n++){const x=-5.6+n*.28;q.lineTo(x,.2+Math.sin(n*.9+row)*.1);}q.lineTo(5.6,-.14);q.lineTo(-5.6,-.14);q.closePath();waves.push(add(new THREE.ShapeGeometry(q),mat(['#79b4bd','#6ba3b1','#8bc0c6'][row]),0,.12,-2.2+row*1.8));}}
 function boat(x,z,w=2.5){const b=new THREE.Group();b.position.set(x,.12,z);g.add(b);shape([[-w/2,.15],[-w*.35,-.05],[w*.35,-.05],[w/2,.3]],wood,0,0,0,b);add(new THREE.BoxGeometry(w*.8,.08,.65),mat('#ba9168'),0,.12,-.15,b);for(const dx of [-w*.25,w*.25])add(new THREE.BoxGeometry(.08,.6,.06),wood,dx,.4,-.4,b);return b;}
 const boats=[];if(s.boats){boats.push(boat(s.id==='resgate'?3.2:2.2,.75));if(s.id==='mar')boats.push(boat(-1.2,1.1,2.5));}
 if(s.raft)add(new THREE.BoxGeometry(3.2,.1,.95),wood,0,.2,1.5);
 let fishFlap=null,jaw=null;
 if(s.fish){
  const fish=new THREE.Group();g.add(fish);const interior=s.fish==='interior';fish.position.set(interior?0:-1,2,-1.8);if(!interior)fish.scale.setScalar(s.fish==='open'?.62:.55);
  const fishMat=asset=>new THREE.MeshStandardMaterial({map:textures[asset],alphaTest:.45,side:THREE.DoubleSide,roughness:1});
  add(new THREE.PlaneGeometry(8.5,4.4),fishMat(interior?'peixe_aberto_pin':'peixe_fechado_pin'),0,0,0,fish);
  if(interior){
   fishFlap=new THREE.Group();fishFlap.position.set(-4.25,0,.04);fish.add(fishFlap);add(new THREE.PlaneGeometry(8.5,4.4),fishMat('peixe_fechado_pin'),4.25,0,0,fishFlap);
   const innerBoat=boat(.6,-1.25,3.3);innerBoat.position.y=.98;
  }else if(s.fish==='open'){
   const mouth=add(new THREE.CircleGeometry(.23,20),mat('#476579'),3.85,-.2,.055,fish);mouth.scale.y=.75;
   jaw=new THREE.Group();jaw.position.set(3.65,-.35,.07);fish.add(jaw);shape([[0,0],[.6,.1],[.5,-.18],[-.15,-.12]],mat('#8eacb9'),0,0,0,jaw);
  }
 }

 if(s.lamp){const y=s.id==='reencontro'?1.35:.55,x=s.id==='reencontro'?.6:-2.6,z=s.id==='reencontro'?-1.1:.7;add(new THREE.BoxGeometry(.3,.38,.24),mat('#e1b965'),x,y,z);add(new THREE.BoxGeometry(.2,.26,.25),new THREE.MeshBasicMaterial({color:'#ffdf95'}),x,y+.01,z+.01);}
 if(s.care){add(new THREE.CylinderGeometry(.09,.075,.2,12),mat('#b8d5ce'),-1,1.05,1.1);add(new THREE.BoxGeometry(.65,.6,.04),mat('#a6b5a0'),-2.1,.85,.86);}
 return {update(t,closing){
  g.scale.y=Math.max(.001,smooth((t-.2)/1.2)*closing);
  if(book)book.position.x=.45+smooth((t-4)/8)*.5;
  if(nose){let amount=s.nose.initial?1:smooth((t-s.nose.growAt)/2.2);if(s.nose.shrinkAt!==undefined)amount=1-smooth((t-s.nose.shrinkAt)/2.2);nose.visible=amount>.005;nose.scale.x=Math.max(.001,amount);}
  if(gate){const q=s.closeTheater===undefined?1:smooth((t-s.closeTheater)/2);gate.rotation.y=(1-q)*Math.PI/2;if(stair)stair.rotation.z=-q*.65;}
  sparks.forEach((m,n)=>{const a=n*2.4+t*.35,r=s.transformAt===undefined?1.5:.7;m.position.set(.2+Math.cos(a)*r,.5+(n%6)*.4+Math.sin(t*2+n)*.08,1.2+Math.sin(a)*.4);m.scale.setScalar(.55+.45*Math.sin(t*2+n)**2);});
  waves.forEach((m,n)=>{m.position.y=.12+Math.sin(t*1.3+n)*.025;});boats.forEach((b,n)=>b.rotation.z=Math.sin(t*1.6+n)*.025);
  if(fishFlap){fishFlap.rotation.y=-smooth((t-2)/3)*1.13;fishFlap.visible=t<5.3;}
  if(jaw)jaw.rotation.z=-smooth((t-2)/3)*(s.fish==='open'?.55:.1);
 }};
}
