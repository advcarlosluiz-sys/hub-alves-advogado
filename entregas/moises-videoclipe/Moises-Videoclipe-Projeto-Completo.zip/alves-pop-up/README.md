# Um Caminho no Mar — Moisés — videoclipe em livro pop-up

Canção original enviada pelo usuário na íntegra, aproximadamente 4min41s (280,8333 segundos). Horizontal 1280 × 720, 24 fps, H.264/AAC estéreo. Somente a canção, sem narrador adicional ou efeitos sobrepostos.

## Assistir

Abra `output/moises-videoclipe.mp4`. No ZIP para assistir, extraia tudo e abra `alves-pop-up/ASSISTA-AQUI.mp4`. Não é necessário executar `.cmd` ou instalar o gerador para assistir ao MP4 pronto.

## Montagem

30 trechos com variações reais de câmera 3D e movimentos suaves acompanhando pulsações estimadas. Capa azul e dourada, livro sobre mesa em sala decorada, Moisés, Miriã, famílias, idosos, animais, deserto, praia e mar com três camadas articuladas por lado. As famílias aguardam na areia e só avançam quando a passagem seca está aberta. Sem perseguições, armas ou imagens de afogamento. Encerramento com marca, perfis, inscrição e indicação musical de A Rainha Ester.

A montagem temática considera a letra embutida no MP3. A pulsação foi estimada pelo fluxo espectral; não há alinhamento de palavras ou marcação exata de seções vocais. Não é karaokê.

## Arquivos

- `stories/joao.json`: roteiro principal do motor, com nome mantido por compatibilidade. Cópia em `stories/moises-videoclipe.json`.
- `references/montagem-videoclipe.json`: tempos dos 30 trechos e intervalos das ações originais.
- `references/letra-musica-fornecida.txt`: letra extraída da canção enviada.
- `references/roteiro-fornecido.txt`: roteiro da história narrada que originou as cenas. O videoclipe utiliza apenas a canção.
- `assets/moises/`: personagens, animais e seis cenários de papel. Arte compactada em WebP sem perda, com comparação de cada pixel RGBA com os PNGs de origem.
- `engine/moises-props.mjs`: mar articulado, cajado, nuvem, vento visual, peixes e objetos do acampamento.
- `assets/musica/um-caminho-no-mar.mp3`: original preservado sem cortes, repetição ou substituição do vocal.
- `publicacao/`: capa, letra, título, descrição e duas miniaturas com indicação VIDEOCLIPE.

## Editar e exportar

Requer Node.js 22+, Chrome/Chromium/Edge e FFmpeg. Execute `npm ci` e `npm start` para visualizar. Exporte com `npm run render:fast -- --out output/moises-videoclipe.mp4`. Use `CHROME_PATH` e `FFMPEG_PATH` se necessário. A geração Noiz está desativada; nenhuma chave é necessária para exportar a música incluída.

## Créditos

Contos de Gaitolé: YouTube @gaitolé; TikTok @gaitole0. Música e letra enviadas pelo usuário, inspiradas em Êxodo 14–15. Ilustrações e mecanismos preparados para a história de Moisés. Licença e avisos originais Mira preservados em LICENSE-MIRA e vendor. Nenhum teste A/B de desempenho nem publicação no YouTube foi realizado.
