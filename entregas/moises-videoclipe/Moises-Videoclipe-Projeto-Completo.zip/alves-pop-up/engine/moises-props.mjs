import * as THREE from '../vendor/three.module.js';
const smooth=x=>{x=Math.max(0,Math.min(1,x));return x*x*(3-2*x)};
export function buildMoisesProps(parent,s,textures={}){
 const g=new THREE.Group();parent.add(g);
 const mat=c=>new THREE.MeshStandardMaterial({color:c,roughness:1,side:THREE.DoubleSide});
 const sand=mat('#d9bc88'),cream=mat('#ece2c7'),wood=mat('#93704d'),clay=mat('#ad8263'),green=mat('#8a9a70'),blue=mat('#87b4bb'),white=mat('#c9e4df');
 function mesh(geo,m,x=0,y=0,z=0,group=g){const a=new THREE.Mesh(geo,m);a.position.set(x,y,z);a.castShadow=a.receiveShadow=true;group.add(a);return a}
 function box(w,h,d,m,x,y,z,group){return mesh(new THREE.BoxGeometry(w,h,d),m,x,y,z,group)}
 function cyl(r1,r2,h,m,x,y,z,group){return mesh(new THREE.CylinderGeometry(r1,r2,h,14),m,x,y,z,group)}
 function tex(draw,w=768,h=384){const c=document.createElement('canvas');c.width=w;c.height=h;draw(c.getContext('2d'),w,h);const t=new THREE.CanvasTexture(c);t.colorSpace=THREE.SRGBColorSpace;return t}
 const seaMap=tex((c,w,h)=>{const grd=c.createLinearGradient(0,0,0,h);grd.addColorStop(0,'#a5d4cf');grd.addColorStop(.6,'#6ea9b2');grd.addColorStop(1,'#477d9b');c.fillStyle=grd;c.fillRect(0,0,w,h);c.strokeStyle='#c8e5dd';c.lineWidth=3;for(let n=0;n<32;n++){const xx=(n*127)%w,yy=(n*67)%h;c.beginPath();c.ellipse(xx,yy,70,10,0,0,Math.PI);c.stroke();}c.fillStyle='rgba(244,236,204,.14)';for(let n=0;n<1200;n++)c.fillRect((n*113)%w,(n*79)%h,2,2)});
 const waterMat=new THREE.MeshStandardMaterial({map:seaMap,roughness:1,side:THREE.DoubleSide});
 let sea=null,staff=null;const walls=[],floors=[],ribbons=[],flags=[];
 function jug(x,z){cyl(.11,.17,.36,clay,x,.21,z);cyl(.08,.11,.11,cream,x,.44,z);const handle=mesh(new THREE.TorusGeometry(.12,.025,6,16),clay,x+.15,.27,z);}
 function basket(x,z){cyl(.25,.2,.28,wood,x,.17,z);for(let n=0;n<5;n++)mesh(new THREE.SphereGeometry(.075,8,6),cream,x-.13+(n%3)*.13,.34,z-.05+Math.floor(n/3)*.12);mesh(new THREE.TorusGeometry(.22,.025,6,20,Math.PI),wood,x,.31,z);}
 function reeds(x,z){for(let n=0;n<4;n++){const a=box(.025,.5+n*.06,.018,green,x+n*.08,.28+n*.03,z);a.rotation.z=(n-1.5)*.15;const b=mesh(new THREE.CircleGeometry(.09,5),green,x+n*.08+.055,.34,z+.01);b.scale.y=.4;b.rotation.z=.4;}}
 if(s.campProps&&!['opening','open'].includes(s.seaMode)){basket(-4.8,2.6);jug(4.7,2.6);reeds(-5,1);reeds(5,1.5);for(let n=0;n<5;n++){const a=mesh(new THREE.DodecahedronGeometry(.12+n%2*.03),sand,-4.8+n*.2,.1,-.5);a.scale.y=.5;}}
 if(s.restProps){box(1.8,.025,1.0,blue,-1.1,.05,2.2);for(let n=0;n<5;n++)box(1.75,.008,.025,cream,-1.1,.069,1.8+n*.16);jug(.4,2.6);basket(3.9,2.7);}
 if(s.desertProps){for(let n=0;n<6;n++){const x=n<3?-4+n*.6:3+(n-3)*.6;const a=mesh(new THREE.SphereGeometry(.23,10,7),sand,x,.12,-.8+(n%2)*.4);a.scale.set(1.6,.65,1);}}
 if(s.cloudColumn){const cloud=new THREE.Group();cloud.position.set(-3.9,0,-1.7);g.add(cloud);for(let n=0;n<8;n++){const p=mesh(new THREE.CircleGeometry(.45+(n%3)*.05,16),cream,Math.sin(n*2)*.16,.8+n*.42,0,cloud);p.scale.x=1.3;}box(.16,3.5,.03,cream,0,2.1,0,cloud);}
 if(s.nightProps){for(let n=0;n<18;n++){const sh=new THREE.Shape();for(let k=0;k<10;k++){const a=k*Math.PI/5,r=k%2?.032:.075,x=Math.sin(a)*r,y=Math.cos(a)*r;k?sh.lineTo(x,y):sh.moveTo(x,y)}sh.closePath();mesh(new THREE.ShapeGeometry(sh),cream,-3.5+(n*1.31)%7,3.45+(n%4)*.25,-2.65);}}
 if(s.seaMode==='calm'){
  box(10.5,.06,3.3,waterMat,0,.09,-1.7);
  for(let n=0;n<4;n++){const pts=[];for(let k=0;k<45;k++){const x=-5.1+k*10.2/44;pts.push(new THREE.Vector3(x,.14,-.2-n*.65+Math.sin(k*.38+n)*.08));}g.add(new THREE.Line(new THREE.BufferGeometry().setFromPoints(pts),new THREE.LineBasicMaterial({color:'#d2e6dd'})));}
 }else if(s.seaMode){
  sea=new THREE.Group();g.add(sea);if(s.distantSea){sea.position.set(0,0,-2.15);sea.scale.set(.62,.62,.38);}
  for(const side of [-1,1]){
   const floor=box(5.6,.05,6.5,waterMat,side*2.95,.12,0,sea);floors.push({floor,side});
   const base=new THREE.Group();base.position.set(side*3.3,.16,0);base.rotation.y=Math.PI/2;sea.add(base);
   const hinge=new THREE.Group();base.add(hinge);
   const sh=new THREE.Shape();sh.moveTo(-3.2,0);sh.lineTo(3.2,0);
   for(let n=32;n>=0;n--){const x=-3.2+n*.2,y=2.6+.32*x/3.2+.15*Math.sin(x*2.8);sh.lineTo(x,y);}sh.closePath();
   const geo=new THREE.ExtrudeGeometry(sh,{depth:.065,bevelEnabled:false}),pos=geo.attributes.position,uv=geo.attributes.uv;
   for(let k=0;k<pos.count;k++)uv.setXY(k,(pos.getX(k)+3.2)/6.4,pos.getY(k)/3.2);uv.needsUpdate=true;
   mesh(geo,[waterMat,white],0,0,-.033,hinge);
   for(let layer=1;layer<=2;layer++){const a=mesh(geo.clone(),[waterMat,white],0,0,-side*layer*.09,hinge);a.scale.y=1-layer*.13;}
   for(let n=0;n<4;n++){const pts=[];for(let k=0;k<33;k++){const x=-3.15+k*6.3/32;pts.push(new THREE.Vector3(x,.35+n*.43+Math.sin(x*2.4+n)*.09,-side*.225));}hinge.add(new THREE.Line(new THREE.BufferGeometry().setFromPoints(pts),new THREE.LineBasicMaterial({color:'#c8e3db'})));}
   if(textures.peixes){for(let n=0;n<2;n++){const fish=mesh(new THREE.PlaneGeometry(.85,.6),new THREE.MeshStandardMaterial({map:textures.peixes,alphaTest:.45,side:THREE.DoubleSide,roughness:1}),-1.4+n*2.3,.9+n*.45,-side*.23,hinge);fish.rotation.y=-Math.PI/2;fish.castShadow=false;}}
   walls.push({hinge,side});
  }
  if(s.seaMode==='opening'){for(let n=0;n<4;n++){const pts=[];for(let k=0;k<22;k++)pts.push(new THREE.Vector3(-3+k*.28,2.9+n*.16,-1.6+Math.sin(k*.3+n)*.14));const a=new THREE.Line(new THREE.BufferGeometry().setFromPoints(pts),new THREE.LineBasicMaterial({color:'#d9e6df',transparent:true,opacity:.45}));g.add(a);ribbons.push(a);}}
 }
 const person=s.actors.find(a=>a.asset==='moises'||a.asset==='moises_erguendo');
 if(person){const raised=person.asset==='moises_erguendo';staff=new THREE.Group();staff.position.set(person.x+person.width*.41,person.height*(raised?.94:.64),person.z+.035);g.add(staff);const len=raised?2.95:2.4;const shaft=cyl(.032,.04,len,wood,0,raised?-.7:-.5,0,staff);mesh(new THREE.TorusGeometry(.14,.031,6,16,Math.PI*.7),wood,.08,len/2-(raised?.64:.44),0,staff);}
 if(s.celebrationProps){basket(-3.7,2.8);basket(2.8,2.8);jug(3.8,2.7);for(let n=0;n<4;n++){const a=box(.65,.025,.45,[cream,blue,clay][n%3],-2.7+n*.7,.06,2.85);a.rotation.y=(n-1.5)*.15;}for(const x of [-4.6,4.6])box(.045,3.3,.045,wood,x,1.65,-1.5);const pts=[];for(let n=0;n<=30;n++){const x=-4.6+n*9.2/30;pts.push(new THREE.Vector3(x,3.35-.35*(1-(x/4.6)**2),-1.5));}g.add(new THREE.Line(new THREE.BufferGeometry().setFromPoints(pts),new THREE.LineBasicMaterial({color:'#b49a6b'})));for(let n=0;n<10;n++){const x=-4.3+n*.95,y=3.35-.35*(1-(x/4.6)**2);const a=box(.33,.4,.018,[cream,blue,clay][n%3],x,y-.2,-1.49);flags.push(a);}}
 return{update(t,closing){g.scale.y=Math.max(.001,smooth((t-.25)/1.15)*closing);let q=s.seaMode==='opening'?smooth((t-3.5)/8):s.seaMode==='closing'?1-smooth((t-5)/8):1;walls.forEach(({hinge,side})=>hinge.rotation.x=-side*Math.PI/2*(1-q));floors.forEach(({floor,side})=>{floor.scale.x=(5.6-1.8*q)/5.6;floor.position.x=side*(2.95+.9*q)});if(staff){staff.rotation.z=s.raiseStaff?.18*(1-smooth((t-2)/6)):.03;staff.position.z=person.z+.035+(person.walkDepth||0)*smooth((t-2)/12);if(s.seaMode==='opening')staff.position.z=3.55+(person.z-3.55)*smooth((t-11.5)/5)+.035;staff.position.x=person.x+person.width*.41+(person.walk||0)*smooth((t-2)/5);}ribbons.forEach((a,n)=>{a.position.x=Math.sin(t*.6+n)*.12;a.material.opacity=.25+.15*Math.sin(t*.7+n)});flags.forEach((a,n)=>a.rotation.z=Math.sin(t*.7+n)*.04);}};
}
