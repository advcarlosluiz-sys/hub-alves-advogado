import * as THREE from '../vendor/three.module.js';
const smooth=v=>{v=Math.max(0,Math.min(1,v));return v*v*(3-2*v)};
export function buildPrincessProps(parent,scene){
 const group=new THREE.Group();parent.add(group);
 const paper=color=>new THREE.MeshStandardMaterial({color,roughness:.9,side:THREE.DoubleSide});
 const add=(geometry,material,x,y,z)=>{const m=new THREE.Mesh(geometry,material);m.position.set(x,y,z);m.castShadow=true;m.receiveShadow=true;group.add(m);return m};
 if(scene.pond){
  const border=add(new THREE.CylinderGeometry(1,1,.065,48),paper('#c8c798'),1.2,.06,.65);border.scale.set(2.35,1,1.55);
  const water=add(new THREE.CircleGeometry(1,48),paper('#67aeb9'),1.2,.099,.65);water.rotation.x=-Math.PI/2;water.scale.set(2.2,1.4,1);
  for(let k=0;k<5;k++){const ring=add(new THREE.TorusGeometry(.22+k*.19,.012,4,40),paper('#c3e1dc'),1.35,.108,.68);ring.rotation.x=Math.PI/2;ring.scale.y=.65;}
  const stone=add(new THREE.DodecahedronGeometry(.38,0),paper('#b3aa8a'),.9,.22,.4);stone.scale.set(1.5,.5,1);
  for(let i=0;i<7;i++){
   const x=2.9+Math.sin(i*2)*.4,z=-.25+i*.25;
   const stem=add(new THREE.BoxGeometry(.025,.5+i%3*.12,.025),paper('#637b40'),x,.32,z);stem.rotation.z=.1*Math.sin(i);
   add(new THREE.CylinderGeometry(.035,.035,.16,6),paper('#a28148'),x,.65+i%3*.06,z);
  }
  if(scene.id==='resgate')for(let i=0;i<3;i++){
   const fish=add(new THREE.CircleGeometry(.13,12),paper(['#efc86a','#e7a47e','#eee1ab'][i]),1.6+i*.45,.115,.2+i*.5);fish.rotation.x=-Math.PI/2;fish.scale.set(1.7,.6,1);
  }
 }
 let ball=null;
 if(scene.goldenBall){ball=add(new THREE.SphereGeometry(.16,16,10),new THREE.MeshStandardMaterial({color:'#f9cb45',metalness:.55,roughness:.32}),-1.2,1.3,1.1);}
 const sparks=[];
 if(scene.fireflies)for(let i=0;i<16;i++){
  const m=add(new THREE.OctahedronGeometry(.028+(i%3)*.006),new THREE.MeshBasicMaterial({color:i%2?'#ffe498':'#fff4c9'}),0,0,0);sparks.push(m);
 }
 let halo=null;
 if(scene.magicTransform){halo=add(new THREE.TorusGeometry(.9,.035,6,48),new THREE.MeshBasicMaterial({color:'#ffda78',transparent:true,opacity:.75}),1.1,1.2,.5);}
 if(scene.celebration){
  for(let i=0;i<15;i++){
   const shape=new THREE.Shape();shape.moveTo(-.19,0);shape.lineTo(.19,0);shape.lineTo(0,-.38);shape.closePath();
   const flag=add(new THREE.ShapeGeometry(shape),paper(['#d77780','#8aaf95','#e4bd67'][i%3]),-4.5+i*.64,3.3-Math.sin(i/14*Math.PI)*.5,-2.1);
   flag.rotation.z=Math.sin(i)*.06;
  }
 }
 return {update(t,closing){
  if(ball){
   ball.visible=true;
   if(scene.goldenBall==='jardim')ball.position.set(-1.2,1.3+Math.abs(Math.sin(t*1.6))*.28,1.1);
   if(scene.goldenBall==='mergulho'){const q=smooth((t-3)/4);ball.position.set(-1.2+q*2.6,Math.max(.12,1.4+Math.sin(q*Math.PI)*1.1-1.7*q),1.1-q*.4);ball.visible=t<7;}
   if(scene.goldenBall==='resgate'){const q=smooth((t-7.5)/3);ball.visible=t>7.1;ball.position.set(1.1-2.3*q,.8+.5*q,.6+.5*q);}
  }
  sparks.forEach((s,i)=>{const a=i*2.4+t*.25,r=scene.magicTransform?(.65+.4*Math.sin(i)):2.7;s.position.set(1.1+Math.cos(a)*r,.5+(i%5)*.32+Math.sin(t*1.7+i)*.12,.6+Math.sin(a)*.7);s.scale.setScalar(.6+.4*Math.sin(t*2+i)**2);});
  if(halo){const q=smooth((t-8.3)/1.7);halo.visible=t>8.3&&t<11.8;halo.scale.setScalar(.3+q*1.2);halo.rotation.z=t;halo.material.opacity=.8*(1-smooth((t-10.3)/1.5));}
  group.scale.y=Math.max(.001,smooth((t-.2)/1.5)*closing);
 }};
}
