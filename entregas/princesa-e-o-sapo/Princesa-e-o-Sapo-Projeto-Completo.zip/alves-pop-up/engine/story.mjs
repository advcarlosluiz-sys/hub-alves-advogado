import { MOTIONS } from "./actor-motion.mjs";
export const ASSETS = Object.freeze(["princesa_clara_ajoelhada","princesa_clara_sentada","nenufar_clara","libelula_clara","princesa_clara","sapo_clara","principe_clara","castelo_clara","fonte_clara","arco_palacio","caracol_clara","convidada_clara","convidado_clara",
  "joao",
  "mae",
  "casa",
  "vila",
  "colinas",
  "nuvem",
  "vaca",
  "castelo",
  "gigante",
  "galinha",
  "feijao",
  "folha",
  "porquinho_palha",
  "porquinho_madeira",
  "porquinho_tijolos",
  "lobo",
  "casa_palha",
  "casa_madeira",
  "casa_tijolos",
  "arvore",
  "vento",
  "rapunzel", "rapunzel_janela", "principe", "feiticeira", "cavalo_rapunzel", "torre_rapunzel", "torre_aberta", "vila_rapunzel", "ponte_rapunzel",
  "coelho", "esquilo", "flores", "tronco",
  "biombo", "mesa_lanche", "passarinho", "borboleta",
  "chapeuzinho", "mae_chapeuzinho", "vovo", "guarda",
  "lobo_floresta", "lobo_cama", "casa_vovo", "arvore_floresta",
  "pata", "patinho_amarelo", "patinho_cinza", "cisne",
  "celeiro", "arvore_verde", "arvore_outono", "arvore_inverno",
]);
export function validateStory(story) {
  if (
    !story ||
    typeof story.title !== "string" ||
    !story.title.trim() ||
    !Array.isArray(story.scenes) ||
    !story.scenes.length
  )
    throw Error("Roteiro precisa de título e cenas");
  if (
    story.endCard &&
    (!Number.isFinite(story.endCard.duration) ||
      story.endCard.duration < 3 ||
      story.endCard.duration > 15 ||
      typeof story.endCard.youtube?.name !== "string" ||
      typeof story.endCard.youtube?.handle !== "string" ||
      typeof story.endCard.tiktok?.handle !== "string")
  )
    throw Error("Tela final inválida");
  if (story.presentation) {
    const p=story.presentation;
    if (!Number.isFinite(p.introDuration) || p.introDuration<0 || p.introDuration>15 ||
        (p.cameraScale!==undefined && (!Number.isFinite(p.cameraScale) || p.cameraScale<0.9 || p.cameraScale>1.6)) ||
        (p.coverImage!==undefined && (!/^(assets|publicacao)\/[a-zA-Z0-9_./-]+\.(png|jpg)$/.test(p.coverImage) || p.coverImage.includes(".."))))
      throw Error("Apresentação do livro inválida");
  }
  const ids = new Set();
  let duration = 0;
  for (const s of story.scenes) {
    if (!s.id || ids.has(s.id))
      throw Error("Identificador de cena ausente ou repetido");
    ids.add(s.id);
    if (!Number.isFinite(s.duration) || s.duration < 3 || s.duration > 120)
      throw Error("Duração de cena inválida");
    if (typeof s.caption !== "string") throw Error("Legenda ausente");
    for (const key of ["from", "to", "target"])
      if (
        !Array.isArray(s.camera?.[key]) ||
        s.camera[key].length !== 3 ||
        !s.camera[key].every(Number.isFinite)
      )
        throw Error("Câmera inválida");
    if (!Array.isArray(s.actors) || s.actors.length > 60)
      throw Error("Atores inválidos");
    for (const a of s.actors) {
      if (a.motion) {
        if (!MOTIONS.includes(a.motion.type))
          throw Error("Movimento desconhecido");
        if (
          !Number.isFinite(a.motion.start) ||
          !Number.isFinite(a.motion.end) ||
          a.motion.start < 0 ||
          a.motion.end <= a.motion.start
        )
          throw Error("Intervalo de movimento inválido");
        for (const field of ["dx", "dy"])
          if (
            a.motion[field] !== undefined &&
            !Number.isFinite(a.motion[field])
          )
            throw Error("Deslocamento inválido");
      }

      if (!ASSETS.includes(a.asset))
        throw Error("Asset desconhecido: " + a.asset);
      for (const k of ["x", "z", "width", "height"])
        if (!Number.isFinite(a[k])) throw Error("Dimensão/posição inválida");
      if (a.width <= 0 || a.height <= 0 || a.width > 25 || a.height > 25)
        throw Error("Dimensão fora dos limites");
      for (const k of ["y", "walk", "enter"])
        if (a[k] !== undefined && !Number.isFinite(a[k]))
          throw Error("Parâmetro de ator inválido");
    }
    duration += s.duration;
  }
  if (
    !Number.isFinite(story.duration) ||
    Math.abs(duration - story.duration) > 0.001
  )
    throw Error("Duração total difere da soma das cenas");
  return story;
}
export function locateScene(story, time) {
  const t = Math.min(story.duration, Math.max(0, Number(time) || 0));
  let start = 0;
  for (let index = 0; index < story.scenes.length; index++) {
    const scene = story.scenes[index];
    if (t < start + scene.duration || index === story.scenes.length - 1)
      return { index, scene, local: t - start, start, time: t };
    start += scene.duration;
  }
}

export const ASSET_FILES = {
  porquinho_palha: {
    file: "assets/porquinhos/personagens.png",
    cell: 0,
    columns: 4,
  },
  porquinho_madeira: {
    file: "assets/porquinhos/personagens.png",
    cell: 1,
    columns: 4,
  },
  porquinho_tijolos: {
    file: "assets/porquinhos/personagens.png",
    cell: 2,
    columns: 4,
  },
  lobo: { file: "assets/porquinhos/personagens.png", cell: 3, columns: 4 },
  casa_palha: { file: "assets/porquinhos/casas.png", cell: 0, columns: 4 },
  casa_madeira: { file: "assets/porquinhos/casas.png", cell: 1, columns: 4 },
  casa_tijolos: { file: "assets/porquinhos/casas.png", cell: 2, columns: 4 },
  arvore: { file: "assets/porquinhos/casas.png", cell: 3, columns: 4 },
};

Object.assign(ASSET_FILES, Object.fromEntries(["pata", "patinho_amarelo", "patinho_cinza", "cisne"].map((name, cell) => [name, {file: "assets/patinho/personagens.png", cell, columns: 4}])));
Object.assign(ASSET_FILES, Object.fromEntries(["celeiro", "arvore_verde", "arvore_outono", "arvore_inverno"].map((name, cell) => [name, {file: "assets/patinho/cenarios.png", cell, columns: 4}])));

Object.assign(ASSET_FILES, Object.fromEntries(["chapeuzinho", "mae_chapeuzinho", "vovo", "guarda"].map((name, cell) => [name, {file: "assets/chapeuzinho/personagens.png", cell, columns: 4}])));
Object.assign(ASSET_FILES, Object.fromEntries(["lobo_floresta", "lobo_cama", "casa_vovo", "arvore_floresta"].map((name, cell) => [name, {file: "assets/chapeuzinho/cenarios.png", cell, columns: 4}])));

Object.assign(ASSET_FILES, {
  biombo: {file:"assets/chapeuzinho/objetos.png",rect:[0,0,647,724]},
  mesa_lanche: {file:"assets/chapeuzinho/objetos.png",rect:[648,0,570,724]},
  passarinho: {file:"assets/chapeuzinho/objetos.png",rect:[1218,0,505,724]},
  borboleta: {file:"assets/chapeuzinho/objetos.png",rect:[1723,0,449,724]},
});

Object.assign(ASSET_FILES, Object.fromEntries([ ["coelho",[0,0,500,724]], ["esquilo",[520,0,545,724]], ["flores",[1065,0,530,724]], ["tronco",[1595,0,577,724]] ].map(([name,rect])=>[name,{file:"assets/detalhes/floresta.png",rect}])));

Object.assign(ASSET_FILES,Object.fromEntries(["rapunzel","principe","feiticeira","cavalo_rapunzel"].map((name,cell)=>[name,{file:"assets/rapunzel/personagens.png",cell,columns:4}])));
Object.assign(ASSET_FILES,Object.fromEntries(["torre_rapunzel","torre_aberta","vila_rapunzel","ponte_rapunzel"].map((name,cell)=>[name,{file:"assets/rapunzel/cenarios.png",cell,columns:4}])));
ASSET_FILES.rapunzel_janela={file:"assets/rapunzel/personagens.png",cell:0,columns:4};

Object.assign(ASSET_FILES,{torre_rapunzel:{file:"assets/rapunzel/cenarios.png",rect:[0,0,450,724]},torre_aberta:{file:"assets/rapunzel/cenarios.png",rect:[450,0,392,724]},vila_rapunzel:{file:"assets/rapunzel/cenarios.png",rect:[842,0,775,724]},ponte_rapunzel:{file:"assets/rapunzel/cenarios.png",rect:[1617,0,555,724]}});

Object.assign(ASSET_FILES,{rapunzel:{file:"assets/rapunzel/rapunzel.png"},rapunzel_janela:{file:"assets/rapunzel/rapunzel.png",rect:[0,0,1024,721]},principe:{file:"assets/rapunzel/principe.png"},feiticeira:{file:"assets/rapunzel/feiticeira.png"},cavalo_rapunzel:{file:"assets/rapunzel/cavalo.png"}});

Object.assign(ASSET_FILES,{"princesa_clara": {"file": "assets/princesa/princesa_clara.png"}, "sapo_clara": {"file": "assets/princesa/sapo_clara.png"}, "principe_clara": {"file": "assets/princesa/principe_clara.png"}, "castelo_clara": {"file": "assets/princesa/castelo_clara.png"}, "fonte_clara": {"file": "assets/princesa/fonte_clara.png"}, "arco_palacio": {"file": "assets/princesa/arco_palacio.png"}, "caracol_clara": {"file": "assets/princesa/caracol_clara.png"}});
ASSET_FILES.convidada_clara={file:"assets/chapeuzinho/personagens.png",cell:1,columns:4};
ASSET_FILES.convidado_clara={file:"assets/rapunzel/principe.png"};

Object.assign(ASSET_FILES,{"princesa_clara": {"file": "assets/princesa/personagens.png", "rect": [0, 0, 568, 1024]}, "sapo_clara": {"file": "assets/princesa/personagens.png", "rect": [575, 0, 445, 1024]}, "principe_clara": {"file": "assets/princesa/personagens.png", "rect": [1024, 0, 512, 1024]}, "castelo_clara": {"file": "assets/princesa/cenarios.png", "rect": [0, 0, 730, 820]}, "fonte_clara": {"file": "assets/princesa/cenarios.png", "rect": [730, 0, 505, 820]}, "arco_palacio": {"file": "assets/princesa/cenarios.png", "rect": [1235, 0, 684, 820]}});

Object.assign(ASSET_FILES,{"caracol_clara": {"file": "assets/princesa/objetos.png", "rect": [0, 0, 700, 724]}, "nenufar_clara": {"file": "assets/princesa/objetos.png", "rect": [700, 0, 800, 724]}, "libelula_clara": {"file": "assets/princesa/objetos.png", "rect": [1500, 0, 672, 724]}});

ASSET_FILES.princesa_clara_ajoelhada={file:"assets/princesa/poses.png",rect:[0,0,768,1024]};
ASSET_FILES.princesa_clara_sentada={file:"assets/princesa/poses.png",rect:[768,0,768,1024]};
