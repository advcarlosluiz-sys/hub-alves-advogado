# A Princesa e o Sapo — Contos de Gaitolé

Vídeo em livro pop-up 3D com 3min08s, em 1280 × 720 e 24 quadros/s.

Para assistir, extraia o ZIP e abra `output/princesa-e-o-sapo.mp4`. A narração Thalita em português do Brasil, a música com redução durante as falas, as legendas e o encerramento estão incluídos no vídeo. Nenhum arquivo `.cmd` precisa ser executado para assistir.

A pasta `publicacao` contém a miniatura, o título e a descrição para YouTube. O roteiro está em `stories/princesa-e-o-sapo.json`; `stories/joao.json` é a cópia usada pelo motor, com nome herdado do primeiro conto.

O projeto usa Three.js e GSAP distribuídos com o Mira. Livro, sala, mesa, sombras, viradas de página, lago e objetos são renderizados em 3D. Personagens e cenários são ilustrações originais em recortes de papel. Veja `LEIA-ME-PRIMEIRO.txt` para editar ou exportar novamente.

Marca e música fornecidas pelo autor. Adaptação original do conto tradicional.
