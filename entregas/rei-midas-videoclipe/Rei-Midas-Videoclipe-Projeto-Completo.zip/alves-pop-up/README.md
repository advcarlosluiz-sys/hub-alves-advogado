# Rei Midas — Videoclipe

REI MIDAS — VIDEOCLIPE | CONTOS DE GAITOLÉ

PARA ASSISTIR
Extraia todo o ZIP e abra output/rei-midas-videoclipe.mp4.
No pacote para assistir, o mesmo vídeo se chama ASSISTA-AQUI.mp4.
A canção Midas 2 está incluída no MP4. Não é necessário executar arquivos .cmd.

FORMATO
206,9167 segundos (aproximadamente 3min27s), horizontal 16:9, 1280 x 720, 24 quadros/s.
H.264 com áudio AAC estéreo. Música cantada do arquivo fornecido; sem narração adicional.

PARA PUBLICAR
publicacao/miniatura-youtube.jpg tem 1280 x 720 pixels.
publicacao/titulo.txt e descricao.txt estão prontos para copiar.

PROJETO
O motor usa Three.js e GSAP locais, com 24 planos do livro pop-up.
O roteiro ativo é stories/joao.json: o nome é herdado, mas o conteúdo é o videoclipe Rei Midas.
A cópia identificada está em stories/rei-midas-videoclipe.json.
references/montagem-videoclipe.json registra os planos e suas durações.
references/roteiro-fornecido.txt é a história original usada como referência visual.
Não há legendas de letra ou sincronização labial.

PARA EDITAR OU EXPORTAR NOVAMENTE
Node.js 22+ e Chrome/Edge são necessários somente para editar/exportar.
Abra o projeto com node scripts/serve.mjs e use Ouvir música e Exportar MP4.
A exportação pelo navegador inclui a música local, sem chamadas à Noiz.
Para o renderizador CLI, instale as dependências do package.json e use Chromium e FFmpeg locais.
Não execute geração de voz ou de efeitos: esta produção utiliza somente a canção fornecida.

CRÉDITOS
Música Midas 2.mp3 e marca fornecidas pelo autor.
Original integral preservado em assets/musica/midas-2.mp3.
A canção inteira acompanha o vídeo, com pequeno ajuste de volume e fade nas extremidades.
Ilustrações originais de Rei Midas, Lia, o viajante e os cenários.
