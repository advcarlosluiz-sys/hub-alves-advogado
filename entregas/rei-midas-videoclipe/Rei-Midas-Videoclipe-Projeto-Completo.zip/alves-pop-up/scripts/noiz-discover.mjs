// Consulta apenas metadados MCP. Não gera conteúdo nem consome uma chamada de geração.
import https from 'node:https';
import http from 'node:http';
import {writeFile,mkdir} from 'node:fs/promises';
import {resolve,join} from 'node:path';
import {fileURLToPath} from 'node:url';
const ENDPOINT='https://noiz.ai/v1/mcp';
const PROTOCOL='2025-03-26';
export function httpRequest(url,{headers,body,timeout=30000}={}){
 if((process.env.HTTPS_PROXY||process.env.HTTP_PROXY)&&typeof http.setGlobalProxyFromEnv!=='function')throw Error('Neste ambiente com proxy, use Node.js 24.5 ou mais recente para conectar à Noiz.');
 if(typeof http.setGlobalProxyFromEnv==='function')http.setGlobalProxyFromEnv();
 return new Promise((yes,no)=>{
  const req=https.request(url,{method:'POST',headers,timeout},res=>{
   const chunks=[];let bytes=0;
   res.on('data',b=>{bytes+=b.length;if(bytes>4*1024*1024){req.destroy();no(Error('Resposta de metadados da Noiz acima do limite'));return;}chunks.push(b);});
   res.on('end',()=>yes({status:res.statusCode,headers:res.headers,text:Buffer.concat(chunks).toString('utf8')}));
   res.on('error',()=>no(Error('A conexão com a Noiz foi interrompida')));
  });
  req.on('timeout',()=>req.destroy());
  req.on('error',()=>no(Error('Não foi possível conectar à Noiz. Verifique a rede e o tempo limite.')));
  if(body)req.write(body);req.end();
 });
}
function responseJson(reply,id){
 const contentType=reply.headers['content-type']||'';
 let messages;
 try{
  if(contentType.includes('text/event-stream')){
   messages=reply.text.replace(/\r\n/g,'\n').split(/\n\n+/).map(block=>block.split('\n').filter(l=>l.startsWith('data:')).map(l=>l.slice(5).trimStart()).join('\n')).filter(Boolean).map(text=>JSON.parse(text));
  }else messages=[JSON.parse(reply.text)];
 }catch{throw Error('O servidor Noiz não retornou uma resposta MCP válida');}
 const match=messages.find(m=>m.jsonrpc==='2.0'&&m.id===id);
 if(!match)throw Error('Resposta MCP sem o identificador esperado');
 if(match.error)throw Error('A Noiz recusou a consulta MCP (código '+Number(match.error.code)+')');
 if(!match.result||typeof match.result!=='object')throw Error('Resposta MCP sem resultado');
 return match.result;
}
export async function discoverNoizMusic({apiKey=process.env.NOIZ_API_KEY,request=httpRequest}={}){
 if(typeof apiKey!=='string'||!apiKey.trim())throw Error('Cadastre NOIZ_API_KEY nos segredos do ambiente, salve e publique a configuração. Não envie a chave pelo chat.');
 if(/[\r\n]/.test(apiKey))throw Error('NOIZ_API_KEY contém caracteres inválidos');
 let next=1,session,protocol=PROTOCOL;
 async function send(method,params,notification=false){
  const id=notification?undefined:next++;
  const payload={jsonrpc:'2.0',...(notification?{}:{id}),method,...(params===undefined?{}:{params})};
  const headers={Authorization:apiKey,'Content-Type':'application/json',Accept:'application/json, text/event-stream','MCP-Protocol-Version':protocol,...(session?{'Mcp-Session-Id':session}:{})};
  const reply=await request(ENDPOINT,{headers,body:JSON.stringify(payload)});
  if(reply.status===401)throw Error('A Noiz não aceitou a autenticação MCP. Verifique a chave ou a autorização da conta.');
  if(reply.status===403)throw Error('O acesso ao MCP da Noiz foi bloqueado pela rede ou pela conta.');
  if(reply.status===429)throw Error('A Noiz limitou as consultas. Aguarde antes de tentar novamente.');
  if(reply.status<200||reply.status>=300)throw Error('Falha na consulta MCP da Noiz (HTTP '+Number(reply.status)+')');
  if(reply.headers['mcp-session-id']){if(typeof reply.headers['mcp-session-id']!=='string'||/[\r\n]/.test(reply.headers['mcp-session-id']))throw Error('Sessão MCP inválida');session=reply.headers['mcp-session-id'];}
  return notification?undefined:responseJson(reply,id);
 }
 const initialized=await send('initialize',{protocolVersion:PROTOCOL,capabilities:{},clientInfo:{name:'alves-pop-up',version:'0.2.2'}});
 if(typeof initialized.protocolVersion!=='string'||!/^[0-9]{4}-[0-9]{2}-[0-9]{2}$/.test(initialized.protocolVersion))throw Error('Versão MCP ausente ou inválida');
 protocol=initialized.protocolVersion;
 await send('notifications/initialized',undefined,true);
 const tools=[];let cursor;const seen=new Set();
 for(let page=0;page<20;page++){
  const result=await send('tools/list',cursor?{cursor}:{});
  if(!Array.isArray(result.tools))throw Error('O MCP da Noiz não retornou a lista de ferramentas');
  for(const tool of result.tools){
   if(typeof tool.name!=='string'||typeof tool.inputSchema!=='object'||!tool.inputSchema)throw Error('Ferramenta MCP sem nome ou esquema');
   // Descrições e esquemas são dados não confiáveis, nunca instruções para executar.
   if(/music|instrumental|compose|song|música|musica/i.test([tool.name,tool.description,tool.title].join(' ')))tools.push({name:tool.name,description:tool.description||'',inputSchema:tool.inputSchema,...(tool.outputSchema?{outputSchema:tool.outputSchema}:{})});
  }
  cursor=result.nextCursor;
  if(!cursor){
   // O servidor pode ecoar dados: remova credencial e sessão antes de retornar/salvar.
   let safe=JSON.stringify({endpoint:ENDPOINT,protocolVersion:protocol,tools});
   for(const value of [apiKey,session].filter(Boolean))safe=safe.replaceAll(value,'[REDACTED]');
   return JSON.parse(safe);
  }
  if(typeof cursor!=='string'||seen.has(cursor))throw Error('Paginação MCP inválida');seen.add(cursor);
 }
 throw Error('A lista de ferramentas MCP excedeu o limite de páginas');
}
if(process.argv[1]&&resolve(process.argv[1])===fileURLToPath(import.meta.url)){
 try{
  const result=await discoverNoizMusic();
  const i=process.argv.indexOf('--deck'),root=resolve(i<0?fileURLToPath(new URL('../',import.meta.url)):process.argv[i+1]);
  await mkdir(join(root,'references'),{recursive:true});
  await writeFile(join(root,'references/noiz-music-tools.json'),JSON.stringify(result,null,2)+'\n');
  console.log('Conexão MCP verificada. Ferramentas musicais encontradas: '+result.tools.length+'. Esquemas salvos em references/noiz-music-tools.json. Nenhuma geração foi solicitada.');
 }catch(error){console.error(error.message);process.exitCode=1;}
}
