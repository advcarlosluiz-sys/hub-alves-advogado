import * as THREE from '../vendor/three.module.js';
const smooth=x=>{x=Math.max(0,Math.min(1,x));return x*x*(3-2*x)};
export function buildMidasProps(parent,s,textures){
 const g=new THREE.Group();parent.add(g);
 const mat=c=>new THREE.MeshStandardMaterial({color:c,roughness:.88,side:THREE.DoubleSide});
 const wood=mat('#9b7050'),gold=mat('#d9ad50'),ivory=mat('#ecdfc2'),green=mat('#6f9165'),teal=mat('#76adb4');
 let goldenFlap=null,cupLift=null;
 const goldColor=new THREE.Color('#e1ba58'),changes=[],lids=[],butterflies=[],sparks=[],wishes=[];
 function mesh(geometry,material,x,y,z,group=g){const m=new THREE.Mesh(geometry,material);m.position.set(x,y,z);m.castShadow=m.receiveShadow=true;group.add(m);return m}
 function box(w,h,d,m,x,y,z,group){return mesh(new THREE.BoxGeometry(w,h,d),m,x,y,z,group)}
 function shape(points,m,x,y,z,group){const a=new THREE.Shape();a.moveTo(...points[0]);for(const p of points.slice(1))a.lineTo(...p);a.closePath();return mesh(new THREE.ShapeGeometry(a),m,x,y,z,group)}
 function makeGold(group,start){group.traverse(obj=>{if(obj.isMesh){obj.material=obj.material.clone();changes.push({material:obj.material,base:obj.material.color.clone(),start});}});}
 function pot(x,z,flowers=true){const b=new THREE.Group();b.position.set(x,0,z);g.add(b);mesh(new THREE.CylinderGeometry(.23,.16,.4,12),mat('#bf8b70'),0,.2,0,b);if(flowers)for(let n=0;n<5;n++){const dx=Math.cos(n*2.4)*.14;box(.025,.4,.025,green,dx,.59,Math.sin(n)*.08,b);mesh(new THREE.CircleGeometry(.075,7),mat(n%2?'#dfb0b5':'#f0d58e'),dx,.83,Math.sin(n)*.08+.03,b);}return b;}
 function chest(x,z){const c=new THREE.Group();c.position.set(x,0,z);g.add(c);box(1.05,.62,.75,wood,0,.35,0,c);for(const dx of [-.32,.32])box(.07,.65,.79,gold,dx,.35,0,c);box(.12,.15,.03,gold,0,.55,.4,c);const lid=new THREE.Group();lid.position.set(0,.65,-.38);c.add(lid);box(1.12,.13,.83,wood,0,.05,.4,lid);for(const dx of [-.33,.33])box(.07,.15,.86,gold,dx,.05,.4,lid);lids.push(lid);for(let n=0;n<8;n++)mesh(new THREE.CylinderGeometry(.085,.085,.035,12),gold,-.35+(n%4)*.22,.68+(n%2)*.02,-.16+Math.floor(n/4)*.28,c);}
 function table(x,z,w=2.7){const b=new THREE.Group();b.position.set(x,0,z);g.add(b);box(w,.14,1.2,wood,0,.95,0,b);for(const dx of [-w*.4,w*.4])for(const dz of [-.4,.4])box(.11,.9,.11,wood,dx,.47,dz,b);return b;}
 function stool(x,z){const b=new THREE.Group();b.position.set(x,0,z);g.add(b);box(.8,.12,.65,wood,0,.72,0,b);for(const dx of [-.28,.28])for(const dz of [-.2,.2])box(.09,.7,.09,wood,dx,.35,dz,b);return b;}
 function chair(x,z){const b=stool(x,z);box(.85,1.1,.08,wood,0,1.28,-.31,b);for(const dx of [-.33,.33])box(.07,1.2,.11,gold,dx,1.35,-.27,b);return b;}
 if(s.treasureMidas){chest(-3.3,.3);chest(3.4,.2);}
 if(s.countingTable){const b=table(.6,.1);for(let n=0;n<12;n++)mesh(new THREE.CylinderGeometry(.09,.09,.035,12),gold,-.9+(n%5)*.3,1.06+Math.floor(n/5)*.025,-.3+(n%3)*.25,b);}
 if(s.gardenMidas){for(const x of [-4.3,4.2])for(const z of [-.1,1.4])pot(x,z);}
 if(s.fountainMidas){const f=new THREE.Group();f.position.set(.2,.02,-1.3);g.add(f);mesh(new THREE.CylinderGeometry(.85,.95,.22,16),ivory,0,.12,0,f);mesh(new THREE.CylinderGeometry(.76,.76,.02,24),teal,0,.25,0,f);const rim=mesh(new THREE.TorusGeometry(.79,.05,6,24),gold,0,.25,0,f);rim.rotation.x=Math.PI/2;mesh(new THREE.CylinderGeometry(.11,.18,.72,12),ivory,0,.62,0,f);mesh(new THREE.CylinderGeometry(.37,.25,.1,12),ivory,0,1.02,0,f);for(let n=0;n<4;n++){const a=n*Math.PI/2,points=[];for(let j=0;j<=10;j++){const u=j/10;points.push(new THREE.Vector3(Math.cos(a)*u*.55,1.14+.4*Math.sin(u*Math.PI)-u*.85,Math.sin(a)*u*.55));}mesh(new THREE.TubeGeometry(new THREE.CatmullRomCurve3(points),12,.012,4,false),teal,0,0,0,f);}}
 if(s.hospitality||s.picnicMidas){const b=table(s.picnicMidas?2.8:.9,s.picnicMidas?-.2:1.2,1.7);mesh(new THREE.CylinderGeometry(.3,.3,.04,16),ivory,0,1.05,.1,b);for(let n=0;n<4;n++)mesh(new THREE.SphereGeometry(.095,10,6),mat(n%2?'#cf9674':'#d5b766'),-.18+n*.12,1.15,.12,b);mesh(new THREE.CylinderGeometry(.11,.08,.27,12),teal,-.6,1.18,.1,b);}
 if(s.twoChairs){chair(-2.5,-.5);chair(2,-.5);}
 if(s.transformObjects){const b=stool(.2,1);makeGold(b,s.goldTimes?.[0]??6);goldenFlap=new THREE.Group();goldenFlap.position.set(0,.8,-.325);b.add(goldenFlap);box(.82,.025,.65,gold,0,0,.325,goldenFlap);const v=pot(1.9,.9,false);makeGold(v,s.goldTimes?.[1]??10);const rock=new THREE.Group();rock.position.set(3,.22,1.1);g.add(rock);mesh(new THREE.DodecahedronGeometry(.28,0),mat('#9da49b'),0,0,0,rock);makeGold(rock,s.goldTimes?.[2]??13);}
 let rose=null,rosePink=null,roseGold=null;
 if(s.roseMidas){rose=new THREE.Group();rose.position.set(-.4,1.55,1.2);g.add(rose);box(.025,.55,.025,green,0,-.15,0,rose);const leaf=shape([[0,0],[.18,.12],[.3,.08],[.15,-.05]],green,0,-.2,.01,rose);makeGold(rose,s.roseMidas.initialGold?-10:s.roseMidas.goldAt);const flowerMat=asset=>new THREE.MeshStandardMaterial({map:textures[asset],transparent:true,alphaTest:.05,depthWrite:false,side:THREE.DoubleSide,roughness:.95});rosePink=mesh(new THREE.PlaneGeometry(.5,.5),flowerMat('rosa_rosa_midas'),0,.18,.035,rose);roseGold=mesh(new THREE.PlaneGeometry(.5,.5),flowerMat('rosa_ouro_midas'),0,.18,.04,rose);}
 if(s.breakfastMidas){const b=table(.8,.1);const bread=new THREE.Group();b.add(bread);mesh(new THREE.SphereGeometry(.27,12,8),mat('#c89b67'),-.55,1.15,.27,bread).scale.set(1.25,.55,.7);for(const dx of [-.65,-.5,-.35])box(.02,.02,.23,ivory,dx,1.29,.27,bread);makeGold(bread,s.breakfastTimes?.[0]??6);const apple=new THREE.Group();b.add(apple);mesh(new THREE.SphereGeometry(.17,12,8),mat('#bc8170'),.25,1.2,.27,apple);box(.03,.1,.03,wood,.25,1.39,.27,apple);makeGold(apple,s.breakfastTimes?.[1]??9);const cup=new THREE.Group();b.add(cup);mesh(new THREE.CylinderGeometry(.14,.11,.3,12),teal,.85,1.21,.2,cup);mesh(new THREE.CylinderGeometry(.115,.115,.015,16),mat('#a8ccd1'),.85,1.37,.2,cup);makeGold(cup,s.breakfastTimes?.[2]??12);cupLift=cup;}
 if(s.wishMidas){for(let n=0;n<3;n++){const w=new THREE.Group();w.position.set(-1.8+n*1.5,3.3,-.7);g.add(w);mesh(new THREE.CircleGeometry(.46,24),ivory,0,0,0,w);if(n===0){box(.12,.45,.04,gold,0,-.05,.03,w);mesh(new THREE.CircleGeometry(.23,8),gold,0,.2,.03,w);}if(n===1){box(.45,.1,.04,gold,0,0,.03,w);box(.07,.4,.04,gold,-.19,-.2,.03,w);box(.07,.4,.04,gold,.19,-.2,.03,w);box(.45,.4,.04,gold,0,.2,.03,w);}if(n===2){box(.35,.6,.05,gold,0,0,.03,w);const roof=mesh(new THREE.ConeGeometry(.3,.24,3),gold,0,.42,.04,w);roof.rotation.y=Math.PI/2;}wishes.push(w);}}
 if(s.riverMidas){const c=document.createElement('canvas');c.width=256;c.height=128;const ctx=c.getContext('2d');ctx.fillStyle='#82b3b7';ctx.fillRect(0,0,256,128);ctx.strokeStyle='#c0d8d5';ctx.lineWidth=2;for(let n=0;n<12;n++){ctx.beginPath();ctx.ellipse((n*71)%256,(n*39)%128,19,3,0,0,Math.PI);ctx.stroke();}const tx=new THREE.CanvasTexture(c);tx.colorSpace=THREE.SRGBColorSpace;tx.wrapS=tx.wrapT=THREE.RepeatWrapping;tx.repeat.set(.22,.8);const waterMat=new THREE.MeshStandardMaterial({map:tx,roughness:1,side:THREE.DoubleSide});const water=shape([[-5.6,-.6],[-2,-.7],[0,-.3],[2,-.65],[5.6,-.5],[5.6,.7],[2,.5],[0,.9],[-2,.4],[-5.6,.7]],waterMat,0,.06,1.7);water.rotation.x=-Math.PI/2;for(let n=0;n<12;n++){const stone=mesh(new THREE.DodecahedronGeometry(.12+(n%3)*.03,0),mat(n%2?'#9ba69c':'#b0b4a4'),-4.8+n*.86,.1,1.7+(n%2?.8:-.65));stone.scale.y=.55;}}
 if(s.greenLeaf){const leaf=shape([[0,0],[.24,.1],[.4,.03],[.23,-.08]],green,.25,.16,1.7);leaf.rotation.x=-Math.PI/2;}
 if(s.butterflyMidas){for(let n=0;n<2;n++){const b=new THREE.Group();g.add(b);for(const side of [-1,1]){const wing=shape([[0,0],[side*.2,.17],[side*.3,.03],[side*.12,-.12]],mat(n?'#c6b4d3':'#e7c779'),0,0,0,b);wing.userData.side=side;}butterflies.push(b);}}
 if(s.magicMidas||s.releaseGold)for(let n=0;n<20;n++)sparks.push(mesh(new THREE.OctahedronGeometry(.025+(n%3)*.01,0),new THREE.MeshBasicMaterial({color:'#ffe3a0',transparent:true}),0,0,0));
 const musicNotes=[];
 if(s.musicPerformance){
  for(let n=0;n<5;n++){
   const note=new THREE.Group();note.position.set(-3.5+n*1.7,2.65+(n%2)*.35,-.8);g.add(note);
   const head=mesh(new THREE.CircleGeometry(.11,12),gold,0,0,.02,note);head.scale.y=.7;
   box(.035,.43,.04,gold,.08,.2,.02,note);
   shape([[.08,.42],[.3,.34],[.24,.2],[.08,.3]],gold,0,0,.03,note);
   musicNotes.push(note);
  }
 }
 return {update(t,closing){
  g.scale.y=Math.max(.001,smooth((t-.2)/1.2)*closing);
  for(const {material,base,start} of changes){const q=smooth((t-start)/1.4);material.color.copy(base).lerp(goldColor,q);material.metalness=q*.6;material.roughness=.9-q*.5;}
  musicNotes.forEach((m,n)=>{m.position.y=2.65+(n%2)*.35+Math.sin(t*3+n)*.07;m.rotation.z=Math.sin(t*2+n)*.06;});
  lids.forEach((lid,n)=>lid.rotation.x=-.65*smooth((t-2-n*.5)/2));
  if(rose){rose.position.y=1.55+smooth((t-(s.clipMode?5:13))/2)*.5;const q=s.roseMidas.initialGold?1:smooth((t-s.roseMidas.goldAt)/1.4);rosePink.material.opacity=1-q;rosePink.visible=q<.999;roseGold.material.opacity=q;roseGold.visible=q>.001;roseGold.rotation.y=-(1-q)*.7;}
  if(goldenFlap){const q=smooth((t-(s.goldTimes?.[0]??6))/1.4);goldenFlap.visible=q>.001;goldenFlap.rotation.x=-(1-q)*Math.PI/2;}
  if(cupLift){const q=smooth((t-(s.clipMode?4.5:10))/(s.clipMode?1.2:2));cupLift.position.set(-q*1.8,q*.85,q*.8);}
  wishes.forEach((w,n)=>{w.scale.setScalar(smooth((t-(s.wishAt??3)-n)/1.2));w.position.y=3.3+Math.sin(t*.7+n)*.035;});
  butterflies.forEach((b,n)=>{const q=smooth((t-(s.roseMidas.goldAt||5)-1)/4);b.position.set(.3+q*2+n*.4,1.9+Math.sin(t+n)*.12,1.3);b.children.forEach(m=>m.rotation.y=m.userData.side*Math.sin(t*9)*.6);});
  sparks.forEach((m,n)=>{let q;if(s.releaseGold){q=smooth((t-(s.releaseAt??6))/6);m.position.set(-.2+n*.035-q*(2+n*.08),1.4*(1-q)+.1,1.25+q*.4+Math.sin(n+t)*.07);m.material.opacity=q>.95?Math.max(0,(1-q)*20):1;m.visible=t>=(s.releaseAt??6)&&q<1;}else{m.position.set(.3+Math.sin(n*2.4+t)*1.3,.3+(n%6)*.23,1+Math.cos(n*2.4+t)*.4);m.scale.setScalar(.4+.6*Math.sin(t*2+n)**2);}});
 }};
}
