# Moisés e o Mar que se Abriu — livro pop-up

Adaptação infantil do roteiro enviado, inspirada em Êxodo 14–15, para Contos de Gaitolé. Duração de 4min10s (250 segundos), horizontal 1280 × 720, 24 fps, H.264/AAC estéreo. Narração Thalita em português do Brasil, legendas por frase e música “Um Caminho no Mar” reduzida durante as falas.

## Assistir

Abra `output/moises-mar.mp4`. No ZIP para assistir, extraia tudo e abra `alves-pop-up/ASSISTA-AQUI.mp4`. Não é necessário executar arquivos `.cmd` ou instalar o gerador para assistir ao MP4 pronto.

## História e apresentação

Dez cenas com capa azul e dourada, livro sobre mesa em sala decorada, deserto, coluna de nuvem, praia, oração, vento, mar articulado, caminhada entre as águas, chegada à outra margem e celebração com Miriã. A abertura do mar usa três painéis de papel por lado com dobradiças reais, revelando a passagem seca. A aproximação das águas ocorre ao fundo, com todas as pessoas em terra. Sem perseguições, armas ou imagens de afogamento.

A pergunta começa aos 2 segundos, acompanhando a capa e a abertura do livro. Encerramento com marca, perfis, inscrição e indicação de A Rainha Ester. Os elementos finais são gráficos do vídeo, sem pressupor recursos interativos do YouTube.

## Arquivos

- `stories/joao.json`: roteiro principal do motor, com nome mantido por compatibilidade. Cópia em `stories/moises-mar.json`.
- `references/roteiro-fornecido.txt`: texto enviado pelo usuário, preservado.
- `assets/moises/`: personagens, poses, animais e seis cenários. Recortes em `engine/story.mjs`; origens em `references/assets-originais.json`.
- `engine/moises-props.mjs`: mar em camadas articuladas, cajado, nuvem, vento, peixes e objetos do acampamento.
- `assets/narracao/`: dez clipes Thalita, manifesto com hashes e tempos das legendas.
- `assets/musica/um-caminho-no-mar.mp3`: original enviado, preservado integralmente. A faixa tem aproximadamente 4min41s; o vídeo narrado usa o trecho correspondente aos seus 4min10s, com redução durante as falas e término suave.
- `assets/efeitos/`: água, vento, passos, pandeiro e sinal suave de encerramento, sintetizados para o episódio.
- `publicacao/`: capa, título, descrição e duas miniaturas A/B de 1280 × 720.

## Editar e exportar

Requer Node.js 22+, Chrome/Chromium/Edge e FFmpeg. Execute `npm ci` e `npm start` para visualizar. Exporte com `npm run render:fast -- --out output/moises-mar.mp4`. Use `CHROME_PATH` e `FFMPEG_PATH` se necessário. A geração Noiz está desativada; os áudios incluídos permitem exportar sem chave. Alterações de texto exigem nova narração e legendas. Os atalhos são opcionais para edição; o MP4 pronto pode ser assistido diretamente.

## Créditos

Roteiro e música enviados pelo usuário. Referência: Êxodo 14–15. Ilustrações e mecanismos de papel preparados para este episódio. Contos de Gaitolé: YouTube @gaitolé; TikTok @gaitole0. Licença e avisos originais Mira preservados em LICENSE-MIRA e vendor. Nenhuma publicação no YouTube nem teste A/B de desempenho foi realizado.
