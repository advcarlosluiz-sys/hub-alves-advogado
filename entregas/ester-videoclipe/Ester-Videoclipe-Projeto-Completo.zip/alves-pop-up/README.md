# Ester Voz de Coragem — videoclipe em livro pop-up

Canção original enviada pelo usuário, na íntegra, aproximadamente 5min04s (303,5833 s). Horizontal 1280 × 720, 24 fps, H.264/AAC estéreo. Somente a canção, sem narrador adicional ou efeitos sobrepostos.

## Assistir

Abra `output/ester-videoclipe.mp4`. No ZIP para assistir, extraia tudo e abra `alves-pop-up/ASSISTA-AQUI.mp4`. Não é necessário executar `.cmd` ou instalar o gerador para assistir ao MP4 pronto.

## Montagem

34 trechos com variações reais de câmera 3D e movimentos suaves acompanhando pulsações musicais estimadas. Capa púrpura e dourada, livro sobre mesa em sala decorada, Susa, jardins, portas articuladas, trono, cetro animado, banquete dobrável, cartas de proteção e celebração de Purim. Encerramento de 20 segundos com marca, inscrição e indicação musical de Jonas e o Grande Peixe.

A montagem temática considera a letra embutida no MP3. O andamento e as pulsações foram estimados pelo fluxo espectral. Não há alinhamento das palavras ou marcação exata de seções vocais; não se trata de karaokê.

## Arquivos

- `stories/joao.json`: roteiro principal do motor, com nome mantido por compatibilidade. Cópia em `stories/ester-videoclipe.json`.
- `references/montagem-videoclipe.json`: tempos dos 34 trechos e intervalos das ações originais.
- `references/letra-musica-fornecida.txt`: letra extraída da canção enviada.
- `references/roteiro-original.txt`: roteiro da história narrada que originou as cenas. O videoclipe utiliza apenas a canção.
- `assets/ester/`: personagens, poses e cenários; recortes em `engine/story.mjs`, origens em `references/assets-originais.json`.
- `engine/ester-props.mjs`: portas, trono, cetro, fonte, banquete, pergaminho e adereços 3D.
- `assets/musica/ester-voz-de-coragem.mp3`: original preservado sem cortes, repetição ou substituição do vocal.
- `publicacao/`: capa, letra, título, descrição e duas miniaturas com indicação VIDEOCLIPE.

## Editar e exportar

Requer Node.js 22+, Chrome/Chromium/Edge e FFmpeg. Execute `npm ci` e `npm start` para visualizar. Exporte com `npm run render:fast -- --out output/ester-videoclipe.mp4`. Use `CHROME_PATH` e `FFMPEG_PATH` se necessário. A geração Noiz está desativada; nenhuma chave é necessária para exportar a música incluída.

## Créditos

Contos de Gaitolé: YouTube @gaitolé e TikTok @gaitole0. Música e letra enviadas pelo usuário, inspiradas no Livro de Ester. Roteiro infantil e ilustrações preparados para o episódio de A Rainha Ester. Licença e avisos originais Mira preservados em LICENSE-MIRA e vendor. Nenhum teste A/B de desempenho nem publicação no YouTube foi realizado.
