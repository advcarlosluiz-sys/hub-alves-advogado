import * as THREE from '../vendor/three.module.js';
const smooth=x=>{x=Math.max(0,Math.min(1,x));return x*x*(3-2*x)};
export function buildEsterProps(parent,s){
 const g=new THREE.Group();parent.add(g);
 const mat=c=>new THREE.MeshStandardMaterial({color:c,roughness:.9,side:THREE.DoubleSide});
 const gold=mat('#c4a363'),cream=mat('#eee0c3'),stone=mat('#d2bf9c'),plum=mat('#876479'),blue=mat('#608f9b'),wood=mat('#98704a'),green=mat('#71905c'),clay=mat('#b68969');
 function mesh(geo,m,x=0,y=0,z=0,group=g){const a=new THREE.Mesh(geo,m);a.position.set(x,y,z);a.castShadow=a.receiveShadow=true;group.add(a);return a;}
 function box(w,h,d,m,x,y,z,group){return mesh(new THREE.BoxGeometry(w,h,d),m,x,y,z,group)}
 function cyl(r1,r2,h,m,x,y,z,group){return mesh(new THREE.CylinderGeometry(r1,r2,h,16),m,x,y,z,group)}
 function texture(draw,w=512,h=384){const c=document.createElement('canvas');c.width=w;c.height=h;draw(c.getContext('2d'),w,h);const t=new THREE.CanvasTexture(c);t.colorSpace=THREE.SRGBColorSpace;return t;}
 let scepter=null,scroll=null,tabletop=null;const doors=[],drops=[],flags=[],blooms=[];
 function column(x,z){cyl(.29,.34,.14,gold,x,.1,z);cyl(.18,.23,3.6,cream,x,1.95,z);cyl(.29,.22,.17,gold,x,3.82,z);box(.66,.18,.58,stone,x,4.0,z);for(let n=0;n<4;n++){const a=n*Math.PI/2;cyl(.06,.08,.26,gold,x+Math.cos(a)*.16,3.88,z+Math.sin(a)*.16);}}
 function vase(x,z,flower=true){cyl(.16,.12,.32,clay,x,.19,z);cyl(.18,.15,.08,gold,x,.38,z);if(flower){for(let k=0;k<3;k++){const xx=x+(k-1)*.13;box(.016,.48,.016,green,xx,.62,z);const a=mesh(new THREE.CircleGeometry(.105,7),k%2?plum:cream,xx,.9+(k%2)*.05,z+.02);blooms.push(a);mesh(new THREE.CircleGeometry(.03,8),gold,xx,.9+(k%2)*.05,z+.025);}}}
 function basket(x,z,n=0){cyl(.27,.2,.26,wood,x,.16,z);for(let j=0;j<5;j++)mesh(new THREE.SphereGeometry(.075,9,7),j%2?gold:cream,x-.14+(j%3)*.14,.34,z-.08+Math.floor(j/3)*.14);const arc=mesh(new THREE.TorusGeometry(.24,.022,5,24,Math.PI),gold,x,.3,z);}
 if(s.royalDoors||s.throneProps||s.banquetProps){column(-4,-1.9);column(4,-1.9);box(8.5,.16,.45,gold,0,4.12,-1.9);for(let n=0;n<11;n++)mesh(new THREE.CircleGeometry(.075,6),blue,-3.75+n*.75,4.12,-1.65);}
 if(s.royalDoors){
  box(4.5,.22,.4,gold,0,3.7,-2.1);for(const side of [-1,1]){box(.27,3.7,.4,cream,side*2.15,1.85,-2.1);const p=new THREE.Group();p.position.set(side*2,.06,-2.05);g.add(p);const center=-side*.98;box(1.96,3.52,.07,blue,center,1.76,0,p);for(const x of [center-.88,center+.88])box(.045,3.4,.09,gold,x,1.76,.02,p);for(let n=0;n<7;n++)box(1.8,.025,.08,gold,center,.22+n*.52,.025,p);for(let n=0;n<4;n++){const a=box(.32,.32,.015,gold,center,.75+n*.65,.055,p);a.rotation.z=Math.PI/4;}doors.push({p,side});}
 }
 if(s.throneProps){
  box(2.6,.15,1.65,stone,1.6,.1,-1.35);box(2.2,.16,1.35,cream,1.6,.26,-1.4);
  for(const x of [1,2.2])for(const z of [-1.72,-1.1])box(.12,.8,.12,gold,x,.74,z);
  box(1.65,.17,1,plum,1.6,1.13,-1.4);box(1.75,2.25,.12,plum,1.6,2.1,-1.88);
  for(const x of [.69,2.51])box(.12,2.5,.16,gold,x,2.1,-1.78);box(1.98,.16,.18,gold,1.6,3.34,-1.78);
  for(let n=0;n<5;n++){const a=box(.16,.3+(n%2)*.12,.12,gold,.95+n*.32,3.55,-1.78);a.rotation.z=n%2?.2:-.2;}
 }
 if(s.scepterProps){scepter=new THREE.Group();scepter.position.set(.7,1.77,-.88);g.add(scepter);cyl(.028,.034,1.55,gold,0,.76,0,scepter);mesh(new THREE.SphereGeometry(.085,12,8),gold,0,1.57,0,scepter);mesh(new THREE.SphereGeometry(.045,10,8),blue,0,1.66,0,scepter);}
 if(s.fountainProps){cyl(.66,.72,.25,cream,1.2,.16,-.25);cyl(.58,.58,.03,blue,1.2,.31,-.25);cyl(.1,.14,.65,gold,1.2,.6,-.25);for(let n=0;n<7;n++){const a=mesh(new THREE.SphereGeometry(.024,7,5),blue,0,0,0);a.castShadow=false;drops.push(a);}}
 if(s.gardenProps){for(const x of [-4.5,4.5]){cyl(.28,.22,.45,clay,x,.25,-.2);const a=mesh(new THREE.ConeGeometry(.48,2.3,9),green,x,1.55,-.2);a.scale.z=.6;}for(let n=0;n<6;n++)vase(n<3?-3.7+n*.35:3+(n-3)*.35,1.4+(n%2)*.3);}
 if(s.quietProps){box(1.1,.08,.75,wood,-.1,.63,-.6);for(const x of [-.5,.3])box(.07,.6,.07,wood,x,.3,-.6);const roll=cyl(.055,.055,.62,cream,-.1,.74,-.6);roll.rotation.z=Math.PI/2;}
 if(s.letterProps){box(1.35,.1,.85,wood,.05,.8,1.25);for(const x of [-.48,.58])for(const z of [.98,1.52])box(.07,.77,.07,wood,x,.39,z);for(let n=0;n<3;n++){const a=cyl(.07,.07,.55,cream,-.35+n*.38,.92,1.2);a.rotation.z=Math.PI/2;}}
 if(s.protectionScroll){
  scroll=new THREE.Group();scroll.position.set(.1,.94,1.35);g.add(scroll);const map=texture((c,w,h)=>{c.fillStyle='#ecdcb3';c.fillRect(0,0,w,h);c.strokeStyle='#b79c64';c.lineWidth=4;c.strokeRect(20,18,w-40,h-36);c.fillStyle='#65543a';c.font='bold 48px Georgia';c.textAlign='center';c.fillText('PROTEÇÃO',w/2,105);c.strokeStyle='#9d987c';c.lineWidth=3;for(let n=0;n<6;n++){c.beginPath();c.moveTo(70,155+n*28);c.lineTo(w-70-(n%3)*22,155+n*28);c.stroke();}});
  mesh(new THREE.PlaneGeometry(2.0,1.5),new THREE.MeshStandardMaterial({map,side:THREE.DoubleSide,roughness:1}),0,.77,.04,scroll);for(const y of [.02,1.53]){const a=cyl(.065,.065,2.08,cream,0,y,0,scroll);a.rotation.z=Math.PI/2;}cyl(.09,.09,.04,plum,.72,.34,.08,scroll).rotation.x=Math.PI/2;
 }
 if(s.banquetProps){
  for(const x of [-1.55,1.55])for(const z of [.25,1.25])box(.1,.85,.1,gold,x,.42,z);
  tabletop=new THREE.Group();tabletop.position.set(0,.9,1.4);g.add(tabletop);box(3.8,.1,1.3,wood,0,0,-.6,tabletop);box(3.9,.025,1.36,plum,0,.065,-.6,tabletop);for(const x of [-1.82,1.82])box(.04,.03,1.36,gold,x,.09,-.6,tabletop);
  for(const x of [-1.15,0,1.15]){cyl(.24,.24,.025,cream,x,.105,-.6,tabletop);for(let n=0;n<3;n++)mesh(new THREE.SphereGeometry(.07,9,7),n%2?gold:mat('#b27c60'),x-.1+n*.1,.19,-.6,tabletop);}
  for(const x of [-.7,.7]){cyl(.06,.05,.18,gold,x,.2,-.18,tabletop);cyl(.07,.07,.015,blue,x,.3,-.18,tabletop);}cyl(.1,.08,.3,clay,0,.25,-1.0,tabletop);cyl(.07,.1,.12,cream,0,.45,-1.0,tabletop);box(1.3,.15,.9,plum,.9,.15,-.3);
 }
 if(s.cityProps){for(const x of [-3.6,3.6]){box(.55,2.7,.45,stone,x,1.35,-1.8);box(.8,.18,.55,gold,x,2.75,-1.8);}box(7.6,.12,.4,cream,0,2.9,-1.8);vase(-4.6,.6);vase(4.6,.6);}
 if(s.celebrationProps){
  const pts=[];for(let n=0;n<=30;n++){const x=-4.6+n*9.2/30;pts.push(new THREE.Vector3(x,3.9-.4*(1-(x/4.6)**2),-.4));}const line=new THREE.Line(new THREE.BufferGeometry().setFromPoints(pts),new THREE.LineBasicMaterial({color:'#bca36a'}));g.add(line);
  for(let n=0;n<13;n++){const x=-4.4+n*.73,y=3.9-.4*(1-(x/4.6)**2);const sh=new THREE.Shape();sh.moveTo(-.2,0);sh.lineTo(.2,0);sh.lineTo(0,-.36);sh.closePath();const a=mesh(new THREE.ShapeGeometry(sh),[gold,plum,blue][n%3],x,y,-.39);flags.push(a);}
  for(let n=0;n<3;n++){basket(2.0+n*.65,2.4);box(.43,.3,.4,n%2?plum:blue,-3.7+n*.6,.17,2.1);box(.03,.31,.42,gold,-3.7+n*.6,.17,2.1);}
 }
 return {update(t,closing){g.scale.y=Math.max(.001,smooth((t-.25)/1.15)*closing);doors.forEach(({p,side})=>p.rotation.y=-side*smooth((t-1.5)/3)*1.25);if(scepter)scepter.rotation.z=smooth((t-3)/4)*.9;if(scroll)scroll.scale.y=Math.max(.001,smooth((t-3)/4));if(tabletop)tabletop.rotation.x=Math.PI/2*(1-smooth((t-.5)/1.8));drops.forEach((a,n)=>{const q=(t*.65+n*.13)%1;a.position.set(1.2+Math.cos(n*1.6)*.22*Math.sin(q*Math.PI),.8+Math.sin(q*Math.PI)*.45,-.25+Math.sin(n*1.6)*.22);});flags.forEach((a,n)=>a.rotation.z=Math.sin(t*.8+n)*.045);}};
}
