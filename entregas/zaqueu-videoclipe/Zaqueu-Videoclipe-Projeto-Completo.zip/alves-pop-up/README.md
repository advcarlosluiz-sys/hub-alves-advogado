# Desce Dessa Árvore, Zaqueu! — Videoclipe

Canção original enviada pelo autor, na íntegra, aproximadamente 3min23s (202,8s de música;202,833s de vídeo). Horizontal 1280×720,24fps,H.264/AAC estéreo. Vocal da própria canção, sem narrador adicional ou efeitos sonoros sobrepostos.

## Assistir

Abra `output/zaqueu-videoclipe.mp4`. No ZIP para assistir, extraia tudo e abra `alves-pop-up/ASSISTA-AQUI.mp4`. Não precisa executar .cmd ou instalar o gerador para assistir.

## Montagem

27 trechos com variações reais de câmera 3D e movimentos delicados acompanhando a pulsação estimada de100,23BPM. Capa teal/dourada, livro sobre mesa trabalhada em sala decorada, Jericó, mercado, moradores, criança, burrinho e passarinho. Zaqueu adulto em poses consistentes; árvore com tronco, galho e duas abas de copa. Subida e descida, porta que abre, casa com mesa e livro de contas, devolução simbólica de moeda e celebração. Trocas de pose sem duplicação do protagonista.

Os cortes consecutivos na mesma página conservam os recortes levantados e a continuidade das ações. Os refrões e a conclusão retomam enquadramentos de acolhimento e reparação; não mostram Zaqueu voltando a cobrar injustamente. Gancho visual imediato; breve capa após o início da música. Encerramento com a marca, perfis, inscrição e indicação musical de Cadê Minha Ovelhinha!.

A letra vem dos metadados do arquivo enviado. A análise rítmica usa fluxo espectral e autocorrelação; a pulsação é estimada. Não há sincronização por palavra, marcação exata de seções vocais, karaokê ou animação labial. A música toca uma vez, completa, com transições muito breves nas extremidades; o final do último quadro é preenchido com silêncio. A versão narrada está preservada em seu próprio projeto.

## Arquivos

- `stories/joao.json`: roteiro principal, por compatibilidade. Cópia em `stories/zaqueu-videoclipe.json`.
- `references/montagem-videoclipe.json`: tempos dos trechos, câmeras e relógios das ações.
- `references/letra-musica-fornecida.txt`: letra dos metadados.
- `references/roteiro-fornecido.txt`: roteiro narrado que originou os cenários; não é falado neste clipe.
- `assets/zaqueu/`: novas ilustrações originais reaproveitadas da história narrada de Zaqueu.
- `assets/elenco/` e `assets/ovelha/`: ilustrações originais dos personagens secundários e cenário.
- `assets/musica/desce-dessa-arvore-zaqueu.mp3`: arquivo original preservado integralmente.
- `publicacao/`: capa, letra, título, descrição, playlist e duas miniaturas com indicação VIDEOCLIPE.

## Editar e exportar

Requer Node.js22+,Chrome/Chromium/Edge e FFmpeg. Execute `npm ci` e `npm start`. Exporte com `npm run render:fast -- --out output/zaqueu-videoclipe.mp4`. Use CHROME_PATH e FFMPEG_PATH se necessário. A música já está incluída, a geração Noiz está desativada e não é necessária chave para esta exportação. Não gere narração para este videoclipe.

## Créditos

Contos de Gaitolé, YouTube@gaitolé,TikTok@gaitole0. Canção e roteiro de origem enviados pelo autor. Referência Lucas19:1–10. Arte e mecanismos adaptados da história narrada de Zaqueu. Bibliotecas locais e licenças preservadas. Sem publicação no YouTube ou teste A/B de desempenho nesta tarefa.
