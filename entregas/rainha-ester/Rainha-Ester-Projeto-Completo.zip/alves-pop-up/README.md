# A Rainha Ester — livro pop-up

Adaptação infantil original do Livro de Ester, para Contos de Gaitolé. Duração de 4min06s (246 segundos), horizontal 1280 × 720, 24 fps, H.264/AAC estéreo. Narração Thalita em português do Brasil, legendas por frase e música “Ester Voz de Coragem” reduzida durante as falas.

## Assistir

Abra `output/rainha-ester.mp4`. No ZIP para assistir, extraia tudo e abra `alves-pop-up/ASSISTA-AQUI.mp4`. Não é necessário executar arquivos `.cmd` ou instalar o gerador para assistir ao MP4 pronto.

## História e apresentação

Dez cenas com capa trabalhada em tons de púrpura e dourado, livro sobre mesa em sala decorada, Susa, jardins, portas articuladas, trono, cetro animado, mesa de banquete dobrável, cartas de proteção e celebração de Purim com alimentos e presentes. Adaptação com suspense leve, sem imagens de violência. Preserva a identidade judaica de Ester e de seu povo; a proteção ocorre por novas cartas que permitem a organização para defesa, sem afirmar que o decreto inicial foi simplesmente revogado.

Pergunta narrada a partir dos 2 segundos, capa breve e contexto a partir dos 14 segundos. Encerramento com marca, perfis, inscrição e indicação de Jonas e o Grande Peixe. Os elementos finais são gráficos do vídeo, sem pressupor recursos interativos do YouTube.

## Arquivos

- `stories/joao.json`: roteiro principal do motor, com nome mantido por compatibilidade. Cópia em `stories/rainha-ester.json`.
- `references/roteiro-original.txt`: narração original deste episódio.
- `assets/ester/`: personagens, poses e seis cenários de papel. Mapa de recortes em `engine/story.mjs`; origens em `references/assets-originais.json`.
- `engine/ester-props.mjs`: portas, trono, cetro, fonte, banquete, pergaminho de proteção e outros objetos 3D.
- `assets/narracao/`: dez clipes Thalita, manifesto com hashes e tempos das legendas.
- `assets/musica/ester-voz-de-coragem.mp3`: arquivo original enviado pelo usuário, preservado integralmente. A música tem aproximadamente 5min04s; o vídeo narrado utiliza o trecho correspondente aos seus 4min06s, com redução durante as falas e término suave.
- `assets/efeitos/`: pássaros, passos e sinal suave de encerramento.
- `publicacao/`: capa, título, descrição e duas miniaturas A/B de 1280 × 720.

## Editar e exportar

Requer Node.js 22+, Chrome/Chromium/Edge e FFmpeg. Execute `npm ci` e `npm start` para visualizar. Exporte com `npm run render:fast -- --out output/rainha-ester.mp4`. Configure `CHROME_PATH` e `FFMPEG_PATH` se necessário. A geração Noiz está desativada; os áudios incluídos permitem exportar sem chave. Alterações de texto exigem nova narração e legendas. Os atalhos são opcionais para edição; o MP4 pode ser assistido diretamente.

## Créditos

Canção fornecida pelo usuário. Roteiro infantil e ilustrações originais preparados para este episódio. Referência: Livro de Ester. Contos de Gaitolé: YouTube @gaitolé; TikTok @gaitole0. Licença e avisos originais Mira preservados em LICENSE-MIRA e vendor. Nenhuma publicação no YouTube nem teste A/B de desempenho foi executado.
