import { MOTIONS } from "./actor-motion.mjs";
export const ASSETS=Object.freeze(["helena", "camila", "epa", "veronica", "teo", "teo_alerta", "veronica_oferece", "epa_lama", "camila_cruza", "casarao", "coreto", "casas", "gato", "bode", "arvore", "mao_helena", "folha"]);
export function validateStory(story) {
  if (
    !story ||
    typeof story.title !== "string" ||
    !story.title.trim() ||
    !Array.isArray(story.scenes) ||
    !story.scenes.length
  )
    throw Error("Roteiro precisa de título e cenas");
  if (
    story.endCard &&
    (!Number.isFinite(story.endCard.duration) ||
      story.endCard.duration < 3 ||
      story.endCard.duration > 15 ||
      typeof story.endCard.youtube?.name !== "string" ||
      typeof story.endCard.youtube?.handle !== "string" ||
      typeof story.endCard.tiktok?.handle !== "string")
  )
    throw Error("Tela final inválida");
  if (story.presentation) {
    const p=story.presentation;
    if (!Number.isFinite(p.introDuration) || p.introDuration<0 || p.introDuration>15 ||
        (p.cameraScale!==undefined && (!Number.isFinite(p.cameraScale) || p.cameraScale<0.9 || p.cameraScale>1.6)) ||
        (p.coverImage!==undefined && (!/^(assets|publicacao)\/[a-zA-Z0-9_./-]+\.(png|jpg)$/.test(p.coverImage) || p.coverImage.includes(".."))))
      throw Error("Apresentação do livro inválida");
  }
  const ids = new Set();
  let duration = 0;
  for (const s of story.scenes) {
    if (!s.id || ids.has(s.id))
      throw Error("Identificador de cena ausente ou repetido");
    ids.add(s.id);
    if (!Number.isFinite(s.duration) || s.duration < 3 || s.duration > 120)
      throw Error("Duração de cena inválida");
    if (typeof s.caption !== "string") throw Error("Legenda ausente");
    for (const key of ["from", "to", "target"])
      if (
        !Array.isArray(s.camera?.[key]) ||
        s.camera[key].length !== 3 ||
        !s.camera[key].every(Number.isFinite)
      )
        throw Error("Câmera inválida");
    if (!Array.isArray(s.actors) || s.actors.length > 60)
      throw Error("Atores inválidos");
    for (const a of s.actors) {
      if (a.motion) {
        if (!MOTIONS.includes(a.motion.type))
          throw Error("Movimento desconhecido");
        if (
          !Number.isFinite(a.motion.start) ||
          !Number.isFinite(a.motion.end) ||
          a.motion.start < 0 ||
          a.motion.end <= a.motion.start
        )
          throw Error("Intervalo de movimento inválido");
        for (const field of ["dx", "dy"])
          if (
            a.motion[field] !== undefined &&
            !Number.isFinite(a.motion[field])
          )
            throw Error("Deslocamento inválido");
      }

      if (!ASSETS.includes(a.asset))
        throw Error("Asset desconhecido: " + a.asset);
      for (const k of ["x", "z", "width", "height"])
        if (!Number.isFinite(a[k])) throw Error("Dimensão/posição inválida");
      if (a.width <= 0 || a.height <= 0 || a.width > 25 || a.height > 25)
        throw Error("Dimensão fora dos limites");
      for (const k of ["y", "walk", "enter"])
        if (a[k] !== undefined && !Number.isFinite(a[k]))
          throw Error("Parâmetro de ator inválido");
    }
    duration += s.duration;
  }
  if (
    !Number.isFinite(story.duration) ||
    Math.abs(duration - story.duration) > 0.001
  )
    throw Error("Duração total difere da soma das cenas");
  return story;
}
export function locateScene(story, time) {
  const t = Math.min(story.duration, Math.max(0, Number(time) || 0));
  let start = 0;
  for (let index = 0; index < story.scenes.length; index++) {
    const scene = story.scenes[index];
    if (t < start + scene.duration || index === story.scenes.length - 1)
      return { index, scene, local: t - start, start, time: t };
    start += scene.duration;
  }
}

export const ASSET_FILES={
  "helena": {
    "file": "assets/cabecudos/elenco_a.webp",
    "rect": [
      126,
      0,
      506,
      724
    ]
  },
  "camila": {
    "file": "assets/cabecudos/elenco_a.webp",
    "rect": [
      734,
      8,
      661,
      715
    ]
  },
  "epa": {
    "file": "assets/cabecudos/elenco_a.webp",
    "rect": [
      1513,
      4,
      573,
      720
    ]
  },
  "veronica": {
    "file": "assets/cabecudos/elenco_b.webp",
    "rect": [
      219,
      5,
      347,
      716
    ]
  },
  "teo": {
    "file": "assets/cabecudos/elenco_b.webp",
    "rect": [
      778,
      22,
      470,
      700
    ]
  },
  "teo_alerta": {
    "file": "assets/cabecudos/elenco_b.webp",
    "rect": [
      1548,
      23,
      434,
      701
    ]
  },
  "veronica_oferece": {
    "file": "assets/cabecudos/elenco_c.webp",
    "rect": [
      182,
      0,
      384,
      724
    ]
  },
  "epa_lama": {
    "file": "assets/cabecudos/elenco_c.webp",
    "rect": [
      907,
      0,
      376,
      724
    ]
  },
  "camila_cruza": {
    "file": "assets/cabecudos/elenco_c.webp",
    "rect": [
      1633,
      2,
      365,
      722
    ]
  },
  "casarao": {
    "file": "assets/cabecudos/cenarios.webp",
    "rect": [
      9,
      7,
      704,
      708
    ]
  },
  "coreto": {
    "file": "assets/cabecudos/cenarios.webp",
    "rect": [
      806,
      12,
      561,
      705
    ]
  },
  "casas": {
    "file": "assets/cabecudos/cenarios.webp",
    "rect": [
      1452,
      330,
      714,
      355
    ]
  },
  "gato": {
    "file": "assets/cabecudos/animais.webp",
    "rect": [
      51,
      167,
      643,
      512
    ]
  },
  "bode": {
    "file": "assets/cabecudos/animais.webp",
    "rect": [
      791,
      15,
      609,
      694
    ]
  },
  "arvore": {
    "file": "assets/cabecudos/animais.webp",
    "rect": [
      1482,
      6,
      669,
      706
    ]
  },
  "mao_helena": {
    "file": "assets/cabecudos/elenco_a.webp",
    "rect": [
      450,
      225,
      195,
      110
    ]
  },
  "folha": {
    "file": "assets/folha.svg"
  }
};
