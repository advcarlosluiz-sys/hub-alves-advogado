import * as THREE from '../vendor/three.module.js';
const smooth=x=>{x=Math.min(1,Math.max(0,x));return x*x*(3-2*x);};
export function buildCabecudosProps(group,s,textures,actors){
 const root=new THREE.Group();group.add(root);const ink=new THREE.LineBasicMaterial({color:'#25180e'});
 const materials=new Map();const material=color=>{if(!materials.has(color))materials.set(color,new THREE.MeshStandardMaterial({color,roughness:1,side:THREE.DoubleSide}));return materials.get(color);};const yellow=material('#e8bb54'),cream=material('#f3d99a'),wood=material('#a96732'),blue=material('#28699d'),dark=material('#30251b');
 function mesh(g,m,x,y,z,parent=root){const a=new THREE.Mesh(g,m);a.position.set(x,y,z);a.castShadow=a.receiveShadow=true;parent.add(a);return a;}
 function outlined(g,m,x,y,z,parent=root){const a=mesh(g,m,x,y,z,parent),edge=new THREE.LineSegments(new THREE.EdgesGeometry(g,28),ink);a.add(edge);return a;}
 function box(w,h,d,m,x,y,z,parent=root){return outlined(new THREE.BoxGeometry(w,h,d),m,x,y,z,parent);}
 function card(asset,w,h,x,z,y=.03,parent=root){const pivot=new THREE.Group();pivot.position.set(x,y,z);const a=mesh(new THREE.PlaneGeometry(w,h),new THREE.MeshStandardMaterial({map:textures[asset],alphaTest:.45,roughness:1,side:THREE.DoubleSide}),0,h/2,0,pivot);parent.add(pivot);return pivot;}
 function label(text,w=.9,h=.35,size=75,color='#33220e'){const c=document.createElement('canvas');c.width=1024;c.height=256;const q=c.getContext('2d');q.fillStyle='#eed79b';q.fillRect(0,0,1024,256);q.strokeStyle='#35210e';q.lineWidth=12;q.strokeRect(10,10,1004,236);q.fillStyle=color;q.textAlign='center';q.textBaseline='middle';q.font='bold '+size+'px Georgia';q.fillText(text,512,130,960);const tx=new THREE.CanvasTexture(c);tx.colorSpace=THREE.SRGBColorSpace;return new THREE.Mesh(new THREE.PlaneGeometry(w,h),new THREE.MeshStandardMaterial({map:tx,roughness:1,side:THREE.DoubleSide}));}
 // Mural de colinas recortadas, em três profundidades distintas.
 for(let k=0;k<3;k++){const sh=new THREE.Shape();sh.moveTo(-5.65,0);for(let j=0;j<=10;j++)sh.lineTo(-5.65+j*1.13,.45+(2-k)*.24+Math.sin(j*1.7+k)*.22);sh.lineTo(5.65,0);sh.closePath();mesh(new THREE.ShapeGeometry(sh),material(['#b29855','#c7ab65','#dbbf7d'][k]),0,.035,-3.15+k*.35);}
 function cactus(x,z,h){const sh=new THREE.Shape();sh.moveTo(-.13,0);sh.lineTo(-.13,h*.37);sh.lineTo(-.42,h*.37);sh.quadraticCurveTo(-.57,h*.37,-.57,h*.58);sh.lineTo(-.57,h*.73);sh.quadraticCurveTo(-.45,h*.84,-.34,h*.73);sh.lineTo(-.34,h*.52);sh.lineTo(-.13,h*.52);sh.lineTo(-.13,h*.9);sh.quadraticCurveTo(0,h*1.05,.13,h*.9);sh.lineTo(.13,h*.62);sh.lineTo(.34,h*.62);sh.lineTo(.34,h*.81);sh.quadraticCurveTo(.45,h*.9,.56,h*.81);sh.lineTo(.56,h*.57);sh.quadraticCurveTo(.56,h*.46,.4,h*.46);sh.lineTo(.13,h*.46);sh.lineTo(.13,0);sh.closePath();outlined(new THREE.ExtrudeGeometry(sh,{depth:.035,bevelEnabled:false}),material('#759238'),x,.03,z);}
 if(s.landscape!=='interior'){card('arvore',2.0,3.3,-4.6,-1.4);cactus(4.9,-1,1.7);cactus(-5.1,1.2,1.0);}
 // Igreja de maquete e coreto em recortes separados sobre a página.
 if(s.villageProps){
  card('coreto',2.4,3.0,1,-1.8);card('casas',3.3,1.64,-3.6,-2.2);
  const church=new THREE.Group();church.position.set(-3.6,.04,-.9);root.add(church);box(1.1,1.55,.32,cream,0,.78,0,church);box(.45,2.55,.35,yellow,.62,1.28,-.05,church);outlined(new THREE.ConeGeometry(.37,.6,4),wood,.62,2.83,-.05,church);box(.08,.38,.08,dark,.62,3.24,-.05,church);box(.26,.07,.08,dark,.62,3.29,-.05,church);box(.4,.76,.035,dark,0,.38,.18,church);box(.21,.36,.035,dark,.62,2.1,.18,church);
 }
 if(s.mansionProps){
  card('casarao',4.3,4.35,0,-2.25);card('casas',2.7,1.35,4.15,-2.2);
  if(s.number<=9){box(3.5,.13,1.1,wood,-.5,.88,-1.02);box(3.55,.08,.08,cream,-.5,1.43,-.56);for(let n=0;n<12;n++)box(.045,.54,.045,dark,-2.15+n*.3,1.16,-.56);}
 }
 if(s.gateProps){const g=new THREE.Group();g.position.set(.95,.03,.7);root.add(g);for(let n=0;n<11;n++)box(.035,1.22,.035,dark,-1.5+n*.3,.61,0,g);for(let y of [.28,.92])box(3.1,.045,.04,dark,0,y,0,g);}
 if(s.pathProps){const mud=mesh(new THREE.CircleGeometry(1.65,28),material('#8f7545'),2.6,.04,.8);mud.rotation.x=-Math.PI/2;mud.scale.y=.55;const sign=label('BREJO DO NUNCA MAIS',3.4,.55,65);sign.position.set(1,1.85,-1.5);root.add(sign);}
 // Mapa em acordeão e textura própria: pivô independente das mãos de Epaminondas.
 let map=null;
 if(s.mapProps){
  const c=document.createElement('canvas');c.width=640;c.height=400;const q=c.getContext('2d');q.fillStyle='#eddca9';q.fillRect(0,0,640,400);q.strokeStyle='#365c45';q.lineWidth=17;q.beginPath();q.moveTo(20,270);q.bezierCurveTo(110,60,260,300,370,100);q.bezierCurveTo(470,10,560,300,620,160);q.stroke();q.strokeStyle='#7a4a27';q.lineWidth=8;q.beginPath();q.moveTo(60,40);q.lineTo(220,320);q.lineTo(530,70);q.stroke();q.fillStyle='#302415';q.font='bold 70px Georgia';q.fillText('N',540,82);q.beginPath();q.moveTo(570,95);q.lineTo(550,155);q.lineTo(590,155);q.closePath();q.fill();q.strokeStyle='#8d784d';q.lineWidth=3;for(let x=0;x<=640;x+=160){q.beginPath();q.moveTo(x,0);q.lineTo(x,400);q.stroke();}const tx=new THREE.CanvasTexture(c);tx.colorSpace=THREE.SRGBColorSpace;map=new THREE.Group();map.position.set(-1.28,1.27,.82);root.add(map);
  for(let n=0;n<4;n++){const g=new THREE.PlaneGeometry(.49,1.0),uv=g.attributes.uv;for(let i=0;i<uv.count;i++)uv.setX(i,(n+uv.getX(i))/4);const p=mesh(g,new THREE.MeshStandardMaterial({map:tx,side:THREE.DoubleSide,roughness:1}),-.735+n*.49,0,0,map);p.rotation.y=n%2?.08:-.08;}
 }
 let curtains=null;
 if(s.landscape==='interior'){
  box(7.4,3.7,.08,material('#d5a165'),0,1.85,-2.4);for(let x=-3.5;x<3.6;x+=.55)box(.025,3.6,.04,dark,x,1.8,-2.33);box(2.8,2.8,.09,cream,-.1,1.85,-1.1);box(2.35,2.45,.04,material('#4e4e40'),-.1,1.85,-1.02);
  if(s.curtainProps){curtains=[];for(const side of [-1,1]){const g=new THREE.Group();g.position.set(side*.68,.1,.05);root.add(g);box(1.5,3.35,.07,material('#ac542b'),0,1.68,0,g);for(let n=0;n<5;n++)box(.028,3.26,.055,dark,-.65+n*.32,1.68,.05,g);curtains.push({g,side});}}
 }
 let drawer=null,docCard=null;
 if(s.drawerProps){
  box(3.2,.95,1.1,wood,-.45,.51,.7);drawer=new THREE.Group();drawer.position.set(-.45,.48,1.05);root.add(drawer);box(2.85,.42,.82,yellow,0,0,0,drawer);box(.36,.08,.11,dark,0,.03,.48,drawer);docCard=label('TESTAMENTO',2.0,.65,105);docCard.position.set(-.45,1.52,1.24);root.add(document);
 }
 let tray=null,cups=[],bottle=null,hand=null;
 if(s.teaProps){
  const offer=s.teaOffering;tray=new THREE.Group();tray.position.set(offer?1.75:-.2,offer?1.27:1.0,offer?1.42:1.2);root.add(tray);
  if(!offer){box(3.8,.12,1.55,wood,-.2,.85,1.2);for(const x of [-1.75,1.35])for(const z of [.55,1.85])box(.1,.85,.1,dark,x,.42,z);}
  box(2.2,.07,.84,yellow,0,0,0,tray);for(const side of [-1,1]){const h=outlined(new THREE.TorusGeometry(.18,.025,5,12),dark,side*1.2,.02,0,tray);h.rotation.x=Math.PI/2;}
  for(let n=0;n<3;n++){
   const cup=new THREE.Group();cup.position.set((n-1)*.65,.06,0);tray.add(cup);outlined(new THREE.CylinderGeometry(.225,.16,.29,12),cream,0,.15,0,cup);outlined(new THREE.CylinderGeometry(.20,.20,.018,12),material('#795533'),0,.303,0,cup);const h=outlined(new THREE.TorusGeometry(.10,.025,5,10),blue,.225,.16,0,cup);h.scale.x=.8;const line=outlined(new THREE.TorusGeometry(.22,.018,4,14),blue,0,.27,0,cup);line.rotation.x=Math.PI/2;cups.push(cup);
  }
  if(s.bottleProps){bottle=new THREE.Group();bottle.position.set(.3,1.9,1.5);root.add(bottle);outlined(new THREE.CylinderGeometry(.11,.14,.38,8),material('#65827a'),0,0,0,bottle);box(.13,.13,.13,dark,0,.25,0,bottle);const mark=label('?',.15,.22,160);mark.position.set(0,0,.15);bottle.add(mark);}
  if(s.reachCup){hand=card('mao_helena',1.2,.68,-.4,1.62,1.0);}
 }
 // Lama permanece no menino depois do retorno, sem alterar a arte original.
 for(const {pivot,data:a} of actors)if(a.muddy){for(let n=0;n<6;n++){const blot=new THREE.Mesh(new THREE.CircleGeometry(.075+(n%3)*.013,6),material('#8c6332'));blot.position.set(-.28+(n%3)*.22,.14+Math.floor(n/3)*.24,.025);pivot.add(blot);}}
 let cliff=null;if(s.cliffhanger){cliff=label('CONTINUA...',4.5,.95,125);cliff.position.set(.1,3.4,.1);root.add(cliff);}
 // Consolida a geometria estática por material, preservando peças móveis e contornos.
 const dynamic=new Set([map,...(curtains||[]).map(x=>x.g),drawer,docCard,tray,bottle,hand,cliff].filter(Boolean));const buckets=new Map();root.updateMatrixWorld(true);const inv=new THREE.Matrix4().copy(root.matrixWorld).invert();
 for(const top of [...root.children]){if(dynamic.has(top))continue;top.traverse(obj=>{if(!obj.isMesh&&!obj.isLineSegments)return;const key=(obj.isMesh?'mesh':'line')+obj.material.uuid,g=obj.geometry.index?obj.geometry.toNonIndexed():obj.geometry.clone();g.applyMatrix4(new THREE.Matrix4().multiplyMatrices(inv,obj.matrixWorld));if(!buckets.has(key))buckets.set(key,{material:obj.material,line:obj.isLineSegments,parts:[]});buckets.get(key).parts.push(g);});root.remove(top);}
 for(const {material,line,parts} of buckets.values()){const g=new THREE.BufferGeometry();for(const attr of Object.keys(parts[0].attributes)){if(!parts.every(p=>p.getAttribute(attr)))continue;const itemSize=parts[0].getAttribute(attr).itemSize,values=new Float32Array(parts.reduce((n,p)=>n+p.getAttribute(attr).array.length,0));let offset=0;for(const p of parts){values.set(p.getAttribute(attr).array,offset);offset+=p.getAttribute(attr).array.length;}g.setAttribute(attr,new THREE.BufferAttribute(values,itemSize));}const o=line?new THREE.LineSegments(g,material):new THREE.Mesh(g,material);if(!line)o.castShadow=o.receiveShadow=true;root.add(o);for(const p of parts)p.dispose();}
 return {update(t,closing){
  const clock=Math.min(t,s.freezeAt??99);const rise=smooth((t-(s.coverOpening?2.5:.3))/1.3)*closing;root.scale.y=Math.max(.001,rise);root.visible=rise>.001;
  if(map)map.rotation.z=Math.PI*smooth((t-1.4)/2.0);
  if(curtains)for(const {g,side} of curtains)g.position.x=side*(.68+1.1*smooth((t-.7)/2.4));
  if(drawer){const open=smooth((t-.7)/1.2)*(1-smooth((t-5.3)/1));drawer.position.z=1.05+.55*open;docCard.position.y=1.52-.95*smooth((t-2.8)/1.8);docCard.rotation.x=-Math.PI/2*smooth((t-2.8)/1.8);docCard.visible=t<5.25;}
  if(bottle)bottle.rotation.z=.65*smooth((t-1)/1.3)*(1-smooth((t-4)/1.1));
  if(tray){tray.rotation.z=s.catJoke?Math.sin(t*12)*.055*Math.sin(Math.PI*smooth((t-1.2)/3)):0;tray.position.x=(s.teaOffering?1.75:-.2)+(s.number===17?.6*(1-smooth((t-.5)/2)):0);}
  if(hand)hand.position.x=-.4+1.0*smooth((t-1.0)/2.8);
  const talk=t>=.75&&t<.75+(s.voiceDuration||4.2);
  for(const {pivot,data:a,index:i} of actors){
   if(pivot.userData.head)pivot.userData.head.rotation.z=Math.sin(clock*4.1+i)*((a.asset===s.speakerAsset&&talk)?.045:.008);
   if(a.asset===s.speakerAsset&&talk)pivot.rotation.z+=Math.sin(clock*4.1)*.016;
   if(s.number===17&&a.asset==='veronica_oferece')pivot.position.x=a.x+.6*(1-smooth((t-.5)/2));
  }
  if(cliff)cliff.visible=t>4.05&&closing>.1;
  window.popupCabecudosAudit={scene:s.id,number:s.number,cups:s.teaProps&&root.visible?cups.length:0,mapRotation:map?.rotation.z??null,drawerOpen:drawer?drawer.position.z>1.3:false,documentVisible:docCard?.visible??false,teaTouched:false,handProgress:hand?smooth((t-1)/2.8):0,freeze:s.cliffhanger&&t>4.05,cast:actors.filter(x=>x.pivot.visible).map(x=>x.data.asset)};
 }};
}
