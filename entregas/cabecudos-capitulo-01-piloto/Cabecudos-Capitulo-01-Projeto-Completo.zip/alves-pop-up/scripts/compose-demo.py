"""Trilha instrumental original de demonstração, síntese aditiva sem amostras externas."""
from pathlib import Path
import json,math,struct,wave,subprocess
import numpy as np
root=Path(__file__).resolve().parents[1];story=json.loads((root/'stories/joao.json').read_text());duration=story['duration']+story['endCard']['duration'];sr=24000;audio=np.zeros(math.ceil(duration*sr),np.float64);beat=60/138;events=[]
def add(start,hold,midi,velocity=75,kind='reed',channel=0):
 if start>=duration:return
 length=min(hold+.12,duration-start);n=round(length*sr);t=np.arange(n)/sr;f=440*2**((midi-69)/12)
 if kind=='reed':
  z=np.zeros(n)
  for h,amp in enumerate([1,.43,.32,.18,.09,.05],1):z+=amp*(np.sin(2*np.pi*f*h*t)+.25*np.sin(2*np.pi*f*h*1.0025*t))
  z*=.085*(.96+.04*np.sin(2*np.pi*5.2*t))
 elif kind=='bass':z=.23*np.exp(-t*2.6)*(np.sin(2*np.pi*f*t)+.22*np.sin(4*np.pi*f*t))
 elif kind=='kick':z=.25*np.exp(-t*26)*np.sin(2*np.pi*(62*t+43*(1-np.exp(-t*32))/32))
 elif kind=='triangle':z=.035*np.exp(-t*27)*(np.sin(2*np.pi*2850*t)+.45*np.sin(2*np.pi*4310*t))
 else:z=.07*np.exp(-t*8)*(np.sin(2*np.pi*f*t)+.25*np.sin(4*np.pi*f*t))
 envelope=np.minimum(1,t/.018)*np.minimum(1,np.maximum(0,(length-t)/.11));z*=envelope*(velocity/100);at=round(start*sr);audio[at:at+n]+=z[:len(audio[at:at+n])];events.append((start,hold,midi,velocity,channel))
bar=0
while bar*4*beat<duration:
 start=bar*4*beat;rootnote=[62,67,69,62][bar%4];suspense=(72<=start<104) or start>=152
 phrase=([0,3,7,6,3,0] if suspense else [0,4,7,9,7,4])
 for j,degree in enumerate(phrase):add(start+j*(4/6)*beat,.48*beat,rootnote+degree,48 if suspense else 58,'reed')
 for k in [0,2]:add(start+k*beat,.7*beat,rootnote-24 if k==0 else rootnote-17,74,'bass',1)
 for k in range(4):
  add(start+k*beat,.08,36,52 if k%2 else 75,'kick',9)
  add(start+(k+.5)*beat,.07,81,42,'triangle',9)
 if suspense:
  for k in [1,3]:add(start+k*beat,.35*beat,rootnote+12+(3 if k==3 else 0),38,'pluck',2)
 bar+=1
# Pequeno motivo de suspense acompanha o alerta, sem encobrir a fala.
for j,note in enumerate([74,77,80]):add(155.8+j*.07,1.4,note,38,'pluck',2)
# Eco discreto, depois normalização e fade natural.
for delay,gain in [(.073,.08),(.129,.045)]:
 n=round(delay*sr);audio[n:]+=audio[:-n].copy()*gain
peak=np.max(np.abs(audio));audio*=.63/max(peak,1e-8);t=np.arange(len(audio))/sr;audio*=np.minimum(1,t/.15)*np.minimum(1,np.maximum(0,(duration-t)/1.2));stereo=np.column_stack([audio,audio*.98]);folder=root/'assets/musica';folder.mkdir(exist_ok=True)
with wave.open(str(folder/'tema-cabecudos.wav'),'wb') as w:w.setnchannels(2);w.setsampwidth(2);w.setframerate(sr);w.writeframes(np.int16(np.clip(stereo,-1,1)*32767).tobytes())
subprocess.run(['ffmpeg','-v','error','-y','-i',str(folder/'tema-cabecudos.wav'),'-codec:a','libmp3lame','-b:a','160k',str(folder/'tema-cabecudos.mp3')],check=True)
# MIDI original, sem biblioteca externa e sem banco de amostras.
def vlq(v):
 b=[v&127];v>>=7
 while v:b.insert(0,(v&127)|128);v>>=7
 return bytes(b)
def chunk(data):return b'MTrk'+struct.pack('>I',len(data))+data
ppq=480;tracks=[];tempo=round(60000000/138);tracks.append(chunk(b'\x00\xff\x51\x03'+tempo.to_bytes(3,'big')+b'\x00\xff\x2f\x00'))
for ch,program in [(0,21),(1,32),(2,45),(9,None)]:
 ev=[]
 for start,hold,note,vel,c in events:
  if c==ch:
   a=round(start/beat*ppq);b=round((start+hold)/beat*ppq);ev.extend([(a,bytes([0x90+ch,note,vel])),(b,bytes([0x80+ch,note,0]))])
 ev.sort(key=lambda x:x[0]);data=b'' if program is None else bytes([0,0xc0+ch,program]);last=0
 for at,msg in ev:data+=vlq(at-last)+msg;last=at
 data+=b'\x00\xff\x2f\x00';tracks.append(chunk(data))
(folder/'tema-cabecudos.mid').write_bytes(b'MThd'+struct.pack('>IHHH',6,1,len(tracks),ppq)+b''.join(tracks))
(folder/'composicao.json').write_text(json.dumps({'original':True,'type':'Trilha instrumental de demonstração','bpm':138,'duration':duration,'method':'Síntese aditiva de timbres de palheta, baixo, percussão e motivo de suspense; sem amostras externas.','notSuno':True,'notNoiz':True},ensure_ascii=False,indent=2))
(folder/'tema-cabecudos.wav').unlink(missing_ok=True)
print('PASS: trilha instrumental original de demonstração, MIDI e MP3,',duration,'s.')
