# OS CABEÇUDOS — CAPÍTULO 1: O CHÁ DA DISCÓRDIA
Vila de Gaitolé — cenário fictício do sertão nordestino
20 cenas x 8 segundos = 160 s, sem contar vinheta e créditos

## PROMPT MESTRE PARA FLOW
TARGET PLATFORM: Google Flow. TARGET MODEL: Veo 3.1 Lite. DURATION: 8 seconds. ASPECT RATIO: 9:16 vertical. COLORFUL BRAZILIAN CORDEL WOODCUT / XILOGRAVURA, NOT PHOTOREALISTIC. Hand-carved thick black ink outlines, printmaking crosshatch, aged yellow parchment, warm terracotta and ochre with vivid cobalt/green/burgundy, large Olinda-puppet-like caricature heads, expressive acting. FICTIONAL VILA DE GAITOLÉ: small town in Brazilian northeastern sertão, central gazebo, colorful low houses, tiled roofs, old mansion, chapel, market, cacti, hills. Preserve reference character appearance exactly: Helena 68 high gray-white bun burgundy dress; Camila 24 Black woman big curly afro blue denim jacket; Epaminondas 55 dark mustache green shirt; Verônica 38 wavy dark brown hair navy blue blazer; Téo 11 thick glasses teal shirt. Natural 2.5D parallax animation, moving arms, eyes, hair, clothes, props and depth, consistent character sizes; no frozen frame except final ending, no subtitles or writing baked into image, no brand logos, no location of a real town. Spoken dialogue in natural Brazilian Portuguese; only stated speaker speaks, no foreign accent or extra dialogue.

## CENAS
### CENA 01 — A vila desperta
IMAGEM: Panorâmica da vila, praça do coreto, casario, igreja e caatinga ao fundo
ÁUDIO: NARRADOR: Lá na Vila de Gaitolé, todo mundo tem opinião!
ANIMAÇÃO: Slow aerial push towards the village square; leaves, banners and rooster subtly move.
PROMPT FLOW: TARGET PLATFORM: Google Flow. TARGET MODEL: Veo 3.1 Lite. DURATION: 8 seconds. ASPECT RATIO: 9:16 vertical. COLORFUL BRAZILIAN CORDEL WOODCUT / XILOGRAVURA, NOT PHOTOREALISTIC. Hand-carved thick black ink outlines, printmaking crosshatch, aged yellow parchment, warm terracotta and ochre with vivid cobalt/green/burgundy, large Olinda-puppet-like caricature heads, expressive acting. FICTIONAL VILA DE GAITOLÉ: small town in Brazilian northeastern sertão, central gazebo, colorful low houses, tiled roofs, old mansion, chapel, market, cacti, hills. Preserve reference character appearance exactly: Helena 68 high gray-white bun burgundy dress; Camila 24 Black woman big curly afro blue denim jacket; Epaminondas 55 dark mustache green shirt; Verônica 38 wavy dark brown hair navy blue blazer; Téo 11 thick glasses teal shirt. Natural 2.5D parallax animation, moving arms, eyes, hair, clothes, props and depth, consistent character sizes; no frozen frame except final ending, no subtitles or writing baked into image, no brand logos, no location of a real town. Spoken dialogue in natural Brazilian Portuguese; only stated speaker speaks, no foreign accent or extra dialogue. SCENE: Panorâmica da vila, praça do coreto, casario, igreja e caatinga ao fundo. ACTION: Slow aerial push towards the village square; leaves, banners and rooster subtly move. AUDIO: NARRADOR: Lá na Vila de Gaitolé, todo mundo tem opinião!

### CENA 02 — Cabeças que não cedem
IMAGEM: Cinco protagonistas diante do casarão, expressões fortes
ÁUDIO: NARRADOR: Tem teimosia de sobra e um mistério no casarão!
ANIMAÇÃO: Short energetic comic portrait transitions revealing all five protagonists, preserve faces.
PROMPT FLOW: TARGET PLATFORM: Google Flow. TARGET MODEL: Veo 3.1 Lite. DURATION: 8 seconds. ASPECT RATIO: 9:16 vertical. COLORFUL BRAZILIAN CORDEL WOODCUT / XILOGRAVURA, NOT PHOTOREALISTIC. Hand-carved thick black ink outlines, printmaking crosshatch, aged yellow parchment, warm terracotta and ochre with vivid cobalt/green/burgundy, large Olinda-puppet-like caricature heads, expressive acting. FICTIONAL VILA DE GAITOLÉ: small town in Brazilian northeastern sertão, central gazebo, colorful low houses, tiled roofs, old mansion, chapel, market, cacti, hills. Preserve reference character appearance exactly: Helena 68 high gray-white bun burgundy dress; Camila 24 Black woman big curly afro blue denim jacket; Epaminondas 55 dark mustache green shirt; Verônica 38 wavy dark brown hair navy blue blazer; Téo 11 thick glasses teal shirt. Natural 2.5D parallax animation, moving arms, eyes, hair, clothes, props and depth, consistent character sizes; no frozen frame except final ending, no subtitles or writing baked into image, no brand logos, no location of a real town. Spoken dialogue in natural Brazilian Portuguese; only stated speaker speaks, no foreign accent or extra dialogue. SCENE: Cinco protagonistas diante do casarão, expressões fortes. ACTION: Short energetic comic portrait transitions revealing all five protagonists, preserve faces. AUDIO: NARRADOR: Tem teimosia de sobra e um mistério no casarão!

### CENA 03 — O mapa de cabeça para baixo
IMAGEM: Epaminondas junto a Téo na Rua dos Teimosos, mapa invertido
ÁUDIO: EPAMINONDAS: Esse mapa está errado, eu conheço cada atalho!
ANIMAÇÃO: Medium shot, Epaminondas confidently rotates inverted map and points away.
PROMPT FLOW: TARGET PLATFORM: Google Flow. TARGET MODEL: Veo 3.1 Lite. DURATION: 8 seconds. ASPECT RATIO: 9:16 vertical. COLORFUL BRAZILIAN CORDEL WOODCUT / XILOGRAVURA, NOT PHOTOREALISTIC. Hand-carved thick black ink outlines, printmaking crosshatch, aged yellow parchment, warm terracotta and ochre with vivid cobalt/green/burgundy, large Olinda-puppet-like caricature heads, expressive acting. FICTIONAL VILA DE GAITOLÉ: small town in Brazilian northeastern sertão, central gazebo, colorful low houses, tiled roofs, old mansion, chapel, market, cacti, hills. Preserve reference character appearance exactly: Helena 68 high gray-white bun burgundy dress; Camila 24 Black woman big curly afro blue denim jacket; Epaminondas 55 dark mustache green shirt; Verônica 38 wavy dark brown hair navy blue blazer; Téo 11 thick glasses teal shirt. Natural 2.5D parallax animation, moving arms, eyes, hair, clothes, props and depth, consistent character sizes; no frozen frame except final ending, no subtitles or writing baked into image, no brand logos, no location of a real town. Spoken dialogue in natural Brazilian Portuguese; only stated speaker speaks, no foreign accent or extra dialogue. SCENE: Epaminondas junto a Téo na Rua dos Teimosos, mapa invertido. ACTION: Medium shot, Epaminondas confidently rotates inverted map and points away. AUDIO: EPAMINONDAS: Esse mapa está errado, eu conheço cada atalho!

### CENA 04 — O aviso de Téo
IMAGEM: Téo aponta a praça e tenta corrigir o pai
ÁUDIO: TÉO: Pai, o caminho é do outro lado!
ANIMAÇÃO: Eyeglasses reflect the church; boy points, father frowns dismissively.
PROMPT FLOW: TARGET PLATFORM: Google Flow. TARGET MODEL: Veo 3.1 Lite. DURATION: 8 seconds. ASPECT RATIO: 9:16 vertical. COLORFUL BRAZILIAN CORDEL WOODCUT / XILOGRAVURA, NOT PHOTOREALISTIC. Hand-carved thick black ink outlines, printmaking crosshatch, aged yellow parchment, warm terracotta and ochre with vivid cobalt/green/burgundy, large Olinda-puppet-like caricature heads, expressive acting. FICTIONAL VILA DE GAITOLÉ: small town in Brazilian northeastern sertão, central gazebo, colorful low houses, tiled roofs, old mansion, chapel, market, cacti, hills. Preserve reference character appearance exactly: Helena 68 high gray-white bun burgundy dress; Camila 24 Black woman big curly afro blue denim jacket; Epaminondas 55 dark mustache green shirt; Verônica 38 wavy dark brown hair navy blue blazer; Téo 11 thick glasses teal shirt. Natural 2.5D parallax animation, moving arms, eyes, hair, clothes, props and depth, consistent character sizes; no frozen frame except final ending, no subtitles or writing baked into image, no brand logos, no location of a real town. Spoken dialogue in natural Brazilian Portuguese; only stated speaker speaks, no foreign accent or extra dialogue. SCENE: Téo aponta a praça e tenta corrigir o pai. ACTION: Eyeglasses reflect the church; boy points, father frowns dismissively. AUDIO: TÉO: Pai, o caminho é do outro lado!

### CENA 05 — O caminho do brejo
IMAGEM: Epaminondas conduz Téo para o Brejo do Nunca Mais
ÁUDIO: EPAMINONDAS: Siga quem sabe, menino!
ANIMAÇÃO: Side tracking shot, father and son walk towards dirt path, goat follows.
PROMPT FLOW: TARGET PLATFORM: Google Flow. TARGET MODEL: Veo 3.1 Lite. DURATION: 8 seconds. ASPECT RATIO: 9:16 vertical. COLORFUL BRAZILIAN CORDEL WOODCUT / XILOGRAVURA, NOT PHOTOREALISTIC. Hand-carved thick black ink outlines, printmaking crosshatch, aged yellow parchment, warm terracotta and ochre with vivid cobalt/green/burgundy, large Olinda-puppet-like caricature heads, expressive acting. FICTIONAL VILA DE GAITOLÉ: small town in Brazilian northeastern sertão, central gazebo, colorful low houses, tiled roofs, old mansion, chapel, market, cacti, hills. Preserve reference character appearance exactly: Helena 68 high gray-white bun burgundy dress; Camila 24 Black woman big curly afro blue denim jacket; Epaminondas 55 dark mustache green shirt; Verônica 38 wavy dark brown hair navy blue blazer; Téo 11 thick glasses teal shirt. Natural 2.5D parallax animation, moving arms, eyes, hair, clothes, props and depth, consistent character sizes; no frozen frame except final ending, no subtitles or writing baked into image, no brand logos, no location of a real town. Spoken dialogue in natural Brazilian Portuguese; only stated speaker speaks, no foreign accent or extra dialogue. SCENE: Epaminondas conduz Téo para o Brejo do Nunca Mais. ACTION: Side tracking shot, father and son walk towards dirt path, goat follows. AUDIO: EPAMINONDAS: Siga quem sabe, menino!

### CENA 06 — A dona do casarão
IMAGEM: Dona Helena na varanda do casarão colonial
ÁUDIO: HELENA: Ninguém mexe numa telha desta casa!
ANIMAÇÃO: Low-angle camera, Helena lifts one finger sternly and tightens grip on purse.
PROMPT FLOW: TARGET PLATFORM: Google Flow. TARGET MODEL: Veo 3.1 Lite. DURATION: 8 seconds. ASPECT RATIO: 9:16 vertical. COLORFUL BRAZILIAN CORDEL WOODCUT / XILOGRAVURA, NOT PHOTOREALISTIC. Hand-carved thick black ink outlines, printmaking crosshatch, aged yellow parchment, warm terracotta and ochre with vivid cobalt/green/burgundy, large Olinda-puppet-like caricature heads, expressive acting. FICTIONAL VILA DE GAITOLÉ: small town in Brazilian northeastern sertão, central gazebo, colorful low houses, tiled roofs, old mansion, chapel, market, cacti, hills. Preserve reference character appearance exactly: Helena 68 high gray-white bun burgundy dress; Camila 24 Black woman big curly afro blue denim jacket; Epaminondas 55 dark mustache green shirt; Verônica 38 wavy dark brown hair navy blue blazer; Téo 11 thick glasses teal shirt. Natural 2.5D parallax animation, moving arms, eyes, hair, clothes, props and depth, consistent character sizes; no frozen frame except final ending, no subtitles or writing baked into image, no brand logos, no location of a real town. Spoken dialogue in natural Brazilian Portuguese; only stated speaker speaks, no foreign accent or extra dialogue. SCENE: Dona Helena na varanda do casarão colonial. ACTION: Low-angle camera, Helena lifts one finger sternly and tightens grip on purse. AUDIO: HELENA: Ninguém mexe numa telha desta casa!

### CENA 07 — Chegada da ativista
IMAGEM: Camila chega ao portão com megafone e cartaz
ÁUDIO: CAMILA: Esse casarão devia virar um centro cultural!
ANIMAÇÃO: Camila approaches wrought iron gate, raises megaphone, waves protest sign.
PROMPT FLOW: TARGET PLATFORM: Google Flow. TARGET MODEL: Veo 3.1 Lite. DURATION: 8 seconds. ASPECT RATIO: 9:16 vertical. COLORFUL BRAZILIAN CORDEL WOODCUT / XILOGRAVURA, NOT PHOTOREALISTIC. Hand-carved thick black ink outlines, printmaking crosshatch, aged yellow parchment, warm terracotta and ochre with vivid cobalt/green/burgundy, large Olinda-puppet-like caricature heads, expressive acting. FICTIONAL VILA DE GAITOLÉ: small town in Brazilian northeastern sertão, central gazebo, colorful low houses, tiled roofs, old mansion, chapel, market, cacti, hills. Preserve reference character appearance exactly: Helena 68 high gray-white bun burgundy dress; Camila 24 Black woman big curly afro blue denim jacket; Epaminondas 55 dark mustache green shirt; Verônica 38 wavy dark brown hair navy blue blazer; Téo 11 thick glasses teal shirt. Natural 2.5D parallax animation, moving arms, eyes, hair, clothes, props and depth, consistent character sizes; no frozen frame except final ending, no subtitles or writing baked into image, no brand logos, no location of a real town. Spoken dialogue in natural Brazilian Portuguese; only stated speaker speaks, no foreign accent or extra dialogue. SCENE: Camila chega ao portão com megafone e cartaz. ACTION: Camila approaches wrought iron gate, raises megaphone, waves protest sign. AUDIO: CAMILA: Esse casarão devia virar um centro cultural!

### CENA 08 — A primeira discussão
IMAGEM: Helena encara Camila do alto da varanda
ÁUDIO: HELENA: Enquanto eu respirar, aqui quem manda sou eu!
ANIMAÇÃO: Two-shot with dynamic alternating focus and expressive hand gestures.
PROMPT FLOW: TARGET PLATFORM: Google Flow. TARGET MODEL: Veo 3.1 Lite. DURATION: 8 seconds. ASPECT RATIO: 9:16 vertical. COLORFUL BRAZILIAN CORDEL WOODCUT / XILOGRAVURA, NOT PHOTOREALISTIC. Hand-carved thick black ink outlines, printmaking crosshatch, aged yellow parchment, warm terracotta and ochre with vivid cobalt/green/burgundy, large Olinda-puppet-like caricature heads, expressive acting. FICTIONAL VILA DE GAITOLÉ: small town in Brazilian northeastern sertão, central gazebo, colorful low houses, tiled roofs, old mansion, chapel, market, cacti, hills. Preserve reference character appearance exactly: Helena 68 high gray-white bun burgundy dress; Camila 24 Black woman big curly afro blue denim jacket; Epaminondas 55 dark mustache green shirt; Verônica 38 wavy dark brown hair navy blue blazer; Téo 11 thick glasses teal shirt. Natural 2.5D parallax animation, moving arms, eyes, hair, clothes, props and depth, consistent character sizes; no frozen frame except final ending, no subtitles or writing baked into image, no brand logos, no location of a real town. Spoken dialogue in natural Brazilian Portuguese; only stated speaker speaks, no foreign accent or extra dialogue. SCENE: Helena encara Camila do alto da varanda. ACTION: Two-shot with dynamic alternating focus and expressive hand gestures. AUDIO: HELENA: Enquanto eu respirar, aqui quem manda sou eu!

### CENA 09 — Ninguém arredará o pé
IMAGEM: Camila cruza os braços em frente ao portão
ÁUDIO: CAMILA: Pois daqui não saio!
ANIMAÇÃO: Subtle slow push-in; Camila plants her feet, resolute expression.
PROMPT FLOW: TARGET PLATFORM: Google Flow. TARGET MODEL: Veo 3.1 Lite. DURATION: 8 seconds. ASPECT RATIO: 9:16 vertical. COLORFUL BRAZILIAN CORDEL WOODCUT / XILOGRAVURA, NOT PHOTOREALISTIC. Hand-carved thick black ink outlines, printmaking crosshatch, aged yellow parchment, warm terracotta and ochre with vivid cobalt/green/burgundy, large Olinda-puppet-like caricature heads, expressive acting. FICTIONAL VILA DE GAITOLÉ: small town in Brazilian northeastern sertão, central gazebo, colorful low houses, tiled roofs, old mansion, chapel, market, cacti, hills. Preserve reference character appearance exactly: Helena 68 high gray-white bun burgundy dress; Camila 24 Black woman big curly afro blue denim jacket; Epaminondas 55 dark mustache green shirt; Verônica 38 wavy dark brown hair navy blue blazer; Téo 11 thick glasses teal shirt. Natural 2.5D parallax animation, moving arms, eyes, hair, clothes, props and depth, consistent character sizes; no frozen frame except final ending, no subtitles or writing baked into image, no brand logos, no location of a real town. Spoken dialogue in natural Brazilian Portuguese; only stated speaker speaks, no foreign accent or extra dialogue. SCENE: Camila cruza os braços em frente ao portão. ACTION: Subtle slow push-in; Camila plants her feet, resolute expression. AUDIO: CAMILA: Pois daqui não saio!

### CENA 10 — Olhos pela cortina
IMAGEM: Verônica observa pela cortina, gato preto ao lado
ÁUDIO: VERÔNICA: Elas brigam e eu só tenho a ganhar.
ANIMAÇÃO: Close-up through curtains, sly smile and the cat walking past.
PROMPT FLOW: TARGET PLATFORM: Google Flow. TARGET MODEL: Veo 3.1 Lite. DURATION: 8 seconds. ASPECT RATIO: 9:16 vertical. COLORFUL BRAZILIAN CORDEL WOODCUT / XILOGRAVURA, NOT PHOTOREALISTIC. Hand-carved thick black ink outlines, printmaking crosshatch, aged yellow parchment, warm terracotta and ochre with vivid cobalt/green/burgundy, large Olinda-puppet-like caricature heads, expressive acting. FICTIONAL VILA DE GAITOLÉ: small town in Brazilian northeastern sertão, central gazebo, colorful low houses, tiled roofs, old mansion, chapel, market, cacti, hills. Preserve reference character appearance exactly: Helena 68 high gray-white bun burgundy dress; Camila 24 Black woman big curly afro blue denim jacket; Epaminondas 55 dark mustache green shirt; Verônica 38 wavy dark brown hair navy blue blazer; Téo 11 thick glasses teal shirt. Natural 2.5D parallax animation, moving arms, eyes, hair, clothes, props and depth, consistent character sizes; no frozen frame except final ending, no subtitles or writing baked into image, no brand logos, no location of a real town. Spoken dialogue in natural Brazilian Portuguese; only stated speaker speaks, no foreign accent or extra dialogue. SCENE: Verônica observa pela cortina, gato preto ao lado. ACTION: Close-up through curtains, sly smile and the cat walking past. AUDIO: VERÔNICA: Elas brigam e eu só tenho a ganhar.

### CENA 11 — O documento escondido
IMAGEM: Verônica examina um testamento na sala
ÁUDIO: VERÔNICA: Esse casarão ainda vai ser meu...
ANIMAÇÃO: Villain turns an old paper, then conceals it in a drawer.
PROMPT FLOW: TARGET PLATFORM: Google Flow. TARGET MODEL: Veo 3.1 Lite. DURATION: 8 seconds. ASPECT RATIO: 9:16 vertical. COLORFUL BRAZILIAN CORDEL WOODCUT / XILOGRAVURA, NOT PHOTOREALISTIC. Hand-carved thick black ink outlines, printmaking crosshatch, aged yellow parchment, warm terracotta and ochre with vivid cobalt/green/burgundy, large Olinda-puppet-like caricature heads, expressive acting. FICTIONAL VILA DE GAITOLÉ: small town in Brazilian northeastern sertão, central gazebo, colorful low houses, tiled roofs, old mansion, chapel, market, cacti, hills. Preserve reference character appearance exactly: Helena 68 high gray-white bun burgundy dress; Camila 24 Black woman big curly afro blue denim jacket; Epaminondas 55 dark mustache green shirt; Verônica 38 wavy dark brown hair navy blue blazer; Téo 11 thick glasses teal shirt. Natural 2.5D parallax animation, moving arms, eyes, hair, clothes, props and depth, consistent character sizes; no frozen frame except final ending, no subtitles or writing baked into image, no brand logos, no location of a real town. Spoken dialogue in natural Brazilian Portuguese; only stated speaker speaks, no foreign accent or extra dialogue. SCENE: Verônica examina um testamento na sala. ACTION: Villain turns an old paper, then conceals it in a drawer. AUDIO: VERÔNICA: Esse casarão ainda vai ser meu...

### CENA 12 — Uma bandeja suspeita
IMAGEM: Verônica prepara três xícaras de chá, frasco simbólico
ÁUDIO: VERÔNICA: Um chazinho vai resolver tudo...
ANIMAÇÃO: Close-up of cup and ominous small bottle, no identifiable chemicals, hand pauses.
PROMPT FLOW: TARGET PLATFORM: Google Flow. TARGET MODEL: Veo 3.1 Lite. DURATION: 8 seconds. ASPECT RATIO: 9:16 vertical. COLORFUL BRAZILIAN CORDEL WOODCUT / XILOGRAVURA, NOT PHOTOREALISTIC. Hand-carved thick black ink outlines, printmaking crosshatch, aged yellow parchment, warm terracotta and ochre with vivid cobalt/green/burgundy, large Olinda-puppet-like caricature heads, expressive acting. FICTIONAL VILA DE GAITOLÉ: small town in Brazilian northeastern sertão, central gazebo, colorful low houses, tiled roofs, old mansion, chapel, market, cacti, hills. Preserve reference character appearance exactly: Helena 68 high gray-white bun burgundy dress; Camila 24 Black woman big curly afro blue denim jacket; Epaminondas 55 dark mustache green shirt; Verônica 38 wavy dark brown hair navy blue blazer; Téo 11 thick glasses teal shirt. Natural 2.5D parallax animation, moving arms, eyes, hair, clothes, props and depth, consistent character sizes; no frozen frame except final ending, no subtitles or writing baked into image, no brand logos, no location of a real town. Spoken dialogue in natural Brazilian Portuguese; only stated speaker speaks, no foreign accent or extra dialogue. SCENE: Verônica prepara três xícaras de chá, frasco simbólico. ACTION: Close-up of cup and ominous small bottle, no identifiable chemicals, hand pauses. AUDIO: VERÔNICA: Um chazinho vai resolver tudo...

### CENA 13 — O gato atrapalha
IMAGEM: Gato preto roça na mesa; Verônica quase deixa a bandeja cair
ÁUDIO: VERÔNICA: Xô, gato intrometido!
ANIMAÇÃO: Cat swishes tail, tea cups rattle, villain catches tray.
PROMPT FLOW: TARGET PLATFORM: Google Flow. TARGET MODEL: Veo 3.1 Lite. DURATION: 8 seconds. ASPECT RATIO: 9:16 vertical. COLORFUL BRAZILIAN CORDEL WOODCUT / XILOGRAVURA, NOT PHOTOREALISTIC. Hand-carved thick black ink outlines, printmaking crosshatch, aged yellow parchment, warm terracotta and ochre with vivid cobalt/green/burgundy, large Olinda-puppet-like caricature heads, expressive acting. FICTIONAL VILA DE GAITOLÉ: small town in Brazilian northeastern sertão, central gazebo, colorful low houses, tiled roofs, old mansion, chapel, market, cacti, hills. Preserve reference character appearance exactly: Helena 68 high gray-white bun burgundy dress; Camila 24 Black woman big curly afro blue denim jacket; Epaminondas 55 dark mustache green shirt; Verônica 38 wavy dark brown hair navy blue blazer; Téo 11 thick glasses teal shirt. Natural 2.5D parallax animation, moving arms, eyes, hair, clothes, props and depth, consistent character sizes; no frozen frame except final ending, no subtitles or writing baked into image, no brand logos, no location of a real town. Spoken dialogue in natural Brazilian Portuguese; only stated speaker speaks, no foreign accent or extra dialogue. SCENE: Gato preto roça na mesa; Verônica quase deixa a bandeja cair. ACTION: Cat swishes tail, tea cups rattle, villain catches tray. AUDIO: VERÔNICA: Xô, gato intrometido!

### CENA 14 — O retorno enlameado
IMAGEM: Epaminondas e Téo chegam de volta sujos de lama
ÁUDIO: TÉO: Eu disse que íamos parar no brejo!
ANIMAÇÃO: Camera follows muddy pair entering town, father wipes his mustache.
PROMPT FLOW: TARGET PLATFORM: Google Flow. TARGET MODEL: Veo 3.1 Lite. DURATION: 8 seconds. ASPECT RATIO: 9:16 vertical. COLORFUL BRAZILIAN CORDEL WOODCUT / XILOGRAVURA, NOT PHOTOREALISTIC. Hand-carved thick black ink outlines, printmaking crosshatch, aged yellow parchment, warm terracotta and ochre with vivid cobalt/green/burgundy, large Olinda-puppet-like caricature heads, expressive acting. FICTIONAL VILA DE GAITOLÉ: small town in Brazilian northeastern sertão, central gazebo, colorful low houses, tiled roofs, old mansion, chapel, market, cacti, hills. Preserve reference character appearance exactly: Helena 68 high gray-white bun burgundy dress; Camila 24 Black woman big curly afro blue denim jacket; Epaminondas 55 dark mustache green shirt; Verônica 38 wavy dark brown hair navy blue blazer; Téo 11 thick glasses teal shirt. Natural 2.5D parallax animation, moving arms, eyes, hair, clothes, props and depth, consistent character sizes; no frozen frame except final ending, no subtitles or writing baked into image, no brand logos, no location of a real town. Spoken dialogue in natural Brazilian Portuguese; only stated speaker speaks, no foreign accent or extra dialogue. SCENE: Epaminondas e Téo chegam de volta sujos de lama. ACTION: Camera follows muddy pair entering town, father wipes his mustache. AUDIO: TÉO: Eu disse que íamos parar no brejo!

### CENA 15 — A desculpa de sempre
IMAGEM: Epaminondas se endireita e ajeita a roupa
ÁUDIO: EPAMINONDAS: Era só uma pesquisa sobre o barro!
ANIMAÇÃO: Comedic close-up as man adjusts dirty collar, boy shakes head.
PROMPT FLOW: TARGET PLATFORM: Google Flow. TARGET MODEL: Veo 3.1 Lite. DURATION: 8 seconds. ASPECT RATIO: 9:16 vertical. COLORFUL BRAZILIAN CORDEL WOODCUT / XILOGRAVURA, NOT PHOTOREALISTIC. Hand-carved thick black ink outlines, printmaking crosshatch, aged yellow parchment, warm terracotta and ochre with vivid cobalt/green/burgundy, large Olinda-puppet-like caricature heads, expressive acting. FICTIONAL VILA DE GAITOLÉ: small town in Brazilian northeastern sertão, central gazebo, colorful low houses, tiled roofs, old mansion, chapel, market, cacti, hills. Preserve reference character appearance exactly: Helena 68 high gray-white bun burgundy dress; Camila 24 Black woman big curly afro blue denim jacket; Epaminondas 55 dark mustache green shirt; Verônica 38 wavy dark brown hair navy blue blazer; Téo 11 thick glasses teal shirt. Natural 2.5D parallax animation, moving arms, eyes, hair, clothes, props and depth, consistent character sizes; no frozen frame except final ending, no subtitles or writing baked into image, no brand logos, no location of a real town. Spoken dialogue in natural Brazilian Portuguese; only stated speaker speaks, no foreign accent or extra dialogue. SCENE: Epaminondas se endireita e ajeita a roupa. ACTION: Comedic close-up as man adjusts dirty collar, boy shakes head. AUDIO: EPAMINONDAS: Era só uma pesquisa sobre o barro!

### CENA 16 — Confusão no portão
IMAGEM: Helena e Camila discutem; Epaminondas e Téo se aproximam
ÁUDIO: HELENA: Minha porta virou praça de discussão?!
ANIMAÇÃO: Five-character staging begins, expressive reactions, maintain continuity.
PROMPT FLOW: TARGET PLATFORM: Google Flow. TARGET MODEL: Veo 3.1 Lite. DURATION: 8 seconds. ASPECT RATIO: 9:16 vertical. COLORFUL BRAZILIAN CORDEL WOODCUT / XILOGRAVURA, NOT PHOTOREALISTIC. Hand-carved thick black ink outlines, printmaking crosshatch, aged yellow parchment, warm terracotta and ochre with vivid cobalt/green/burgundy, large Olinda-puppet-like caricature heads, expressive acting. FICTIONAL VILA DE GAITOLÉ: small town in Brazilian northeastern sertão, central gazebo, colorful low houses, tiled roofs, old mansion, chapel, market, cacti, hills. Preserve reference character appearance exactly: Helena 68 high gray-white bun burgundy dress; Camila 24 Black woman big curly afro blue denim jacket; Epaminondas 55 dark mustache green shirt; Verônica 38 wavy dark brown hair navy blue blazer; Téo 11 thick glasses teal shirt. Natural 2.5D parallax animation, moving arms, eyes, hair, clothes, props and depth, consistent character sizes; no frozen frame except final ending, no subtitles or writing baked into image, no brand logos, no location of a real town. Spoken dialogue in natural Brazilian Portuguese; only stated speaker speaks, no foreign accent or extra dialogue. SCENE: Helena e Camila discutem; Epaminondas e Téo se aproximam. ACTION: Five-character staging begins, expressive reactions, maintain continuity. AUDIO: HELENA: Minha porta virou praça de discussão?!

### CENA 17 — A falsa reconciliação
IMAGEM: Verônica sai do casarão com bandeja e sorriso ensaiado
ÁUDIO: VERÔNICA: Família, trouxe um chá para fazer as pazes!
ANIMAÇÃO: Camera gently tracks towards the tray, Verônica offers the cups.
PROMPT FLOW: TARGET PLATFORM: Google Flow. TARGET MODEL: Veo 3.1 Lite. DURATION: 8 seconds. ASPECT RATIO: 9:16 vertical. COLORFUL BRAZILIAN CORDEL WOODCUT / XILOGRAVURA, NOT PHOTOREALISTIC. Hand-carved thick black ink outlines, printmaking crosshatch, aged yellow parchment, warm terracotta and ochre with vivid cobalt/green/burgundy, large Olinda-puppet-like caricature heads, expressive acting. FICTIONAL VILA DE GAITOLÉ: small town in Brazilian northeastern sertão, central gazebo, colorful low houses, tiled roofs, old mansion, chapel, market, cacti, hills. Preserve reference character appearance exactly: Helena 68 high gray-white bun burgundy dress; Camila 24 Black woman big curly afro blue denim jacket; Epaminondas 55 dark mustache green shirt; Verônica 38 wavy dark brown hair navy blue blazer; Téo 11 thick glasses teal shirt. Natural 2.5D parallax animation, moving arms, eyes, hair, clothes, props and depth, consistent character sizes; no frozen frame except final ending, no subtitles or writing baked into image, no brand logos, no location of a real town. Spoken dialogue in natural Brazilian Portuguese; only stated speaker speaks, no foreign accent or extra dialogue. SCENE: Verônica sai do casarão com bandeja e sorriso ensaiado. ACTION: Camera gently tracks towards the tray, Verônica offers the cups. AUDIO: VERÔNICA: Família, trouxe um chá para fazer as pazes!

### CENA 18 — Desconfiança
IMAGEM: Téo observa a bandeja e o sorriso de Verônica
ÁUDIO: TÉO: Desde quando ela faz as pazes com chá?
ANIMAÇÃO: Close-up on Téo suspicious eyes and reflection of tea cups in glasses.
PROMPT FLOW: TARGET PLATFORM: Google Flow. TARGET MODEL: Veo 3.1 Lite. DURATION: 8 seconds. ASPECT RATIO: 9:16 vertical. COLORFUL BRAZILIAN CORDEL WOODCUT / XILOGRAVURA, NOT PHOTOREALISTIC. Hand-carved thick black ink outlines, printmaking crosshatch, aged yellow parchment, warm terracotta and ochre with vivid cobalt/green/burgundy, large Olinda-puppet-like caricature heads, expressive acting. FICTIONAL VILA DE GAITOLÉ: small town in Brazilian northeastern sertão, central gazebo, colorful low houses, tiled roofs, old mansion, chapel, market, cacti, hills. Preserve reference character appearance exactly: Helena 68 high gray-white bun burgundy dress; Camila 24 Black woman big curly afro blue denim jacket; Epaminondas 55 dark mustache green shirt; Verônica 38 wavy dark brown hair navy blue blazer; Téo 11 thick glasses teal shirt. Natural 2.5D parallax animation, moving arms, eyes, hair, clothes, props and depth, consistent character sizes; no frozen frame except final ending, no subtitles or writing baked into image, no brand logos, no location of a real town. Spoken dialogue in natural Brazilian Portuguese; only stated speaker speaks, no foreign accent or extra dialogue. SCENE: Téo observa a bandeja e o sorriso de Verônica. ACTION: Close-up on Téo suspicious eyes and reflection of tea cups in glasses. AUDIO: TÉO: Desde quando ela faz as pazes com chá?

### CENA 19 — Mão na xícara
IMAGEM: Helena estende a mão para pegar a xícara
ÁUDIO: NARRADOR: Mas o menino percebeu que havia uma armação...
ANIMAÇÃO: Extreme close-up hand nearing teacup, suspenseful slow motion.
PROMPT FLOW: TARGET PLATFORM: Google Flow. TARGET MODEL: Veo 3.1 Lite. DURATION: 8 seconds. ASPECT RATIO: 9:16 vertical. COLORFUL BRAZILIAN CORDEL WOODCUT / XILOGRAVURA, NOT PHOTOREALISTIC. Hand-carved thick black ink outlines, printmaking crosshatch, aged yellow parchment, warm terracotta and ochre with vivid cobalt/green/burgundy, large Olinda-puppet-like caricature heads, expressive acting. FICTIONAL VILA DE GAITOLÉ: small town in Brazilian northeastern sertão, central gazebo, colorful low houses, tiled roofs, old mansion, chapel, market, cacti, hills. Preserve reference character appearance exactly: Helena 68 high gray-white bun burgundy dress; Camila 24 Black woman big curly afro blue denim jacket; Epaminondas 55 dark mustache green shirt; Verônica 38 wavy dark brown hair navy blue blazer; Téo 11 thick glasses teal shirt. Natural 2.5D parallax animation, moving arms, eyes, hair, clothes, props and depth, consistent character sizes; no frozen frame except final ending, no subtitles or writing baked into image, no brand logos, no location of a real town. Spoken dialogue in natural Brazilian Portuguese; only stated speaker speaks, no foreign accent or extra dialogue. SCENE: Helena estende a mão para pegar a xícara. ACTION: Extreme close-up hand nearing teacup, suspenseful slow motion. AUDIO: NARRADOR: Mas o menino percebeu que havia uma armação...

### CENA 20 — Não bebam!
IMAGEM: Téo ergue a mão e interrompe todos
ÁUDIO: TÉO: ESPEREM! NÃO BEBAM ESSE CHÁ!
ANIMAÇÃO: Sharp push-in on boy, everyone freezes their movement, end on black with suspense.
PROMPT FLOW: TARGET PLATFORM: Google Flow. TARGET MODEL: Veo 3.1 Lite. DURATION: 8 seconds. ASPECT RATIO: 9:16 vertical. COLORFUL BRAZILIAN CORDEL WOODCUT / XILOGRAVURA, NOT PHOTOREALISTIC. Hand-carved thick black ink outlines, printmaking crosshatch, aged yellow parchment, warm terracotta and ochre with vivid cobalt/green/burgundy, large Olinda-puppet-like caricature heads, expressive acting. FICTIONAL VILA DE GAITOLÉ: small town in Brazilian northeastern sertão, central gazebo, colorful low houses, tiled roofs, old mansion, chapel, market, cacti, hills. Preserve reference character appearance exactly: Helena 68 high gray-white bun burgundy dress; Camila 24 Black woman big curly afro blue denim jacket; Epaminondas 55 dark mustache green shirt; Verônica 38 wavy dark brown hair navy blue blazer; Téo 11 thick glasses teal shirt. Natural 2.5D parallax animation, moving arms, eyes, hair, clothes, props and depth, consistent character sizes; no frozen frame except final ending, no subtitles or writing baked into image, no brand logos, no location of a real town. Spoken dialogue in natural Brazilian Portuguese; only stated speaker speaks, no foreign accent or extra dialogue. SCENE: Téo ergue a mão e interrompe todos. ACTION: Sharp push-in on boy, everyone freezes their movement, end on black with suspense. AUDIO: TÉO: ESPEREM! NÃO BEBAM ESSE CHÁ!

## MÚSICA — LETRA PARA SUNO
[Spoken Intro]
Minha gente, chegue perto,
Venha ouvir esta canção!
Lá na Vila de Gaitolé
Vai começar a confusão!

[Verse 1]
Dona Helena é quem decide,
Quer mandar no casarão,
Mas Camila vem da praça
Com coragem e megafone na mão.
Epaminondas lê o mapa
Sem admitir que errou,
Téo avisa: “É outro rumo!”
Mas o pai nem escutou!

[Chorus]
Ô cabeça dura, deixa de teimar!
Na Vila de Gaitolé a história vai virar!
Ô cabeça dura, escute o coração!
Tem riso, tem segredo e muita confusão!

[Verse 2]
Verônica vem sorrindo,
Com bandeja e chá na mão,
Traz mistério na conversa,
Tem segredo no casarão.
Dona Helena não se rende,
E Camila diz que não,
Mas o menino de óculos
Vai mudar a situação!

[Chorus]
Ô cabeça dura, deixa de teimar!
Na Vila de Gaitolé a história vai virar!
Ô cabeça dura, escute o coração!
Tem riso, tem segredo e muita confusão!

[Spoken Break]
Olha o chá! Olha o portão!
Olha o povo em discussão!
Quem não escuta conselho
Pode cair na armação!

[Final Chorus]
Ô cabeça dura, deixa de teimar!
Na Vila de Gaitolé a história vai virar!
Ô cabeça dura, escute o coração!
É novela de cordel, tem surpresa no sertão!

[Outro]
Os Cabeçudos! Êta povo pra teimar!

## SUNO STYLE
Traditional Northeastern Brazilian frevo-forró fusion for humorous cordel TV soap opera theme. 138 BPM, joyful accordion, zabumba, triangle, pandeiro, lively brass trumpets and trombones, acoustic bass, playful male lead and female call-and-response, mixed chorus, rhythmic spoken repente narrator, catchy short refrain, theatrical suspense stings, warm authentic Brazilian Portuguese vocal delivery, no EDM, no English lyrics.

## NOTA
Os 20 PNGs nomeados PREVIA_storyboard são recortes de um painel conceitual, não artes finais 9:16. Gerar as imagens individuais definitivas no Flow a partir dos prompts e imagens originais dos personagens.