# Os Cabeçudos — O Chá da Discórdia — piloto pop-up

Adaptação de teste do capítulo 1 da novela na fictícia Vila de Gaitolé. Vinte cenas de 8 segundos mais 6 segundos de encerramento: 2min46s. Horizontal 1280 × 720, 24 fps, H.264/AAC estéreo. Livro físico 3D sobre mesa trabalhada em sala decorada, capa intitulada e ilustrações de xilogravura de cordel colorida. Personagens com cabeças exageradas, como bonecos de Olinda.

## Assistir

Abra `output/cabecudos-capitulo-01.mp4`. No ZIP para assistir, extraia tudo e abra `alves-pop-up/ASSISTA-AQUI.mp4`. Não precisa executar .cmd ou instalar o programa para assistir ao vídeo pronto.

## Conteúdo do teste

Foram preservadas as 20 falas curtas do arquivo Roteiro_Prompts_Flow_Letra_Suno.md do kit enviado. Os PDFs descrevem versões anteriores mais longas. A direção foi adaptada dos prompts verticais do Flow para o livro pop-up horizontal solicitado. Arte nova, com recortes transparentes baseados nas referências; os pequenos PNGs PREVIA_storyboard não foram usados como personagens ampliados.

Mapa que gira em eixo próprio, varanda e portão, cortinas que abrem, gaveta deslizante e testamento que se recolhe, frasco simbólico, bandeja que oscila, três xícaras e mão de papel que se aproxima. Epaminondas e Téo voltam enlameados. O alerta final de Téo é mantido; ninguém bebe o chá e o capítulo termina em suspense.

Movimentos de teatro de papel: recortes se erguem das páginas, caminham e têm articulação de cabeça. Legendas por frase com identificação do falante. São poses de papel articuladas, com diálogos sintetizados. O título PILOTO identifica esta versão de teste. Nenhuma publicação no YouTube ou teste de desempenho foi realizado.

## Vozes e música

Três vozes sintéticas pt-BR, com seis perfis de cadência e tom: narradora, Helena e Verônica usam Thalita; Epaminondas usa Antonio; Camila e Téo usam Francisca com parâmetros diferentes. Perfis exatos e hashes de texto em references/adaptacao.json e assets/narracao/manifest.json. Não são clones ou gravações de atores. As falas começam 0,75 s após o início de cada cena e já estão incluídas no MP4.

O kit contém letra e uma proposta de estilo para Suno, sem música pronta. Para este teste foi composta uma trilha instrumental original de demonstração, por síntese aditiva de timbres de palheta, baixo e percussão. Não é uma canção gerada no Suno ou na Noiz. Arquivos MP3 e MIDI e o programa de composição acompanham o projeto. Música reduzida durante as falas e mais presente nas pausas; efeitos sintetizados discretos. Nenhuma API de música foi utilizada.

## Arquivos

- stories/joao.json: roteiro principal por compatibilidade do motor; cópia em stories/cabecudos-capitulo-01.json.
- assets/cabecudos/: cinco atlas originais em WebP sem perda; personagens, poses, casarão, coreto, casas, gato, bode e árvore. Recortes em engine/story.mjs.
- engine/cabecudos-props.mjs: mecanismos de papel e geometria 3D; elementos estáticos consolidados por material para acelerar a exportação.
- assets/narracao/: 20 MP3s, SRTs e manifesto de voz com perfil por fala.
- assets/musica/: tema instrumental MP3, composição MIDI e registro de origem.
- scripts/compose-demo.py: composição e síntese original, requer Python com NumPy e FFmpeg para recriar.
- references/: kit original em Markdown, textos dos PDFs, painéis e cenários fornecidos, direção e ficha dos perfis.
- publicacao/: capa, roteiro cronológico e legendas. Material de apoio, sem publicação automática.

## Editar e exportar

Requer Node.js 22+, Chrome/Chromium/Edge e FFmpeg. Execute `npm ci` e `npm start`. Exporte com `npm run render:fast -- --out output/cabecudos-capitulo-01.mp4`. CHROME_PATH e FFMPEG_PATH permitem informar os executáveis. As falas e a trilha já estão locais; a exportação não necessita de chave. Alterar texto exige regerar as falas por `npm run narrate` e revisar legendas/durações. A geração musical Noiz está desativada.

## Créditos

Roteiro, personagens, estética e referências fornecidos pelo autor. Ilustrações, mecanismos e trilha de demonstração preparados para este piloto. Contos de Gaitolé, YouTube @gaitolé, TikTok @gaitole0. Licença e avisos do Mira preservados em LICENSE-MIRA e vendor. O projeto não utiliza o Google Flow para renderizar; utiliza o motor Alves Pop-Up com Three.js e GSAP locais.
