# Jesus Acalma a Tempestade — livro pop-up narrado

Contos de Gaitolé. Adaptação infantil do roteiro enviado, inspirada em Marcos 4:35–41. Aproximadamente 3min53s (232,8333 segundos), horizontal 1280 × 720, 24 fps, H.264/AAC estéreo. Narração Thalita em português do Brasil, legendas por frase e a música “Calma, Ventania! — Jesus Acalma a Tempestade” reduzida durante as falas.

## Assistir

Abra `output/jesus-tempestade.mp4`. No ZIP para assistir, extraia tudo e abra `alves-pop-up/ASSISTA-AQUI.mp4`. Não precisa executar `.cmd` ou instalar o gerador para assistir ao vídeo pronto.

## História e apresentação

Dez cenas com capa azul-petróleo e dourada, mesa trabalhada e sala decorada. O livro se abre rapidamente e as peças se levantam das páginas. A voz começa aos 0,75 segundos. Barco com casco, tábuas, bancos, mastro, vela e cordas; Jesus sentado, dormindo e de pé; três discípulos em poses de preocupação e alívio. Ondas de papel articuladas, vento, entardecer, nuvens e céu estrelado. Jesus se levanta e acalma a tempestade; as ondas se recolhem e o barco estabiliza. Sem personagens caindo na água, barco virando ou efeitos assustadores.

A vinheta de uma criança com a avó, em uma página contemporânea distinta, acolhe a reflexão sobre expressar o medo e pedir ajuda. Encerramento com capa, marca, perfis, inscrição e indicação de Moisés e o Mar que se Abriu. Os elementos finais são gráficos do vídeo.

## Arquivos

- `stories/joao.json`: roteiro principal, nome mantido por compatibilidade. Cópia em `stories/jesus-tempestade.json`.
- `references/roteiro-fornecido.txt`: texto original enviado pelo usuário.
- `assets/tempestade/`: poses de Jesus e dos discípulos, criança e avó, sala e três cenários do lago. WebP sem perdas, com comparação RGBA aos PNGs originais.
- `engine/tempestade-props.mjs`: barco e ondas articuladas, céu que clareia, cais, margem e móveis da vinheta familiar.
- `assets/narracao/`: dez clipes Thalita, manifesto com hashes e tempos das legendas. Entrada de voz aos 0,75 segundos de cada cena; regras de geração, reprodução, legendas e exportação usam o mesmo deslocamento.
- `assets/musica/calma-ventania.mp3`: original preservado, duração 232,824 segundos. A trilha é reproduzida uma vez, completa, com redução nas falas e retorno nas pausas. O vídeo termina aproximadamente 0,009 segundo depois da duração de arquivo da música, para completar o último quadro, sem repetição.
- `assets/efeitos/`: vento e água suaves, pássaros na partida e sinal discreto de encerramento.
- `publicacao/`: capa, título, descrição, capítulos e duas miniaturas A/B.

## Editar e exportar

Requer Node.js 22+, Chrome/Chromium/Edge e FFmpeg. Execute `npm ci` e `npm start` para visualizar. Exporte com `npm run render:fast -- --out output/jesus-tempestade.mp4`. Use `CHROME_PATH` e `FFMPEG_PATH` se necessário. Áudios incluídos; geração Noiz desativada, sem chave necessária para exportar. Alterações no texto exigem nova voz e legendas; alterações de duração exigem revisar os tempos da voz e efeitos.

## Créditos

Roteiro e música enviados pelo autor. Referência: Marcos 4:35–41. Artes e mecanismos de papel preparados para este episódio. Contos de Gaitolé: YouTube @gaitolé; TikTok @gaitole0. Licença e avisos do Mira preservados em LICENSE-MIRA e vendor. Nenhum teste A/B de desempenho nem publicação no YouTube foi realizado.
