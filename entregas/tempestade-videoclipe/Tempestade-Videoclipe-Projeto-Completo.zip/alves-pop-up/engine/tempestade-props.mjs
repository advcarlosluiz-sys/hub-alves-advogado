import * as THREE from '../vendor/three.module.js';
const smooth=x=>{x=Math.max(0,Math.min(1,x));return x*x*(3-2*x)};
export function buildTempestadeProps(parent,s,textures={},actors=[]){
 const g=new THREE.Group();parent.add(g);
 const mat=c=>new THREE.MeshStandardMaterial({color:c,roughness:1,side:THREE.DoubleSide});
 const cream=mat('#e9dbb8'),edge=mat('#765136'),brown=mat('#a8794c'),sand=mat('#c9b58c'),green=mat('#8c9a70');
 function mesh(geo,m,x=0,y=0,z=0,p=g){const a=new THREE.Mesh(geo,m);a.position.set(x,y,z);a.castShadow=a.receiveShadow=true;p.add(a);return a}
 function box(w,h,d,m,x,y,z,p=g){return mesh(new THREE.BoxGeometry(w,h,d),m,x,y,z,p)}
 function tex(draw,w=768,h=384){const c=document.createElement('canvas');c.width=w;c.height=h;draw(c.getContext('2d'),w,h);const t=new THREE.CanvasTexture(c);t.colorSpace=THREE.SRGBColorSpace;return t}
 const woodTex=tex((c,w,h)=>{c.fillStyle='#b58a5d';c.fillRect(0,0,w,h);for(let n=0;n<100;n++){c.strokeStyle=n%3?'rgba(94,57,30,.15)':'rgba(247,222,176,.25)';c.lineWidth=n%3+1;c.beginPath();for(let k=0;k<16;k++){const x=k*w/15,y=(n*37)%h+Math.sin(k*.7+n)*2;k?c.lineTo(x,y):c.moveTo(x,y);}c.stroke();}c.strokeStyle='#7f5c3e';c.lineWidth=3;for(let n=1;n<5;n++){c.beginPath();c.moveTo(0,n*h/5);c.lineTo(w,n*h/5);c.stroke();}});
 const wood=new THREE.MeshStandardMaterial({map:woodTex,roughness:1,side:THREE.DoubleSide});
 const sailTex=tex((c,w,h)=>{c.fillStyle='#e8ddbb';c.fillRect(0,0,w,h);for(let n=0;n<280;n++){c.fillStyle=n%2?'rgba(120,91,58,.06)':'rgba(255,250,227,.12)';c.fillRect((n*97)%w,(n*53)%h,38,1);}c.strokeStyle='#c9b88e';c.lineWidth=4;c.strokeRect(10,10,w-20,h-20);c.beginPath();c.moveTo(w*.48,8);c.lineTo(w*.51,h-8);c.stroke();});
 const sailMat=new THREE.MeshStandardMaterial({map:sailTex,roughness:1,side:THREE.DoubleSide});
 const waterTex=tex((c,w,h)=>{const q=c.createLinearGradient(0,0,0,h);q.addColorStop(0,'#b7d8db');q.addColorStop(.45,'#72adbf');q.addColorStop(1,'#4c7e9b');c.fillStyle=q;c.fillRect(0,0,w,h);for(let n=0;n<240;n++){c.fillStyle=n%2?'rgba(238,236,202,.12)':'rgba(58,88,105,.06)';c.fillRect((n*97)%w,(n*53)%h,30,2);}});
 const waterMat=new THREE.MeshStandardMaterial({map:waterTex,roughness:1,side:THREE.DoubleSide});
 const boat=new THREE.Group();g.add(boat);const waves=[],clouds=[];let sail=null,clearSky=null;
 function tube(points,r,m,p=boat){const curve=new THREE.CatmullRomCurve3(points.map(a=>new THREE.Vector3(...a)));return mesh(new THREE.TubeGeometry(curve,24,r,5,false),m,0,0,0,p)}
 if(s.boatScene){
  for(const a of actors)if(a.data.boatPassenger)boat.add(a.pivot);
  const hull=new THREE.Shape();hull.moveTo(-3.3,1.05);hull.quadraticCurveTo(-2.9,.14,-2.2,.10);hull.lineTo(2.1,.10);hull.quadraticCurveTo(2.9,.2,3.3,1.05);hull.quadraticCurveTo(0,.88,-3.3,1.05);hull.closePath();
  const hullGeo=new THREE.ExtrudeGeometry(hull,{depth:.055,bevelEnabled:false});const pos=hullGeo.attributes.position,uv=hullGeo.attributes.uv;for(let n=0;n<pos.count;n++)uv.setXY(n,(pos.getX(n)+3.3)/6.6,pos.getY(n)/1.1);uv.needsUpdate=true;
  for(const z of [-.12,1.98]){mesh(hullGeo,[wood,cream],0,0,z,boat);tube([[-3.3,1.07,z],[0,.91,z],[3.3,1.07,z]],.04,edge);const pts=[];for(let n=0;n<26;n++){const x=-2.9+n*5.8/25;pts.push(new THREE.Vector3(x,.48+.05*Math.cos(x),z+.062));}boat.add(new THREE.Line(new THREE.BufferGeometry().setFromPoints(pts),new THREE.LineBasicMaterial({color:'#ede0bc'})));}
  box(4.6,.08,1.95,wood,0,.18,.95,boat);for(let n=0;n<11;n++)box(.43,.04,1.85,n%2?wood:brown,-2.35+n*.47,.42,.95,boat);
  for(const x of [-2.05,-.5,1.55])box(.3,.13,1.9,wood,x,.66,.95,boat);
  tube([[-3.3,1.05,-.1],[-3.5,.9,.95],[-3.3,1.05,2.02]],.04,edge);tube([[3.3,1.05,-.1],[3.5,.9,.95],[3.3,1.05,2.02]],.04,edge);
  mesh(new THREE.CylinderGeometry(.05,.065,4.1,10),wood,-.35,2.28,.01,boat);const spar=mesh(new THREE.CylinderGeometry(.035,.035,3.5,8),wood,-.25,4.02,.01,boat);spar.rotation.z=Math.PI/2;
  sail=new THREE.Group();sail.position.set(-.3,2.45,.03);boat.add(sail);const sh=new THREE.Shape();sh.moveTo(-1.6,.04);sh.quadraticCurveTo(-1.7,.8,-1.5,1.55);sh.lineTo(1.5,1.55);sh.quadraticCurveTo(1.8,.7,1.55,.04);sh.quadraticCurveTo(0,-.17,-1.6,.04);sh.closePath();const geo=new THREE.ShapeGeometry(sh);const gp=geo.attributes.position,gu=geo.attributes.uv;for(let n=0;n<gp.count;n++)gu.setXY(n,(gp.getX(n)+1.8)/3.6,gp.getY(n)/1.7);gu.needsUpdate=true;mesh(geo,sailMat,0,0,0,sail);
  tube([[-.35,4.3,.01],[-3,1.05,.55]],.018,cream);tube([[-.35,4.3,.01],[2.9,1.05,.55]],.018,cream);tube([[-1.8,4,.04],[-1.8,2.5,.04]],.012,cream);tube([[1.2,4,.04],[1.3,2.5,.04]],.012,cream);
  const cushion=box(.7,.13,.55,cream,2.5,.75,.96,boat);cushion.rotation.z=.05;
  for(let row=0;row<3;row++)for(const side of [-1,1]){
   const pivot=new THREE.Group();pivot.position.set(side*2.9,.035,-1.6+row*2.05);g.add(pivot);const w=5.1,sh=new THREE.Shape();sh.moveTo(-w/2,0);sh.lineTo(w/2,0);const top=[];
   for(let n=36;n>=0;n--){const x=-w/2+n*w/36,y=.5+.2*Math.sin(x*2.4+row)+.08*Math.sin(x*5.1);sh.lineTo(x,y);top.push(new THREE.Vector3(x,y,.065));}sh.closePath();const geo=new THREE.ExtrudeGeometry(sh,{depth:.05,bevelEnabled:false}),p=geo.attributes.position,u=geo.attributes.uv;for(let n=0;n<p.count;n++)u.setXY(n,(p.getX(n)+w/2)/w,p.getY(n));u.needsUpdate=true;mesh(geo,[waterMat,cream],0,0,0,pivot);pivot.add(new THREE.Line(new THREE.BufferGeometry().setFromPoints(top),new THREE.LineBasicMaterial({color:'#e5e4ce'})));waves.push({pivot,phase:row*1.4+side});
  }
  if(['storm','building','calming'].includes(s.seaState))for(const side of [-1,1]){const c=new THREE.Group();c.position.set(side*3,3.4,-2.65);g.add(c);for(let n=0;n<4;n++){const q=mesh(new THREE.CircleGeometry(.42+(n%2)*.13,12),mat(n%2?'#b7c3c5':'#94aab3'),(n-1.5)*.4,Math.sin(n)*.12,n*.018,c);q.scale.y=.7;q.receiveShadow=false;}clouds.push({c,side});}
  if(s.seaState==='calming'&&textures.noite){clearSky=mesh(new THREE.PlaneGeometry(8.6,4.9),new THREE.MeshStandardMaterial({map:textures.noite,transparent:true,opacity:0,roughness:1,side:THREE.DoubleSide,depthWrite:false}),0,2.45,-2.8,g);clearSky.castShadow=false;}
  if(s.shoreProps){const side=(s.sourceScene||s.id)==='partida'?-1:1;box(1.1,.16,4.3,sand,side*5.1,.1,-.6);for(let n=0;n<5;n++){const a=mesh(new THREE.DodecahedronGeometry(.18+(n%2)*.06),cream,side*(4.6+(n%2)*.3),.24,-1.5+n*.65);a.scale.set(1.3,.6,1);}for(let n=0;n<7;n++){const a=box(.03,.5+(n%3)*.12,.025,green,side*(4.8+(n%2)*.2),.4,-2+n*.4);a.rotation.z=side*.16;}}
  if(s.dockProps){for(let n=0;n<9;n++)box(.2,.07,2.1,wood,-5.2+n*.22,.5,-.3);for(const x of [-5.1,-3.6])for(const z of [-1.2,.6])box(.1,.65,.1,wood,x,.26,z);}
 }
 if(s.homeProps){const rug=mesh(new THREE.PlaneGeometry(7.1,4.8),cream,0,.03,.8);rug.rotation.x=-Math.PI/2;box(2.6,.55,.9,mat('#a2b8b1'),-1.1,.34,.25);box(2.6,1.4,.13,mat('#91a8a4'),-1.1,1.1,-.22);for(const x of [-2.4,.2])box(.2,.5,.95,cream,x,.75,.25);box(.9,.07,.7,wood,2.6,.7,.85);for(const x of [2.25,2.95])for(const z of [.6,1.1])box(.05,.7,.05,wood,x,.36,z);for(let n=0;n<3;n++)box(.55,.075,.4,mat(['#a97e6e','#90a2a3','#c3b26e'][n]),2.6,.8+n*.08,.85);mesh(new THREE.CylinderGeometry(.035,.05,1.8,10),wood,3.5,.95,-.9);mesh(new THREE.ConeGeometry(.47,.6,16,1,true),cream,3.5,2,-.9);}
 return{update(t,closing,clock=t){const q=s.seaState==='calming'?smooth((t-(s.calmAt??6))/(s.calmDuration??2.4)):0;let amp=s.seaState==='storm'?1:s.seaState==='building'?.2+.6*smooth((t-2)/12):s.seaState==='calming'?1-q:.06;g.scale.y=Math.max(.001,smooth((t-(s.coverOpening?2.35:.15))/1.0)*closing);boat.rotation.z=Math.sin(clock*1.8)*.047*amp;boat.rotation.x=Math.sin(clock*1.35+.5)*.025*amp;boat.position.y=.025+Math.sin(clock*1.8+.5)*.035*amp;boat.position.x=s.dockProps?.65*smooth((t-3)/8):(s.sourceScene||s.id)==='travessia'?.45*smooth((t-2)/16):0;if(sail){const windAmp=s.seaState==='calming'?1-smooth((t-(s.calmAt??6))/2):amp;sail.rotation.y=Math.sin(clock*2.8)*.1*windAmp;sail.rotation.z=Math.sin(clock*2.1)*.035*windAmp;}
 waves.forEach(({pivot,phase})=>{pivot.rotation.x=-1.48*(1-amp);pivot.rotation.z=Math.sin(clock*1.9+phase)*.025*amp;pivot.scale.y=.65+.35*(.8+.2*Math.sin(clock*1.5+phase))*amp;});clouds.forEach(({c,side})=>{c.position.x=side*(3+q*1.4)+Math.sin(clock*.35)*.06;c.scale.setScalar(Math.max(.001,1-q));c.visible=q<.99;});if(clearSky)clearSky.material.opacity=q;
 window.popupBoatAudit={scene:s.id,amplitude:amp,calmProgress:q,roll:boat.rotation.z,passengers:actors.filter(a=>a.data.boatPassenger&&a.pivot.visible).length,wavesFolded:waves.every(a=>Math.abs(a.pivot.rotation.x)>1.3)};
 }};
}
