# Calma, Ventania! — Jesus Acalma a Tempestade — videoclipe

Canção enviada pelo autor na íntegra, aproximadamente 3min53s (232,8333 segundos de vídeo; duração do arquivo musical original 232,824 segundos). Horizontal 1280 × 720, 24 fps, H.264/AAC estéreo. Vocal original da canção, sem narrador adicional ou efeitos sonoros sobrepostos.

## Assistir

Abra `output/tempestade-videoclipe.mp4`. No ZIP para assistir, extraia tudo e abra `alves-pop-up/ASSISTA-AQUI.mp4`. Não precisa executar `.cmd` ou instalar o gerador para assistir.

## Montagem

28 trechos com variações reais de câmera 3D e movimentos suaves próximos às pulsações estimadas da música. Livro com capa azul-petróleo e dourada, mesa trabalhada e sala decorada; barco de papel com tábuas, bancos, mastro, vela e cordas. Jesus sentado, dormindo e em pé; três discípulos em poses de preocupação e alívio; ondas articuladas que se recolhem, nuvens, entardecer e céu estrelado. Uma vinheta contemporânea da criança com a avó acompanha a mensagem de acolhimento. Encerramento com capa, marca, perfis, inscrição e indicação de “Um Caminho no Mar”, de Moisés.

As ações se adaptam à duração dos trechos; as oscilações do barco, vela e ondas mantêm um relógio próprio para conservar movimentos delicados. A montagem temática considera a letra dos metadados do MP3. A pulsação foi estimada por fluxo espectral; não há alinhamento de palavras ou marcação exata de seções vocais. Não é karaokê. A letra completa acompanha o kit.

## Arquivos

- `stories/joao.json`: roteiro principal, nome mantido por compatibilidade. Cópia em `stories/tempestade-videoclipe.json`.
- `references/montagem-videoclipe.json`: tempos dos 28 trechos e intervalos das ações de origem.
- `references/letra-musica-fornecida.txt`: letra extraída dos metadados da canção enviada.
- `references/roteiro-fornecido.txt`: roteiro da história que originou as cenas; o clipe usa somente a canção.
- `assets/tempestade/`: personagens, poses e cenários WebP sem perdas, reutilizados da história narrada; recortes em `engine/story.mjs`.
- `engine/tempestade-props.mjs`: barco e ondas de papel articulados, vela, céu, cais, margem e móveis da vinheta familiar.
- `assets/musica/calma-ventania.mp3`: arquivo original preservado, sem cortes, repetição ou substituição do vocal.
- `publicacao/`: capa, letra, título, descrição e duas miniaturas com indicação VIDEOCLIPE.

## Editar e exportar

Requer Node.js 22+, Chrome/Chromium/Edge e FFmpeg. Execute `npm ci` e `npm start` para visualizar. Exporte com `npm run render:fast -- --out output/tempestade-videoclipe.mp4`. Use `CHROME_PATH` e `FFMPEG_PATH` se necessário. A geração Noiz está desativada; a música incluída permite exportar sem chave.

## Créditos

Contos de Gaitolé: YouTube @gaitolé; TikTok @gaitole0. Música e roteiro de origem enviados pelo autor; referência bíblica Marcos 4:35–41. Artes e mecanismos de papel preparados para a história de Jesus acalmando a tempestade. Licença e avisos originais do Mira preservados em LICENSE-MIRA e vendor. Nenhum teste A/B de desempenho nem publicação no YouTube foi realizado.
