import { MOTIONS } from "./actor-motion.mjs";
export const ASSETS=Object.freeze(["alice_maravilhas", "coelho_relogio", "irma_alice", "rainha_alice", "cartas_alice", "arganaz_alice", "jardim_arvore_alice", "sala_portas_alice", "jardim_gigante_alice", "jardim_cha_alice", "jardim_rosas_alice", "arvore_gato_alice", "lagarta_alice", "gato_alice", "chapeleiro_alice", "lebre_alice", "folha"]);
export function validateStory(story) {
  if (
    !story ||
    typeof story.title !== "string" ||
    !story.title.trim() ||
    !Array.isArray(story.scenes) ||
    !story.scenes.length
  )
    throw Error("Roteiro precisa de título e cenas");
  if (
    story.endCard &&
    (!Number.isFinite(story.endCard.duration) ||
      story.endCard.duration < 3 ||
      story.endCard.duration > 15 ||
      typeof story.endCard.youtube?.name !== "string" ||
      typeof story.endCard.youtube?.handle !== "string" ||
      typeof story.endCard.tiktok?.handle !== "string")
  )
    throw Error("Tela final inválida");
  if (story.presentation) {
    const p=story.presentation;
    if (!Number.isFinite(p.introDuration) || p.introDuration<0 || p.introDuration>15 ||
        (p.cameraScale!==undefined && (!Number.isFinite(p.cameraScale) || p.cameraScale<0.9 || p.cameraScale>1.6)) ||
        (p.coverImage!==undefined && (!/^(assets|publicacao)\/[a-zA-Z0-9_./-]+\.(png|jpg)$/.test(p.coverImage) || p.coverImage.includes(".."))))
      throw Error("Apresentação do livro inválida");
  }
  const ids = new Set();
  let duration = 0;
  for (const s of story.scenes) {
    if (!s.id || ids.has(s.id))
      throw Error("Identificador de cena ausente ou repetido");
    ids.add(s.id);
    if (!Number.isFinite(s.duration) || s.duration < 3 || s.duration > 120)
      throw Error("Duração de cena inválida");
    if (typeof s.caption !== "string") throw Error("Legenda ausente");
    for (const key of ["from", "to", "target"])
      if (
        !Array.isArray(s.camera?.[key]) ||
        s.camera[key].length !== 3 ||
        !s.camera[key].every(Number.isFinite)
      )
        throw Error("Câmera inválida");
    if (!Array.isArray(s.actors) || s.actors.length > 60)
      throw Error("Atores inválidos");
    for (const a of s.actors) {
      if (a.motion) {
        if (!MOTIONS.includes(a.motion.type))
          throw Error("Movimento desconhecido");
        if (
          !Number.isFinite(a.motion.start) ||
          !Number.isFinite(a.motion.end) ||
          a.motion.start < 0 ||
          a.motion.end <= a.motion.start
        )
          throw Error("Intervalo de movimento inválido");
        for (const field of ["dx", "dy"])
          if (
            a.motion[field] !== undefined &&
            !Number.isFinite(a.motion[field])
          )
            throw Error("Deslocamento inválido");
      }

      if (!ASSETS.includes(a.asset))
        throw Error("Asset desconhecido: " + a.asset);
      for (const k of ["x", "z", "width", "height"])
        if (!Number.isFinite(a[k])) throw Error("Dimensão/posição inválida");
      if (a.width <= 0 || a.height <= 0 || a.width > 25 || a.height > 25)
        throw Error("Dimensão fora dos limites");
      for (const k of ["y", "walk", "enter"])
        if (a[k] !== undefined && !Number.isFinite(a[k]))
          throw Error("Parâmetro de ator inválido");
    }
    duration += s.duration;
  }
  if (
    !Number.isFinite(story.duration) ||
    Math.abs(duration - story.duration) > 0.001
  )
    throw Error("Duração total difere da soma das cenas");
  return story;
}
export function locateScene(story, time) {
  const t = Math.min(story.duration, Math.max(0, Number(time) || 0));
  let start = 0;
  for (let index = 0; index < story.scenes.length; index++) {
    const scene = story.scenes[index];
    if (t < start + scene.duration || index === story.scenes.length - 1)
      return { index, scene, local: t - start, start, time: t };
    start += scene.duration;
  }
}

export const ASSET_FILES={
  "alice_maravilhas": {
    "file": "assets/alice/personagens.png",
    "rect": [
      0,
      0,
      510,
      1024
    ]
  },
  "coelho_relogio": {
    "file": "assets/alice/personagens.png",
    "rect": [
      510,
      0,
      540,
      1024
    ]
  },
  "irma_alice": {
    "file": "assets/alice/personagens.png",
    "rect": [
      1050,
      0,
      486,
      1024
    ]
  },
  "rainha_alice": {
    "file": "assets/alice/rainha-cartas-arganaz.png",
    "rect": [
      0,
      0,
      610,
      724
    ]
  },
  "cartas_alice": {
    "file": "assets/alice/rainha-cartas-arganaz.png",
    "rect": [
      610,
      0,
      900,
      724
    ]
  },
  "arganaz_alice": {
    "file": "assets/alice/rainha-cartas-arganaz.png",
    "rect": [
      1510,
      0,
      662,
      724
    ]
  },
  "jardim_arvore_alice": {
    "file": "assets/alice/cenarios-1.png",
    "rect": [
      0,
      0,
      707,
      724
    ]
  },
  "sala_portas_alice": {
    "file": "assets/alice/cenarios-1.png",
    "rect": [
      707,
      0,
      748,
      724
    ]
  },
  "jardim_gigante_alice": {
    "file": "assets/alice/cenarios-1.png",
    "rect": [
      1455,
      0,
      717,
      724
    ]
  },
  "jardim_cha_alice": {
    "file": "assets/alice/cenarios-2.png",
    "rect": [
      0,
      0,
      707,
      724
    ]
  },
  "jardim_rosas_alice": {
    "file": "assets/alice/cenarios-2.png",
    "rect": [
      707,
      0,
      806,
      724
    ]
  },
  "arvore_gato_alice": {
    "file": "assets/alice/cenarios-2.png",
    "rect": [
      1513,
      0,
      659,
      724
    ]
  }
};

Object.assign(ASSET_FILES,{"lagarta_alice": {"file": "assets/alice/amigos.png", "rect": [0, 0, 543, 724]}, "gato_alice": {"file": "assets/alice/amigos.png", "rect": [543, 0, 543, 724]}, "chapeleiro_alice": {"file": "assets/alice/amigos.png", "rect": [1086, 0, 543, 724]}, "lebre_alice": {"file": "assets/alice/amigos.png", "rect": [1629, 0, 543, 724]}});
