# Alice no País das Maravilhas — Contos de Gaitolé

Produção em livro pop-up, narrada pela Thalita em português do Brasil, com a música fornecida **Alice v2**. Duração: **4min19s**; vídeo horizontal **1280 × 720**, **24 fps**, H.264/AAC estéreo.

## Assistir

Abra `output/alice-pais-maravilhas.mp4`. No ZIP para assistir, extraia e abra `alves-pop-up/ASSISTA-AQUI.mp4`. Não é necessário executar `.cmd` ou instalar o gerador para assistir.

## Conteúdo do projeto

- `stories/joao.json`: roteiro usado pelo motor; o nome é mantido por compatibilidade. `stories/alice-pais-maravilhas.json` é sua cópia nomeada.
- `assets/alice/`: ilustrações originais de personagens e cenários; os recortes estão mapeados em `engine/story.mjs` e `references/assets-originais.json`.
- `engine/alice-props.mjs`: relógios, espiral, porta articulada, mesa do chá, flores, cartas e demais elementos animados.
- `assets/narracao/`: 12 clipes Thalita e manifestos de sincronização. As legendas acompanham as frases da voz.
- `assets/musica/alice-v2.mp3`: música fornecida, preservada. O motor reduz o volume durante os clipes de narração e aumenta nas pausas.
- `assets/efeitos/`: ambiente suave e sinal de encerramento.
- `publicacao/`: miniatura 1280 × 720, capa, título e descrição para YouTube.
- `references/roteiro-fornecido.txt`: roteiro de referência.

## Editar e exportar novamente

Requer Node.js 22 ou superior, Chrome/Chromium/Edge e FFmpeg. Na pasta do projeto:

```sh
npm ci
npm start
```

Abra o endereço local mostrado no terminal para visualizar o livro. Para exportação com os áudios já incluídos:

```sh
npm run render:fast -- --out output/alice-pais-maravilhas.mp4
```

`CHROME_PATH` e `FFMPEG_PATH` permitem indicar os programas instalados. Alterar o texto requer regenerar a narração com `npm run narrate` (conexão à internet e dependências de voz). As vozes atuais já estão incluídas. A geração Noiz está desativada neste episódio porque foi utilizada a música fornecida; nenhuma chave é necessária para exportar estes arquivos existentes.

O cenário contém recortes ilustrados em espaço 3D e objetos geométricos animados. Novas histórias exigem adaptar roteiro, ilustrações e ações; o pacote não transforma qualquer texto automaticamente em arte inédita.

## Créditos

Adaptação original inspirada na obra de Lewis Carroll. Canal Contos de Gaitolé, YouTube @gaitolé e TikTok @gaitole0. Mira: sandeco/mira-animator, versão 0.1.69. Avisos e termos originais preservados em LICENSE-MIRA e vendor.
