# Jesus e os Cinco Pães e Dois Peixinhos — livro pop-up

História narrada do Contos de Gaitolé, adaptada do roteiro enviado e inspirada em João 6:1–13. Duração: 4min14s (254 segundos). Horizontal 1280 × 720, 24 fps, H.264/AAC estéreo. Voz Thalita em português do Brasil, legendas por frase e música “Um Pouquinho Vira Muito” com volume reduzido durante as falas.

## Assistir

Abra `output/cinco-paes.mp4`. No ZIP para assistir, extraia tudo e abra `alves-pop-up/ASSISTA-AQUI.mp4`. Não precisa executar `.cmd` nem instalar o gerador para assistir ao vídeo pronto.

## Livro e história

Capa verde e dourada, mesa trabalhada e sala com estantes, planta, janela e luminária. Dez cenas com lago da Galileia, Jesus, menino, André, discípulos, famílias, idosos e crianças. Cestas com dobradiças, cinco pães e dois peixes como peças separadas antes do milagre; um dos cinco pães se aproxima de Jesus na ação de graças. Na distribuição surgem novas porções. Depois, doze cestos de sobras se levantam um a um, em três filas de quatro, acompanhando a pergunta da narração. Sem efeitos luminosos exagerados.

A pergunta inicial começa aos 2 segundos, durante a capa e a abertura do livro. Encerramento com a marca, perfis, inscrição e indicação de “Moisés e o Mar que se Abriu”. Os convites são gráficos do vídeo.

## Arquivos incluídos

- `stories/joao.json`: roteiro principal, nome mantido por compatibilidade. Cópia em `stories/cinco-paes.json`.
- `references/roteiro-fornecido.txt`: texto original enviado pelo usuário.
- `assets/paes/`: personagens em pé e sentados e três cenários. Atlas WebP sem perdas, RGBA conferido com os originais; recortes em `engine/story.mjs`.
- `engine/paes-props.mjs`: peças do lanche, tampas articuladas, distribuição e doze cestos. Contagens conferidas em prévias reais do renderizador.
- `assets/narracao/`: dez clipes Thalita, manifesto com hashes e tempos das legendas.
- `assets/musica/um-pouquinho-vira-muito.mp3`: arquivo original preservado. A música tem aproximadamente 4min02s; como a história dura 4min14s, o início da faixa se repete brevemente no encerramento, com término suave. A música baixa durante as falas e sobe nas pausas.
- `assets/efeitos/`: ambiente discreto de pássaros, passos e sinal de encerramento.
- `publicacao/`: título, descrição, capítulos, capa e duas miniaturas de 1280 × 720.

## Editar e exportar novamente

Requer Node.js 22+, Chrome/Chromium/Edge e FFmpeg. Execute `npm ci`, depois `npm start` para visualizar. Exporte com `npm run render:fast -- --out output/cinco-paes.mp4`. Use `CHROME_PATH` e `FFMPEG_PATH` se necessário. Os áudios já estão incluídos e a geração Noiz está desativada, sem chave necessária para exportar. Alterar o texto exige gerar novamente narração e legendas.

## Créditos

Roteiro e música enviados pelo usuário; adaptação inspirada em João 6:1–13. Artes e mecanismos de papel preparados para o episódio. Contos de Gaitolé: YouTube @gaitolé; TikTok @gaitole0. Licença e avisos do Mira preservados em LICENSE-MIRA e vendor. Nenhuma publicação no YouTube nem teste A/B de desempenho foi realizado.
