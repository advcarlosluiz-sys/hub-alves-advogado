import { MOTIONS } from "./actor-motion.mjs";
export const ASSETS=Object.freeze(["aladdin", "mae_aladdin", "amira", "viajante", "genio", "guarda_aladdin", "mercado", "caverna_aladdin", "torre_aladdin", "oficina_aladdin", "cristais_aladdin", "jardim_aladdin", "gato_aladdin", "jardineiro_aladdin", "criancas_aladdin", "folha"]);
export function validateStory(story) {
  if (
    !story ||
    typeof story.title !== "string" ||
    !story.title.trim() ||
    !Array.isArray(story.scenes) ||
    !story.scenes.length
  )
    throw Error("Roteiro precisa de título e cenas");
  if (
    story.endCard &&
    (!Number.isFinite(story.endCard.duration) ||
      story.endCard.duration < 3 ||
      story.endCard.duration > 15 ||
      typeof story.endCard.youtube?.name !== "string" ||
      typeof story.endCard.youtube?.handle !== "string" ||
      typeof story.endCard.tiktok?.handle !== "string")
  )
    throw Error("Tela final inválida");
  if (story.presentation) {
    const p=story.presentation;
    if (!Number.isFinite(p.introDuration) || p.introDuration<0 || p.introDuration>15 ||
        (p.cameraScale!==undefined && (!Number.isFinite(p.cameraScale) || p.cameraScale<0.9 || p.cameraScale>1.6)) ||
        (p.coverImage!==undefined && (!/^(assets|publicacao)\/[a-zA-Z0-9_./-]+\.(png|jpg)$/.test(p.coverImage) || p.coverImage.includes(".."))))
      throw Error("Apresentação do livro inválida");
  }
  const ids = new Set();
  let duration = 0;
  for (const s of story.scenes) {
    if (!s.id || ids.has(s.id))
      throw Error("Identificador de cena ausente ou repetido");
    ids.add(s.id);
    if (!Number.isFinite(s.duration) || s.duration < 3 || s.duration > 120)
      throw Error("Duração de cena inválida");
    if (typeof s.caption !== "string") throw Error("Legenda ausente");
    for (const key of ["from", "to", "target"])
      if (
        !Array.isArray(s.camera?.[key]) ||
        s.camera[key].length !== 3 ||
        !s.camera[key].every(Number.isFinite)
      )
        throw Error("Câmera inválida");
    if (!Array.isArray(s.actors) || s.actors.length > 60)
      throw Error("Atores inválidos");
    for (const a of s.actors) {
      if (a.motion) {
        if (!MOTIONS.includes(a.motion.type))
          throw Error("Movimento desconhecido");
        if (
          !Number.isFinite(a.motion.start) ||
          !Number.isFinite(a.motion.end) ||
          a.motion.start < 0 ||
          a.motion.end <= a.motion.start
        )
          throw Error("Intervalo de movimento inválido");
        for (const field of ["dx", "dy"])
          if (
            a.motion[field] !== undefined &&
            !Number.isFinite(a.motion[field])
          )
            throw Error("Deslocamento inválido");
      }

      if (!ASSETS.includes(a.asset))
        throw Error("Asset desconhecido: " + a.asset);
      for (const k of ["x", "z", "width", "height"])
        if (!Number.isFinite(a[k])) throw Error("Dimensão/posição inválida");
      if (a.width <= 0 || a.height <= 0 || a.width > 25 || a.height > 25)
        throw Error("Dimensão fora dos limites");
      for (const k of ["y", "walk", "enter"])
        if (a[k] !== undefined && !Number.isFinite(a[k]))
          throw Error("Parâmetro de ator inválido");
    }
    duration += s.duration;
  }
  if (
    !Number.isFinite(story.duration) ||
    Math.abs(duration - story.duration) > 0.001
  )
    throw Error("Duração total difere da soma das cenas");
  return story;
}
export function locateScene(story, time) {
  const t = Math.min(story.duration, Math.max(0, Number(time) || 0));
  let start = 0;
  for (let index = 0; index < story.scenes.length; index++) {
    const scene = story.scenes[index];
    if (t < start + scene.duration || index === story.scenes.length - 1)
      return { index, scene, local: t - start, start, time: t };
    start += scene.duration;
  }
}

export const ASSET_FILES={
  "aladdin": {
    "file": "assets/aladdin/personagens.png",
    "rect": [
      0,
      0,
      500,
      1024
    ]
  },
  "mae_aladdin": {
    "file": "assets/aladdin/personagens.png",
    "rect": [
      500,
      0,
      470,
      1024
    ]
  },
  "amira": {
    "file": "assets/aladdin/personagens.png",
    "rect": [
      970,
      0,
      566,
      1024
    ]
  },
  "viajante": {
    "file": "assets/aladdin/genio-viajante-guarda.png",
    "rect": [
      0,
      0,
      550,
      1024
    ]
  },
  "genio": {
    "file": "assets/aladdin/genio-viajante-guarda.png",
    "rect": [
      550,
      0,
      550,
      1024
    ]
  },
  "guarda_aladdin": {
    "file": "assets/aladdin/genio-viajante-guarda.png",
    "rect": [
      1100,
      0,
      436,
      1024
    ]
  },
  "mercado": {
    "file": "assets/aladdin/cenarios.png",
    "rect": [
      0,
      0,
      950,
      809
    ]
  },
  "caverna_aladdin": {
    "file": "assets/aladdin/cenarios.png",
    "rect": [
      950,
      0,
      650,
      809
    ]
  },
  "torre_aladdin": {
    "file": "assets/aladdin/cenarios.png",
    "rect": [
      1600,
      0,
      342,
      809
    ]
  },
  "oficina_aladdin": {
    "file": "assets/aladdin/interiores.png",
    "rect": [
      0,
      0,
      718,
      724
    ]
  },
  "cristais_aladdin": {
    "file": "assets/aladdin/interiores.png",
    "rect": [
      718,
      0,
      732,
      724
    ]
  },
  "jardim_aladdin": {
    "file": "assets/aladdin/interiores.png",
    "rect": [
      1450,
      0,
      722,
      724
    ]
  },
  "gato_aladdin": {
    "file": "assets/aladdin/secundarios.png",
    "rect": [
      0,
      0,
      575,
      887
    ]
  },
  "jardineiro_aladdin": {
    "file": "assets/aladdin/secundarios.png",
    "rect": [
      575,
      0,
      570,
      887
    ]
  },
  "criancas_aladdin": {
    "file": "assets/aladdin/secundarios.png",
    "rect": [
      1145,
      0,
      629,
      887
    ]
  }
};
