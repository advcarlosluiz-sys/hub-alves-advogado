import * as THREE from '../vendor/three.module.js';
const smooth=x=>{x=Math.max(0,Math.min(1,x));return x*x*(3-2*x)};
export function buildAladdinProps(parent,s){
 const g=new THREE.Group();parent.add(g);
 const mat=c=>new THREE.MeshStandardMaterial({color:c,roughness:.9,side:THREE.DoubleSide});
 const gold=mat('#c69954'),wood=mat('#956743'),cream=mat('#f0dab3'),teal=mat('#5d9491'),violet=mat('#9480ad');
 const glow=new THREE.MeshBasicMaterial({color:'#ffe8a3'});
 function mesh(geo,material,x,y,z,parent=g){const m=new THREE.Mesh(geo,material);m.position.set(x,y,z);m.castShadow=m.receiveShadow=true;parent.add(m);return m}
 function box(w,h,d,m,x,y,z,parent){return mesh(new THREE.BoxGeometry(w,h,d),m,x,y,z,parent)}
 function pot(x,z,flowers=false){mesh(new THREE.CylinderGeometry(.22,.15,.4,10),mat('#ba7960'),x,.2,z);if(flowers)for(let n=0;n<5;n++){const xx=x+Math.cos(n*2.4)*.12;box(.02,.4,.02,mat('#788c5e'),xx,.6,z);mesh(new THREE.SphereGeometry(.07,6,5),mat(n%2?'#ce97a0':'#f1d089'),xx,.82,z);}}
 function lantern(x,y,z,scale=1){const q=new THREE.Group();q.position.set(x,y,z);q.scale.setScalar(scale);g.add(q);box(.28,.38,.22,gold,0,0,0,q);box(.18,.26,.24,glow,0,0,.01,q);mesh(new THREE.ConeGeometry(.22,.16,4),gold,0,.26,0,q);const ring=mesh(new THREE.TorusGeometry(.09,.015,5,12),gold,0,.39,0,q);return q;}
 const lanterns=[];
 if(s.marketProps){for(const x of [-3.6,3.7]){pot(x,1.1);for(let n=0;n<4;n++)mesh(new THREE.SphereGeometry(.09,8,6),mat(n%2?'#e4b868':'#c57e5e'),x+(n-1.5)*.13,.45,1.1);}for(const x of [-3,0,3])lanterns.push(lantern(x,3.35,-1.8,.8));}
 if(s.workbenchAl){box(2.8,.12,1.05,wood,.4,.85,-.25);for(const x of [-.7,1.5])for(const z of [-.6,.1])box(.1,.85,.1,wood,x,.42,z);for(const x of [-.5,.4,1.2])lanterns.push(lantern(x,1.3,-.2,.7));box(.45,.04,.2,gold,.8,.94,.03);pot(-4,1.2,true);}
 if(s.mapProp){box(.65,.45,.018,cream,1.1,1.4,.45);for(let i=0;i<5;i++)box(.07,.018,.022,gold,.87+i*.1,1.35+Math.sin(i)*.08,.47);}
 if(s.desert){for(let n=0;n<5;n++){const dune=mesh(new THREE.SphereGeometry(1.2+n*.12,16,8),mat(n%2?'#d4b17b':'#e5c794'),-4+n*2,.08,-2.2);dune.scale.set(1,.12,.65);}}
 if(s.steps)for(let n=0;n<5;n++)box(1.3,.1+n*.1,.35,cream,-.5,(.1+n*.1)/2,-.2-n*.33);
 let door=null;
 if(s.caveDoor){door=new THREE.Group();door.position.set(.1,0,-1.4);g.add(door);const points=[[-1,0],[-1.1,.65],[-.95,1.4],[-1.04,2.15],[-.73,3.12],[-.28,3.65],[.4,3.5],[.87,2.85],[1.02,1.9],[.88,.9],[1,0]];const outline=new THREE.Shape();outline.moveTo(...points[0]);for(const q of points.slice(1))outline.lineTo(...q);outline.closePath();mesh(new THREE.ExtrudeGeometry(outline,{depth:.12,bevelEnabled:false}),mat('#b79b80'),0,0,0,door);
 const facets=[ [[-1,0],[-.95,1.4],[.05,1.1],[.2,0]], [[-.95,1.4],[-.73,3.12],[-.28,3.65],[.05,1.1]], [[.05,1.1],[-.28,3.65],[.87,2.85],[1.02,1.9]], [[.05,1.1],[1.02,1.9],[1,0],[.2,0]] ];
 facets.forEach((points,n)=>{const sh=new THREE.Shape();sh.moveTo(...points[0]);for(const q of points.slice(1))sh.lineTo(...q);sh.closePath();mesh(new THREE.ShapeGeometry(sh),mat(['#b9a084','#c4aa8d','#a58c77','#b49a82'][n]),0,0,.13,door);});}
 if(s.treasures){for(const x of [-3.5,3.4]){box(1,.55,.7,wood,x,.3,.1);box(1,.1,.72,gold,x,.6,.1);for(const dx of [-.32,.32])box(.07,.55,.74,gold,x+dx,.32,.1);}for(let n=0;n<8;n++)mesh(new THREE.OctahedronGeometry(.14,0),mat(n%2?'#afa0c4':'#83b5b3'),-4.1+(n%4)*.25,.18+(n%3)*.12,1+(n<4?0:.5));}
 let lamp=null;
 if(s.magicLamp||s.liberate){lamp=new THREE.Group();g.add(lamp);lamp.position.set(s.id==='torre'?-.1:.4,s.workbenchAl?1.1:.55,1.05);mesh(new THREE.SphereGeometry(.25,16,10),gold,0,0,0,lamp).scale.set(1.4,.55,.7);mesh(new THREE.CylinderGeometry(.1,.17,.07,12),gold,0,-.15,0,lamp);const spout=mesh(new THREE.ConeGeometry(.12,.52,9),gold,.42,.08,0,lamp);spout.rotation.z=-1.15;mesh(new THREE.SphereGeometry(.12,10,6),gold,0,.17,0,lamp).scale.y=.4;mesh(new THREE.TorusGeometry(.17,.025,6,16),gold,-.33,.04,0,lamp);}
 if(s.swapLamp){const copy=new THREE.Group();g.add(copy);mesh(new THREE.SphereGeometry(.18,12,8),mat('#b1b8b4'),.8,1.12,-.25,copy);}
 if(s.cartAl){box(1.2,.14,.8,wood,2.9,.55,.5);for(const dx of [-.55,.55]){const wheel=mesh(new THREE.CylinderGeometry(.32,.32,.1,14),wood,2.9+dx,.32,.5);wheel.rotation.z=Math.PI/2;}for(let n=0;n<3;n++)lanterns.push(lantern(2.5+n*.35,.9,.5,.6));}
 let water=null;
 if(s.fountainAl){const f=new THREE.Group();f.position.set(.1,.02,-.9);g.add(f);mesh(new THREE.CylinderGeometry(.95,1,.25,12),cream,0,.13,0,f);const rim=mesh(new THREE.TorusGeometry(.88,.07,6,24),gold,0,.28,0,f);rim.rotation.x=Math.PI/2;water=mesh(new THREE.CylinderGeometry(.83,.83,.018,24),teal,0,.27,0,f);mesh(new THREE.CylinderGeometry(.12,.2,.75,12),cream,0,.6,0,f);mesh(new THREE.CylinderGeometry(.45,.3,.12,14),cream,0,.98,0,f);for(let n=0;n<8;n++){const a=n*Math.PI/4,points=[];for(let j=0;j<=10;j++){const u=j/10;points.push(new THREE.Vector3(Math.cos(a)*u*.63,1.2+.48*Math.sin(u*Math.PI)-u*.88,Math.sin(a)*u*.63));}const q=new THREE.Mesh(new THREE.TubeGeometry(new THREE.CatmullRomCurve3(points),12,.015,4,false),teal);water.add(q);}}
 if(s.gardenProps){for(const x of [-4.2,4.2])for(const z of [-.3,1.5])pot(x,z,true);for(const x of [-3.9,3.9]){box(.09,3.1,.09,wood,x,1.55,-1.7);box(.9,.06,.4,wood,x,3.1,-1.7);}}
 if(s.lanternFestival){const pts=[];for(let n=0;n<=20;n++){const x=-4.4+n*.44;pts.push(new THREE.Vector3(x,3.55-.4*Math.sin(n*Math.PI/20),-.7));}mesh(new THREE.TubeGeometry(new THREE.CatmullRomCurve3(pts),30,.012,4,false),wood,0,0,0);for(let n=0;n<7;n++)lanterns.push(lantern(-3.8+n*1.27,3.25-.4*Math.sin(n*Math.PI/6),-.7,.6));}
 const sparks=[],ribbons=[];
 if(s.genieMagic){for(let n=0;n<28;n++)sparks.push(mesh(new THREE.OctahedronGeometry(.035+(n%3)*.012,0),glow,0,0,0));for(let n=0;n<3;n++){const points=[];for(let i=0;i<=32;i++){const a=i/32*2*Math.PI;points.push(new THREE.Vector3(Math.cos(a+n)*(.2+i*.018),i*.075,Math.sin(a+n)*.3));}ribbons.push(mesh(new THREE.TubeGeometry(new THREE.CatmullRomCurve3(points),40,.025,4,false),n%2?gold:violet,.4,.6,1.05));}}
 const path=[];if(s.starPath)for(let n=0;n<16;n++)path.push(mesh(new THREE.OctahedronGeometry(.045,0),glow,-3+n*.35,.12,-1+Math.sin(n*.4)*.6));
 return {update(t,closing){
  g.scale.y=Math.max(.001,smooth((t-.25)/1.2)*closing);
  if(door){const c=s.caveDoor.closeAt;const q=c===null?0:smooth((t-c)/1.5);door.position.x=c===null?2.2:2.2*(1-q);door.visible=c!==null;}
  if(lamp&&s.swapLamp){const q=smooth((t-9)/5);lamp.position.x=.4+q*1.9;lamp.position.y=1.1-q*.2;}
  if(lamp&&s.recoverLamp)lamp.position.x=-.1-smooth((t-10)/5)*1.3;
  if(lamp&&s.liberate)lamp.rotation.z=Math.sin(t*.6)*.08;
  if(water)water.visible=t>=(s.waterAt||0);
  const mq=s.genieMagic?smooth((t-s.genieMagic.start)/2):0;
  sparks.forEach((m,n)=>{const a=n*2.4+t*.65;m.visible=mq>.01;m.position.set(.4+Math.cos(a)*(s.liberate?1.7:1),.7+(n%8)*.36+Math.sin(a)*.1,1+Math.sin(a)*.6);m.scale.setScalar(mq*(.5+.5*Math.sin(t*2+n)**2));});
  ribbons.forEach((m,n)=>{m.visible=mq>.01;m.scale.y=Math.max(.001,mq);m.rotation.y=t*.25+n;});
  lanterns.forEach((m,n)=>m.rotation.z=Math.sin(t*.8+n)*.025);
  path.forEach((m,n)=>m.scale.setScalar(.5+.5*Math.sin(t*2-n*.3)**2));
 }};
}
