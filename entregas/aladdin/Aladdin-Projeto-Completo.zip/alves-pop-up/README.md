# Aladdin e a Lâmpada Mágica

Produção Contos de Gaitolé em livro pop-up 3D.

ALADDIN E A LÂMPADA MÁGICA — CONTOS DE GAITOLÉ

PARA ASSISTIR
Extraia tudo e abra output/aladdin-lampada-magica.mp4.
No pacote para assistir, o mesmo vídeo se chama ASSISTA-AQUI.mp4.
Não é necessário executar arquivos .cmd: a narração, a trilha e as legendas já estão no MP4.

DURAÇÃO E FORMATO
4min18s, horizontal 16:9, 1280 x 720, 24 quadros/s.
H.264 com áudio AAC estéreo.

PARA PUBLICAR
publicacao/miniatura-youtube.jpg tem 1280 x 720 pixels.
publicacao/titulo.txt e descricao.txt estão prontos para copiar.

PARA EDITAR
Este projeto usa o motor 3D do Mira, com Three.js e GSAP locais.
O roteiro ativo é stories/joao.json: o nome é herdado, mas o conteúdo é Aladdin.
A cópia identificada está em stories/aladdin.json.
Node.js 22+, Chrome/Edge e servidor local são necessários somente para editar/exportar.
Com Node instalado: node scripts/serve.mjs
Depois de alterar o roteiro ativo:
node scripts/narrate.mjs
node scripts/subtitles.mjs
node scripts/effects.mjs
Abra o endereço exibido pelo servidor e clique em Exportar MP4.

CRÉDITOS
Adaptação original do conto tradicional com o roteiro fornecido pelo autor.
Ilustrações originais, criadas para esta produção.
Voz pt-BR-ThalitaMultilingualNeural, ritmo -12%, tom -4Hz.
Marca e música fornecidas pelo autor; original musical preservado em assets/musica/gaitole.mp3.
