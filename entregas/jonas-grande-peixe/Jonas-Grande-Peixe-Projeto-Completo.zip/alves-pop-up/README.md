# Jonas e o Grande Peixe — livro pop-up

Adaptação infantil do roteiro fornecido, baseada em Jonas 1–4, para Contos de Gaitolé. Duração de 4min07s (247 s), horizontal 1280 × 720, 24 fps, H.264/AAC estéreo. Narração Thalita em português do Brasil, legendas por frase e música “Jonas, uma nova chance” reduzida durante as falas.

## Assistir

Abra `output/jonas-grande-peixe.mp4`. No ZIP para assistir, extraia tudo e abra `alves-pop-up/ASSISTA-AQUI.mp4`. Não é necessário executar `.cmd` ou instalar o gerador para assistir ao vídeo pronto.

## Cenas

Dez cenas com capa trabalhada, livro sobre mesa em sala decorada, porto, barco articulado com velas, ondas de papel, grande peixe com painel lateral dobrável e interior iluminado, oração, praia, Nínive com portões móveis e mercado, plantinha que cresce e murcha. O suspense é leve, sem imagens de afogamento ou violência.

Pergunta narrada a partir dos 2 segundos, capa breve e contexto da história a partir dos 14 segundos. Encerramento de 20 segundos com marca, perfis, convite à inscrição e indicação de A Arca de Noé. Os elementos finais são gráficos do próprio vídeo, sem pressupor recursos interativos do YouTube.

## Arquivos

- `stories/joao.json`: roteiro principal do motor; nome mantido por compatibilidade. Cópia em `stories/jonas-grande-peixe.json`.
- `references/roteiro-fornecido.txt`: texto original enviado pelo usuário.
- `assets/jonas/`: personagens, poses, animais e seis cenários de papel. Mapa de recortes em `engine/story.mjs`; origens em `references/assets-originais.json`.
- `engine/jonas-props.mjs`: objetos e mecanismos 3D, incluindo peixe, painel articulado, barco, portão, palmeiras, mercado e plantinha.
- `assets/narracao/`: dez clipes Thalita, manifesto com hashes e tempos das legendas.
- `assets/musica/jonas-uma-nova-chance.mp3`: original fornecido, preservado. A mistura utiliza o trecho correspondente à duração do vídeo, com redução nas falas e término suave; não é um videoclipe da música inteira.
- `assets/efeitos/`: pássaros, passos, água suave e sinal de encerramento.
- `publicacao/`: capa, título, descrição e duas miniaturas A/B em 1280 × 720.

## Editar e exportar

Requer Node.js 22+, Chrome/Chromium/Edge e FFmpeg. Execute `npm ci` e `npm start` para visualizar. Exporte com `npm run render:fast -- --out output/jonas-grande-peixe.mp4`. Use `CHROME_PATH` e `FFMPEG_PATH` se necessário. A geração Noiz está desativada e nenhuma chave é necessária para exportar os áudios incluídos. Mudanças no texto exigem nova narração e legendas. Os atalhos são opcionais para edição; o MP4 pronto pode ser assistido diretamente.

## Créditos

Roteiro e música fornecidos pelo usuário. Referência bíblica em Jonas 1–4. Contos de Gaitolé: YouTube @gaitolé e TikTok @gaitole0. Licença e avisos originais Mira preservados em LICENSE-MIRA e vendor. Nenhuma publicação no YouTube ou teste A/B de desempenho foi executado.
