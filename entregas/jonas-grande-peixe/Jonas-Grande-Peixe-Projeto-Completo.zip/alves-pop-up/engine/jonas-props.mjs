import * as THREE from '../vendor/three.module.js';
const smooth=x=>{x=Math.max(0,Math.min(1,x));return x*x*(3-2*x)};
export function buildJonasProps(parent,s,textures,actors){
 const g=new THREE.Group();parent.add(g);
 const mat=c=>new THREE.MeshStandardMaterial({color:c,roughness:.96,side:THREE.DoubleSide});
 const wood=mat('#ac7949'),dark=mat('#80572f'),cream=mat('#f1e3bf'),gold=mat('#d5b36a'),green=mat('#759554'),blue=mat('#76acb6'),stone=mat('#cfb38d'),clay=mat('#bf855b');
 function mesh(geo,m,x=0,y=0,z=0,group=g){const a=new THREE.Mesh(geo,m);a.position.set(x,y,z);a.castShadow=a.receiveShadow=true;group.add(a);return a;}
 function box(w,h,d,m,x,y,z,group){return mesh(new THREE.BoxGeometry(w,h,d),m,x,y,z,group)}
 function cyl(r1,r2,h,m,x,y,z,group){return mesh(new THREE.CylinderGeometry(r1,r2,h,16),m,x,y,z,group)}
 function tx(draw){const c=document.createElement('canvas');c.width=c.height=256;draw(c.getContext('2d'));const t=new THREE.CanvasTexture(c);t.colorSpace=THREE.SRGBColorSpace;return t;}
 function oval(cx,cy,rx,ry){const sh=new THREE.Shape();sh.absellipse(cx,cy,rx,ry,0,Math.PI*2,false);return sh;}
 const grain=new THREE.MeshStandardMaterial({map:tx(c=>{c.fillStyle='#b98450';c.fillRect(0,0,256,256);for(let n=0;n<8;n++){c.strokeStyle='#916135';c.lineWidth=3;c.beginPath();c.moveTo(0,n*32);c.lineTo(256,n*32);c.stroke();c.lineWidth=.7;for(let j=0;j<3;j++){c.beginPath();c.moveTo(0,n*32+7+j*6);c.bezierCurveTo(90,n*32+j*6,180,n*32+13+j*6,256,n*32+7+j*6);c.stroke();}}}),roughness:.95,side:THREE.DoubleSide});
 let fish=null,flap=null,boat=null,sail=null,plant=null,worm=null;const waves=[],leaves=[],glints=[],doors=[];
 if(s.fishModel){
  fish=new THREE.Group();fish.position.set(s.fishX||0,0,s.fishZ||0);fish.scale.setScalar(s.fishScale||1);g.add(fish);
  const texture=textures.peixe,H=4.5,W=H*texture.image.width/texture.image.height;
  const skin=new THREE.MeshStandardMaterial({map:texture,alphaTest:.45,side:THREE.DoubleSide,roughness:1});
  mesh(new THREE.ExtrudeGeometry(oval(.3,2.15,2.65,1.4),{depth:.22,bevelEnabled:false}),mat('#538b90'),0,0,-.55,fish);
  mesh(new THREE.PlaneGeometry(W,H),skin,0,H/2+.025,-.3,fish);
  mesh(new THREE.ShapeGeometry(oval(.15,2.15,1.98,1.2)),mat('#deceac'),0,0,.06,fish);
  box(3.5,.07,.75,wood,.15,1,.22,fish);
  for(let n=0;n<6;n++)box(.025,.015,.72,gold,-1.3+n*.55,1.045,.22,fish);
  for(let n=0;n<3;n++){const dot=mesh(new THREE.CircleGeometry(.065,10),gold,-.65+n*.65,3.02,.1,fish);dot.castShadow=false;}
  const glow=tx(c=>{const a=c.createRadialGradient(128,128,2,128,128,128);a.addColorStop(0,'rgba(255,227,153,.6)');a.addColorStop(.65,'rgba(255,227,153,.22)');a.addColorStop(1,'rgba(255,227,153,0)');c.fillStyle=a;c.fillRect(0,0,256,256);});
  const aura=mesh(new THREE.PlaneGeometry(3.8,2.6),new THREE.MeshBasicMaterial({map:glow,transparent:true,depthWrite:false}),.15,2.15,.12,fish);aura.castShadow=false;
  flap=new THREE.Group();flap.position.set(0,.85,.68);fish.add(flap);
  const geo=new THREE.ShapeGeometry(oval(.15,1.3,2.1,1.3),48),pos=geo.attributes.position,uv=geo.attributes.uv;
  for(let i=0;i<pos.count;i++)uv.setXY(i,(pos.getX(i)+W/2)/W,(pos.getY(i)+.85-.025)/H);uv.needsUpdate=true;
  mesh(geo,skin,0,0,0,flap);
  const pts=[];for(let i=0;i<=72;i++){const a=i*Math.PI*2/72;pts.push(new THREE.Vector3(.15+Math.cos(a)*2.1,1.3+Math.sin(a)*1.3,.008));}
  const rim=new THREE.Line(new THREE.BufferGeometry().setFromPoints(pts),new THREE.LineBasicMaterial({color:'#d5d4b2'}));flap.add(rim);
  for(const a of actors.filter(a=>a.data.fishPassenger))fish.add(a.pivot);
  if(s.prayerProps)for(let n=0;n<9;n++){const q=mesh(new THREE.CircleGeometry(.025+(n%3)*.009,5),new THREE.MeshBasicMaterial({color:'#d7b976',transparent:true}),0,0,0,fish);q.castShadow=false;glints.push(q);}
 }
 if(s.boatModel){
  boat=new THREE.Group();boat.position.set(s.boatX||0,0,s.boatZ||0);boat.scale.setScalar(s.boatScale||1);g.add(boat);
  const hull=new THREE.Shape();hull.moveTo(-2.9,1.2);hull.lineTo(-2.3,.2);hull.quadraticCurveTo(0,-.02,2.3,.2);hull.lineTo(2.9,1.2);hull.closePath();mesh(new THREE.ExtrudeGeometry(hull,{depth:1.7,bevelEnabled:true,bevelSize:.025,bevelThickness:.025,bevelSegments:1}),grain,0,0,-.85,boat);
  box(5.4,.06,1.55,dark,0,.94,0,boat);box(5.6,.07,.07,cream,0,1.23,.9,boat);
  cyl(.045,.06,3.7,wood,.05,3,-.45,boat);
  sail=new THREE.Group();sail.position.set(.1,1.7,-.35);boat.add(sail);
  const sh=new THREE.Shape();sh.moveTo(0,0);sh.lineTo(0,2.7);sh.quadraticCurveTo(1.65,1.4,2.1,0);sh.closePath();mesh(new THREE.ShapeGeometry(sh),cream,0,0,0,sail);
  for(let n=1;n<=4;n++){const p=mesh(new THREE.PlaneGeometry(.018,2.6-n*.4),blue,n*.3,(2.6-n*.4)/2,.015,sail);p.rotation.z=.08;}
  const penn=new THREE.Shape();penn.moveTo(0,0);penn.lineTo(.65,-.13);penn.lineTo(0,-.32);penn.closePath();mesh(new THREE.ShapeGeometry(penn),mat('#b97563'),.1,4.85,-.45,boat);
  for(const a of actors.filter(a=>a.data.boatPassenger))boat.add(a.pivot);
 }
 if(s.waterFloor){for(let n=0;n<5;n++){const sh=new THREE.Shape();sh.moveTo(-5,0);for(let k=0;k<=40;k++)sh.lineTo(-5+k*.25,.28+Math.sin(k*.65+n)*.09);sh.lineTo(5,0);sh.closePath();waves.push(mesh(new THREE.ShapeGeometry(sh),mat(n%2?'#86bfc9':'#639fae'),0,.08,1.5+n*.42));}}
 if(s.harborProps){for(let n=0;n<3;n++){cyl(.24,.24,.56,wood,-4+n*.5,.3,.4);mesh(new THREE.TorusGeometry(.25,.018,5,20),dark,-4+n*.5,.4,.4).rotation.x=Math.PI/2;}box(.7,.5,.6,wood,-3.4,.25,1.1);const rope=mesh(new THREE.TorusGeometry(.28,.04,6,30),gold,-3.9,.08,1.5);rope.rotation.x=-Math.PI/2;}
 if(s.signProps){box(.08,1.8,.08,wood,-.3,.9,-.25);for(let n=0;n<2;n++){const canvas=document.createElement('canvas');canvas.width=512;canvas.height=128;const c=canvas.getContext('2d');c.fillStyle='#e9d8b0';c.fillRect(0,0,512,128);c.fillStyle='#705332';c.font='bold 60px Georgia';c.textAlign='center';c.fillText(n?'PORTO →':'← NÍNIVE',256,86);const map=new THREE.CanvasTexture(canvas);map.colorSpace=THREE.SRGBColorSpace;const p=mesh(new THREE.PlaneGeometry(1.5,.45),new THREE.MeshStandardMaterial({map,side:THREE.DoubleSide}),-.3,1.6-n*.5,-.19);}}
 if(s.beachProps){const water=mesh(new THREE.PlaneGeometry(5.3,2.2),blue,-2.2,.04,-1.5);water.rotation.x=-Math.PI/2;for(let n=0;n<7;n++){const a=mesh(new THREE.SphereGeometry(.08+(n%3)*.018,8,5),n%2?cream:clay,-4+n*1.2,.07,2.3+(n%2)*.5);a.scale.y=.35;}for(const x of [-4.1,4.2]){cyl(.07,.13,2.4,wood,x,1.2,-.3);for(let n=0;n<5;n++){const sh=new THREE.Shape();sh.moveTo(0,0);sh.quadraticCurveTo(.3,.4,1.2,.1);sh.quadraticCurveTo(.5,-.15,0,0);const a=mesh(new THREE.ShapeGeometry(sh),green,x,2.4,-.3);a.rotation.y=n*Math.PI*2/5;a.rotation.z=-.35;}}}
 if(s.underwaterProps){for(const side of [-1,1])for(let n=0;n<3;n++){const sh=new THREE.Shape();sh.moveTo(0,0);sh.quadraticCurveTo(.5,.7,.12,1.5+n*.15);sh.quadraticCurveTo(-.2,.8,0,0);mesh(new THREE.ShapeGeometry(sh),n%2?green:blue,side*(4.1+n*.23),.06,.5+n*.2);}for(let n=0;n<8;n++){const a=mesh(new THREE.TorusGeometry(.035+(n%3)*.018,.008,4,14),cream,-4.2+(n%2)*8.2,.7+(n%4)*.6,.6);a.castShadow=false;}}
 if(s.cityProps){
  const arch=new THREE.Shape();arch.moveTo(-2,0);arch.lineTo(2,0);arch.lineTo(2,3.2);arch.lineTo(-2,3.2);arch.closePath();const hole=new THREE.Path();hole.moveTo(-1.05,0);hole.lineTo(-1.05,1.95);hole.quadraticCurveTo(0,3.1,1.05,1.95);hole.lineTo(1.05,0);hole.closePath();arch.holes.push(hole);mesh(new THREE.ExtrudeGeometry(arch,{depth:.25,bevelEnabled:false}),stone,0,0,-1.5);
  for(const side of [-1,1]){box(.65,3.5,.6,stone,side*1.75,1.75,-1.3);for(let k=0;k<3;k++)box(.16,.2,.62,cream,side*1.75-.25+k*.25,3.6,-1.3);const p=new THREE.Group();p.position.set(side*1.05,.02,-1.15);g.add(p);box(1,2.3,.06,grain,-side*.5,1.15,0,p);doors.push({p,side});}
 }
 if(s.marketProps){box(1.5,.1,.9,wood,-3.5,.8,-.3);for(const x of [-4.15,-2.85]){box(.06,2,.06,wood,x,1,-.65);box(.06,.8,.06,wood,x,.4,.05);}const awning=box(1.65,.04,1.1,cream,-3.5,2.02,-.25);awning.rotation.x=.15;for(let n=0;n<5;n++){const a=box(.15,.045,1.1,blue,-4.1+n*.3,2.05,-.25);a.rotation.x=.15;}for(let n=0;n<8;n++)mesh(new THREE.SphereGeometry(.1,10,8),n%2?gold:mat('#bd8063'),-4+(n%4)*.3,.98,-.45+Math.floor(n/4)*.32);for(let n=0;n<2;n++)cyl(.18,.13,.38,clay,3.8+n*.4,.2,-.2);}
 if(s.gardenProps)for(let n=0;n<8;n++){const x=n<4?-4.6+n*.25:4+(n-4)*.25,z=.6+(n%2)*.45;box(.02,.35,.02,green,x,.2,z);mesh(new THREE.CircleGeometry(.1,6),n%2?gold:cream,x,.42,z+.02);}
 if(s.plantProps){
  plant=new THREE.Group();plant.position.set(-1.1,0,.65);g.add(plant);cyl(.05,.09,3,green,0,1.5,0,plant);
  for(let n=0;n<9;n++){const side=n%2?1:-1;const sh=new THREE.Shape();sh.moveTo(0,0);sh.bezierCurveTo(.3,.45,1.0,.5,1.4,.07);sh.bezierCurveTo(.9,-.42,.3,-.3,0,0);const p=new THREE.Group();p.position.set(side*.05,2.1+(n%3)*.38,(n%3)*.06);p.rotation.z=side>0?.2:Math.PI-.2;plant.add(p);const material=mat('#739653');const a=mesh(new THREE.ShapeGeometry(sh),material,0,0,0,p);p.rotation.y=(n%3-1)*.18;leaves.push({p,a,base:p.rotation.z,material});}
  worm=new THREE.Group();worm.position.set(.02,1.15,.12);plant.add(worm);for(let n=0;n<5;n++)mesh(new THREE.SphereGeometry(.07,8,6),mat('#cc9c8b'),n*.09,Math.sin(n*.8)*.03,0,worm);for(const x of [.33,.39])mesh(new THREE.SphereGeometry(.012,6,4),dark,x,.07,.055,worm);
 }
 if(s.sunProps){mesh(new THREE.CircleGeometry(.35,24),gold,3.4,4,-2.4);for(let n=0;n<8;n++){const a=n*Math.PI/4;const ray=mesh(new THREE.PlaneGeometry(.025,.16),gold,3.4+Math.cos(a)*.54,4+Math.sin(a)*.54,-2.39);ray.rotation.z=a-Math.PI/2;}}
 return {update(t,closing){
  g.scale.y=Math.max(.001,smooth((t-.25)/1.15)*closing);
  if(fish){const q=s.fishAlwaysOpen ? .85+.15*smooth((t-.2)/1.5):s.fishOpen?smooth((t-1.8)/2.5):0;flap.rotation.x=q*1.56;if(s.fishFloat){fish.position.y=Math.sin(t*.65)*.07;fish.rotation.z=Math.sin(t*.45)*.012;}}
  if(boat){if(s.boatFloat){boat.position.y=.12+Math.sin(t*.8)*.07;boat.rotation.z=Math.sin(t*.65)*.025;}sail.rotation.z=Math.sin(t*.9)*.025;}
  waves.forEach((a,n)=>{a.position.x=Math.sin(t*.55+n)*.1;a.position.y=.08+Math.sin(t*.8+n)*.035;});
  glints.forEach((a,n)=>{a.position.set(-.7+(n%3)*.6,.9+(n%4)*.45+Math.sin(t*.65+n)*.08,.28);a.material.opacity=smooth((t-3)/3)*(.4+.3*Math.sin(t+n));});
  doors.forEach(({p,side})=>p.rotation.y=side*smooth((t-1.5)/3)*1.15);
  if(plant){const growth=smooth((t-2)/5),dry=smooth((t-11)/4);plant.scale.y=Math.max(.001,growth);leaves.forEach(({p,a,base,material},n)=>{p.rotation.z=base+(n%2?1:-1)*dry*.65;p.rotation.x=dry*.9;material.color.set('#739653').lerp(new THREE.Color('#b6a078'),dry);a.scale.setScalar(1-dry*.18);});worm.visible=t>10&&t<17;worm.position.x=.02+Math.sin(t*.5)*.12;}
 }};
}
